#!/usr/bin/env python3
"""
MicroMap package.

This file replaces the old micromap.py with hardcoded paths.
It automatically locates the local "submodules" directory relative
to the installed package location.
"""

from __future__ import annotations

import os
import platform
import sys
from pathlib import Path

__version__ = "1.1.0"

# Каталог submodules внутри установленного пакета micromap
_SUBMODULES_DIR = Path(__file__).resolve().parent / "submodules"

if _SUBMODULES_DIR.is_dir():
    # Windows: нужно для поиска DLL
    if platform.system() == "Windows":
        if hasattr(os, "add_dll_directory"):
            os.add_dll_directory(str(_SUBMODULES_DIR))

    # Linux/macOS: оставляем для совместимости,
    # но для .so лучше использовать RPATH/RUNPATH.
    else:
        old_ld_path = os.environ.get("LD_LIBRARY_PATH", "")
        if str(_SUBMODULES_DIR) not in old_ld_path.split(os.pathsep):
            os.environ["LD_LIBRARY_PATH"] = str(_SUBMODULES_DIR) + (
                os.pathsep + old_ld_path if old_ld_path else ""
            )

    # Добавляем submodules в sys.path, чтобы работали старые импорты вида:
    # from mapedit import MapEdit
    # from transformdata import TransformData
    if str(_SUBMODULES_DIR) not in sys.path:
        sys.path.insert(0, str(_SUBMODULES_DIR))

# Старые импорты
from mapedit import MapEdit
from transformdata import TransformData
from simplemapconstruction import SimpleMapConstruction
from phasemapconstruction import PhaseMapConstruction
from fittingmap import FittingMap
from plotmap import PlotMap
from readwriteir5 import ReadWrite5

__all__ = [
    "MapEdit",
    "TransformData",
    "SimpleMapConstruction",
    "PhaseMapConstruction",
    "FittingMap",
    "PlotMap",
    "ReadWrite5",
]