"""
The module finder for web-app ArDi (ArDI (Advanced spectRa Deconvolution Instrument)) for fitting of different types of curves, search in databases with different methods and printing results from db.
1) micromap (https://github.com/romus33/micromap): time, ctypes, multiprocessing, lmfit, numpy, scipy, termcolor, os, platform

2) dash, plotly, dash_bootstrap, pandas, urllib, base64, io, os, sys, copy

"""
__author__ = "Roman Shendrik, A. Myasnikova"
__copyright__ = "Copyright © 2023R"
__license__ = "GNU GPL 3.0"
__version__ = "2.1.0"


import numpy as np
import copy
import torch
# import onnx
import onnxruntime
from lmfit import minimize, Parameters, fit_report
#import scipy.special as sp
#import os,sys,math
import fittingmap as mm
import readwriteir5 as rm
import time, re, os
from scipy.signal import savgol_filter
import faiss
import time as tm
from scipy.optimize import lsq_linear
import scipy
from jcamp import jcamp_read
from scipy.signal import find_peaks, peak_widths
from scipy import interpolate
from typing import List, Tuple, Optional, Dict, Any
#from predict import MineralPredictor
from scipy.optimize import least_squares
from scipy.special import factorial
from scipy.linalg import lstsq
# import fastrdp
MAX_ITERATIONS = 29  # Maximum number of iterations for basis selection
MIN_CONDITION = 1e-15  # Minimum condition number for least squares solver
DEFAULT_PROBE = 128  # Default FAISS nprobe parameter
DEFAULT_EF = 64  # Default FAISS ef parameter 
CONFIG = {
    "model_path": "model_complete.pth",
    "peaks_db": "mineral_peaks_db.json",
    "minerals": ['quartz','calcite','topaz','tourmaline','corundum','albite','sassolite','whewellite','borax','hydroboracite','trona','nahcolite','gaylussite','burkeite','hydromagnesite','dawsonite','strontianite','aragonite','dolomite','siderite','zabuyelite','magnesite','qilianshanite','cryolite','elpasolite','fluorite','saltonseaite','graphite','hematite','cristobalite','arsenolite','claudetite','senarmontite','valentinite','wavellite','orthoclase','talc','sulphohalite','epsomite','alunogen','thenardite','halotrichite','gypsum','blodite','polyhalite','realgar','orpiment','cryolithionite','eskolaite','ramanite-(cs)','ramanite-(rb)','forsterite','atacamite','aphthitalite','glauberite','alunite','anglesite','anhydrite','antlerite','brochantite','celestine','chalcanthite','jarosite','langbeinite','linarite','syngenite','natrojarosite','voltaite','goldichite','azurite','cerussite','malachite','otavite','phosgenite','rhodochrosite','smithsonite','witherite','ankerite','vivianite','pyromorphite','goethite','diaspore','cuprite','tenorite','spinel','chromite','prehnite','epidote','laumontite','wairakite','wollastonite','diopside','tremolite','actinolite','pyrite','marcasite','pyrrhotite','chalcopyrite','sphalerite','molybdenite','kainite'],
    "test_file": "test.csv"
}


class MLSearch(object):
    def __init__(self, strunz = None, minlist = None, formula = None, chem_elements = None, deep_num = 3, cond = -1, shift = 0, number = 10, dbname = './databases/excellent-raman-rruf.h5'):
        """
            dbname (str): Path to HDF5 database file
            number (int): Maximum number of candidate components to consider
            strunz (list): Filter by Strunz classification
            minlist (list): Filter by mineral list
            formula (list): Filter by chemical formula
            chem_elements (list): Filter by chemical elements present  
            deep_num (int): Depth of iterative RPA
            cond (float): Tolerance of least square
            shift (int): Anbsolute value of spectral shift on X-axis 
            number_pr (int): number of printed results
        """      
        self.strunz  = strunz
        self.minlist = minlist
        self.formula = formula
        self.chem_elements = chem_elements
        self.deep_num = deep_num
        self.cond = cond
        self.shift = shift
        self.number_pr = number
        self.dbname: str = dbname

#    def mixture_ai_search(self, x: np.ndarray, y: np.ndarray, top_names: int = 4):
#        start_time = tm.time()
#        x, y, shift_list = self._init_data(x, y, self.shift)
#        founded_names = []       
#        predictor = MineralPredictor(
#            model_path=CONFIG["model_path"],
#            mineral_columns=CONFIG["minerals"],
#            peaks_db_path=CONFIG["peaks_db"]
#        )
#        results = predictor.predict_from_csv(CONFIG["test_file"], data = [x,y], top_k=top_names)
#        for mineral, prob in results:
#            entry_data = self.get_info_from_db(key=mineral.title())
#            entry_data['R-factor'] = prob
#            entry_data['peaks'] = predictor.get_mineral_peaks(mineral)
#            founded_names.append(entry_data)
#        return founded_names, tm.time() - start_time       
    
    def faiss_search(self, y, index_file=None, filter_out=None, nprobe=DEFAULT_PROBE, ef=DEFAULT_EF):
        """
        Search a Faiss index using interpolated query data.

        Parameters:
        x (array-like): X-values of the query points.
        y (array-like): Y-values corresponding to the query points.
        database (dict-like): Database containing metadata (must have 'xmin', 'xmax', 'npoints' attributes).
        index_file (faiss.Index): The Faiss index to search.
        number (int): Number of results to return.
        filter_out (list): List of index IDs to exclude from results.
        nprobe (int): Number of IVF clusters to search (for IVF indices).
        ef (int): Search depth for HNSW indices.

        Returns:
        D (np.ndarray): Distances of the nearest neighbors.
        I (np.ndarray): Indices of the nearest neighbors.
        x_a (np.ndarray): Interpolation grid x-values.
        dY (np.ndarray): Interpolated y-values on the grid.
        """
        # Input validation
        if index_file is None:
            raise ValueError("Index file must be provided")
        query = y.reshape(1, -1).astype(np.float32)
        # Configure index parameters
        index = faiss.downcast_index(index_file.index)
        
        if isinstance(index, faiss.IndexIVF):
            index.nprobe = nprobe
        elif isinstance(index, faiss.IndexHNSW):
            index.hnsw.efSearch = ef

        # Handle ID filtering
        if filter_out:
            filter_out = set(filter_out)
            filter_ids = [id_ for id_ in range(index_file.ntotal) if id_ not in filter_out]
            
            if not filter_ids:
                return np.empty((0, self.number_pr)), np.empty((0, self.number_pr))

            filter_ids_np = np.asarray(filter_ids, dtype=np.int64)
            id_selector = faiss.IDSelectorArray(len(filter_ids_np), faiss.swig_ptr(filter_ids_np))

            # Use appropriate search parameters based on index type
            if isinstance(index, faiss.IndexIVF):
                search_params = faiss.SearchParametersIVF(sel=id_selector)
            else:
                raise NotImplementedError("Filtering not supported for this index type")
                
            D, I = index_file.search(query, self.number_pr, params=search_params)
        else:
            D, I = index_file.search(query, self.number_pr)

        return D, I         
    
    def find_mix_ml(self,
        x: np.ndarray,
        y: np.ndarray,
        loaded_class_names: Optional[List[str]] = None, 
        best_in_class: bool = None, 
        session: onnxruntime = None
    ) -> Tuple[List[Dict[str, Any]], float]:
        """
        Identifies mixture components in spectra using nearal network phase search and least squares fitting.

        Args:
            x (np.ndarray): X-coordinates of the experimental spectrum
            y (np.ndarray): Y-values of the experimental spectrum
            loaded_name_class (list): List of mineral names
            best_in_class (bool): If True the best spectrum from class to be in output 
            session: The AI onix session
        Returns:
            Tuple containing:
            - List of component dictionaries with metadata and fitting results
            - Total processing time in seconds
        Raises:
            ValueError: For invalid inputs or no components found
            RuntimeError: For database access or numerical computation issues
        """
        start_time = tm.time()
        # x = np.array(x)
        # y = np.array(y)
        with rm.h5py.File(self.dbname, 'r') as db:
            return self._process_spectrum_ml(x = x,
                                        y= y,
                                        db = db,
                                        start_time = start_time,
                                        loaded_class_names=loaded_class_names, 
                                        best_in_class=best_in_class, 
                                        session = session) 
               
    def _process_spectrum_ml(self,          
            x: np.ndarray,
            y: np.ndarray,
            db = None,
            start_time: float = 0.0,
            loaded_class_names=None, 
            best_in_class=True, 
            session = None,
            debug = False
            ) -> Tuple[List[Dict[str, Any]], float]:
            """Core processing logic for spectral analysis"""
            db_keys = list(db.keys())
            basis_vectors = [] 
            component_keys = []
            component_shift = []
            final_keys = []
            final_shift = []
            final_vectors = []
            final_coeffs = []
            
            y_max = np.nanmax(np.asarray(y, dtype=float))
            y_init = np.nan_to_num(np.asarray(y, dtype=float))/y_max
            x_init = x 
            for i in range(self.deep_num+1): 
                y_max = np.nanmax(y_init*y_max)
                y_ = np.nan_to_num(y_init/y_max) if y_max else y_init*0
                    
                basis_vectors_, component_keys_, component_shift_,_, y_init, x_init = self._select_basis_vectors_ml(x_init, y_, dbname = db,
                    dbkeys = db_keys, session = session, best_in_class = best_in_class,
                    loaded_class_names=loaded_class_names)
                y_init = y_init*y_max
                if not i:
                    y_init_0 = np.array(y_init)    
                # Phase 2: Least squares fitting
                if basis_vectors_:
                    coefficients, basis, keys, shifts = self._perform_least_squares(
                        basis_vectors=basis_vectors_, basis_keys = component_keys_, basis_shift = component_shift_,
                        y=y_init
                    )
                    if len(basis):
                        coefficients = np.nan_to_num(coefficients)
                        j=np.argmax(coefficients)
                        final_vectors.append(basis[j])
                        final_keys.append(keys[j])
                        final_shift.append(shifts[j])
                        final_coeffs.append(coefficients[j])
                        if i:
                            y_init = y_init - basis[j]*coefficients[j]    
                        else:
                            y_init = y_init - basis[j]
                        y_init[y_init<0] = 0
                        if debug:
                            np.savetxt(f'{i}. Spectra_{round(y_max,3)}_{keys[j][:5]}.txt',np.c_[x_init, y_init, basis[j]])
            if len(basis):  
                final_vectors.extend(basis[self.deep_num:])
                final_keys.extend(keys[self.deep_num:])
                final_shift.extend(shifts[self.deep_num:])
                final_coeffs.extend(coefficients)    
                # Phase 3: Result formatting
            return self._format_results(
                    db=db,
                    component_keys=final_keys,
                    coefficients=final_coeffs,
                    basis_vectors=final_vectors,
                    x=x_init,
                    y=y_init_0,
                    dbname=db.filename,
                    shift=final_shift,
                    start_time=start_time
                )    

    def _select_basis_vectors_ml(self, x, y, 
                                    session=None, 
                                    dbname = None,
                                    dbkeys=None, 
                                    loaded_class_names=None, 
                                    best_in_class = True
                    ):
            if dbname is None:
                raise ValueError("Database must be provided")

            if session is not None:
                session = onnxruntime.InferenceSession(session)
            else:
                raise ValueError("No sesion of ML opened")
            basis_vectors = [] 
            component_keys = [] 
            component_shift = [] 
            distances_ = []
            x, y, shift_list = self._init_data(x, y, self.shift)
            keys = dbkeys
            x_min = dbname[keys[0]].attrs['xmin']
            x_max = dbname[keys[0]].attrs['xmax']
            npoints = dbname[keys[0]].attrs['npoints']
                    
            x_a = np.linspace(x_min, x_max, npoints)
            test_return_y = np.interp(x_a, np.asarray(x, dtype=float), np.asarray(y, dtype=float), left=0, right=0)
            for shift_ in shift_list:
                    x_shifted = x + shift_
                    test_1_y_0 = np.interp(x_a, np.asarray(x_shifted, dtype=float), np.asarray(y, dtype=float), left=0, right=0)
                    # Prepare input for ONNX model
                    test_1_y = torch.from_numpy(test_1_y_0).unsqueeze(0).unsqueeze(0).permute(1, 0, 2).to(torch.float32)
                    test_1_y_np = test_1_y.numpy()

                    # Get input name and perform prediction
                    input_name = session.get_inputs()[0].name
                    outputs = session.run(None, {input_name: test_1_y_np})
                    logits = outputs[0]

                    # Apply softmax to get probabilities
                    probabilities = torch.softmax(torch.tensor(logits), dim=1)
                    a, top_indices = torch.topk(probabilities, k=self.number_pr)

                    top_indices = top_indices.cpu().numpy()
                    a = a.cpu().numpy()[0]

                    # Retrieve top class names
                    top_class_names = [loaded_class_names[idx] for idx in top_indices[0]]

                    for i, class_name in enumerate(top_class_names):
                        if class_name is not np.nan:
                            if a[i] > 0:
                                r_all = []
                                for element in keys:
                                    element_split = element.split('_')
                                    if element_split[0].lower() == class_name:
                                        if not best_in_class:
                                            
                                            component_keys.append(element)
                                            component_shift.append(shift_)
                                            distances_.append(a[i])
                                            
                                            
                                            y_a = np.interp(x_a - shift_, x_a, np.asarray(dbname[element], dtype=float), left=0, right=0)
                                            test_return_y = np.interp(x_a, np.asarray(x, dtype=float), np.asarray(y, dtype=float), left=0, right=0)
                                            basis_vectors.append(np.nan_to_num(y_a/np.nanmax(y_a)))
                                        else:
                                            r = abs(rm.ReadWrite5().pairwise_correlation(test_1_y_0, dbname[element])[0])
                                            r_all.append({'r-factor': r, 'key': element})

                                if best_in_class and r_all:
                                    max_item = max(r_all, key=lambda xx: xx['r-factor'])
                                    component_keys.append(max_item['key'])
                                    component_shift.append(shift_)
                                    distances_.append(max_item['r-factor'])
                                
                                    test_return_y = np.interp(x_a, np.asarray(x, dtype=float), np.asarray(y, dtype=float), left=0, right=0)
                                    y_a = np.interp(x_a - shift_, x_a, np.asarray(dbname[max_item['key']], dtype=float), left=0, right=0)
                                    basis_vectors.append(np.nan_to_num(y_a/np.nanmax(y_a)))
            return basis_vectors, component_keys, component_shift, distances_, test_return_y, x_a
    
    def _perform_least_squares_simple(self, y, basis_vectors, db_meta, threshold = 0, dbname = None):
        A = np.column_stack(basis_vectors) if basis_vectors else np.zeros((len(y), 0))
        while True:
            coeffs, residuals, *_ = scipy.linalg.lstsq(A, y, cond=self.cond)
            #coeffs, residuals = scipy.optimize.nnls(A, y)
            mask = coeffs > threshold        
            if mask.all():
                break           
            # Фильтрация компонентов ниже порога
            A = A[:, mask]
            coeffs = coeffs[mask]
            db_meta = [m for m, valid in zip(db_meta, mask) if valid]
            basis_vectors = [v for v, valid in zip(basis_vectors, mask) if valid]
        
        # Расчет общего R-квадрата
        reconstructed = A @ coeffs
        r_value = np.corrcoef(reconstructed, y)[0, 1]
        r_squared = abs(r_value)
        return db_meta, coeffs, basis_vectors, r_squared
    
    def _process_spectrum_simple(self, x, y, dblist=None, 
                        key_list = None,
                        start_time=None,
                        threshold=0,
                        normalize_search=False,  
                        dbname = None, shift_data = None,            
                        ):
            # Инициализация
            y = np.nan_to_num(np.asarray(y, dtype=float))
            y /= np.nanmax(y)  # Нормализация целевого спектра
        
            # Загрузка ключей баз данных
            with rm.h5py.File(self.dbname, 'r') as f:
                keys = key_list if key_list else list(f.keys())
            basis_vectors, db_meta = self._select_basis_vector_simple(x, keys = keys, 
                                                                dbname = dbname, 
                                                                dblist = dblist, 
                                                                shift_data = shift_data, 
                                                                normalize_search =normalize_search)
            
            db_meta, coeffs, basis_vectors, r_squared = self._perform_least_squares_simple(y, basis_vectors, db_meta, threshold = threshold)

            results = []
            for (key, db_path, shift), coeff, vec in zip(db_meta, coeffs, basis_vectors):
                with rm.h5py.File(db_path, 'r') as f:
                    #metadata = get_info_from_db(f, key, strunz, minlist, formula, chem_elements)
                    metadata = self.get_info_from_db(f, key=key)

                metadata.update({
                    #'x': x,
                    #'y': y,
                    'R-factor': round(coeff * np.max(vec), 3),
                    'R-square': f"{r_squared:.4f}",
                    'phase_y': vec * coeff,
                    'dbname': db_path,
                    'shift': shift
                })
                results.append(metadata)
            
            return results, tm.time() - start_time 
    def get_info_from_db(self,
        database=None,
        key=None
    ):
        """Retrieve mineral information from a database entry with enhanced metadata.

        Args:
            database: Database handle (h5py or similar).
            key: Primary key for the database entry.

        Returns:
            Dictionary with mineral metadata.

        Raises:
            ValueError: If key is not provided.
        """
        strunz_ = ''
        formula_ = ''
        chem_elements_ = ''
        mineral_id = ''   
        hyperlinks = []  
        comments = ''
        status = ''
        wavelength = ''   
        if database is None:
            mineral_name = key
            key = ''
        else:
            if key is None:
                raise ValueError("A valid database key must be provided")
            attrs = database[key].attrs
            # Initialize core metadata
            name = attrs.get("name", "")
            # Extract ID and hyperlinks from key
            key_split = name.split('_')
            if len(key_split) > 1:
                mineral_name, mineral_id = key_split[0], key_split[1]
            else:
                mineral_name = name
            
            # Map prefixes to URL templates
        link_templates = {
                'rruf': ('[RRUFF](https://rruff.info/{})', mineral_id),
                'rod': ('[ROD](https://solsa.crystallography.net/rod/{}.html)', mineral_id),
                'fmm': ('[FMM](https://fmm.ru/{})', mineral_id.replace('-', '_'))
            }
        for item in ['rruf', 'rod']:
            if item in key:
                link, value = link_templates[item]
                hyperlinks.append(link.format(value))
        if 'fmm' in key:
            for item in ['FMM', 'FN']:
                if item in mineral_id:
                    link, value = link_templates['fmm']
                    hyperlinks.append(link.format(value))

        # Add Mindat/Webmin links if mineral is found
        if self.minlist:
            minlist = [m.lower() for m in self.minlist]
            clean_name = mineral_name.translate(str.maketrans('', '', '()-')).lower()
            
            try:
                idx = minlist.index(mineral_name.lower())
            except ValueError:
                try:
                    idx = minlist.index(clean_name)
                except ValueError:
                    idx = None
            
            if idx is not None:
                safe_name = mineral_name.replace('(', '%28').replace(')', '%29')
                hyperlinks.extend([
                    f'[Mindat](http://www.mindat.org/search.php?name={safe_name})',
                    f'[WebMin](https://www.webmineral.com/data/{safe_name}.shtml)'
                ])
                
                # Get classification data if available
                if self.strunz and idx < len(self.strunz):
                    strunz_ = self.strunz[idx]
                if self.formula and idx < len(self.formula):
                    # formula_ = ChemicalFormatter().format(formula[idx])
                    formula_ = self.formula[idx]
                if self.chem_elements and idx < len(self.chem_elements):
                    chem_elements_ = self.chem_elements[idx]

        # Fallback to direct attributes if no list data
        if database:
            status = ['Proceed', 'RAW', 'Proceed'][attrs.get("status", 1)]
            comments = attrs.get("comments", "")
            wavelength = attrs.get("wavelength", "")
            if not formula_:
                # formula_ = ChemicalFormatter().format(attrs.get("formula", ""))
                formula_ = attrs.get("formula", "")
            if not strunz_:
                strunz_ = attrs.get("strunz", "")
            if chem_elements_:
                chem_elements_ = attrs.get("elements", "")

        return {
            'name': mineral_name,
            'id': mineral_id,
            'hyperlink': ' '.join(hyperlinks),
            'wavelength': wavelength,
            'strunz': strunz_,
            'formula': formula_,
            'elements': chem_elements_,
            'key': key,
            'status': status,
            'comments': comments
        }

    def find_dl(self, x, y, session = None, loaded_class_names = None, best_in_class = True):
        if self.dbname is None:
                    raise ValueError("Database must be provided")    
        if session is not None:
            session = onnxruntime.InferenceSession(session)   
            #index = faiss.read_index(index_file)
            founded_names = []
            start_time = tm.time()
            x, y, shift_list = self._init_data(x, y, self.shift)
        
            with rm.h5py.File(self.dbname, 'r') as f:
                ls = list(f.keys())
                x_min = f[ls[0]].attrs['xmin']
                x_max = f[ls[0]].attrs['xmax']
                npoints = f[ls[0]].attrs['npoints']
                        #npoints =750            
                x_a = np.linspace(x_min,x_max, npoints)               
                for shift_ in shift_list:
                    x_ = x + shift_    
                    test_1_y_0=np.interp(x_a, np.asarray(x_, dtype=float), np.asarray(y, dtype=float), left = 0, right = 0)
                    test_1_y = torch.from_numpy(test_1_y_0)
                    test_1_y = test_1_y.unsqueeze(0) 
                    test_1_y = test_1_y.unsqueeze(0).permute(1, 0, 2)
                    test_1_y = test_1_y.to(torch.float32) 
                    # Преобразование в NumPy массив для передачи в модель ONNX
                    test_1_y_np = test_1_y.numpy()
                    # Получаем имя входного узла
                    input_name = session.get_inputs()[0].name
                    # Выполнение предсказания
                    outputs = session.run(None, {input_name: test_1_y_np})
                    # Предполагая, что последний узел в модели - это логиты
                    logits = outputs[0]
                    # Применяем softmax для получения вероятностей
                    probabilities = torch.softmax(torch.tensor(logits), dim=1)
                    
                    # Получаем индексы топ-5 классов для каждого примера
                    a, top_indices = torch.topk(probabilities, k=self.number_pr)

                    # Преобразование индексов в NumPy для дальнейшего использования, если необходимо
                    
                        
                    top_indices = top_indices.cpu().numpy()
                    a = a.cpu().numpy()[0]
                    # Вывод предсказанных классов
                    # print("Top-5 предсказанные классы:", top_indices)
                    top_class_names = [[loaded_class_names[idx] for idx in indices] for indices in top_indices]
                    top_class_names = top_class_names[0]
                    
                    # print(top_class_names)
                    
                    for i, classes in enumerate(top_class_names):
                        
                        if classes is not np.nan:
                            r_all = []
                            #print(classes)
                            if self.minlist:
                                if a[i]>0:
                                        for  elements in ls:
                                            b = elements.split('_')
                                            if b[0].lower() == classes:
                                                if not best_in_class:
                                                    d_ = self.get_info_from_db(f, key = elements)   
                                                    d_['R-factor'] = a[i]
                                                    d_['dbname'] = self.dbname
                                                    d_['shift'] = shift_
                                                    founded_names.append(d_)

                                                else:
                                                    r = abs(rm.ReadWrite5().pairwise_correlation(test_1_y_0, f[elements])[0])
                                                    r_all.append({'r-factor': r, 'key': elements})
                                        if best_in_class:
                                            if len(r_all):
                                                max_item = max(r_all, key=lambda xx:xx['r-factor'])
                                                d_ = self.get_info_from_db(f, key = max_item['key'])   
                                                d_['R-factor'] = max_item['r-factor']
                                                d_['dbname'] = self.dbname
                                                d_['shift'] = shift_
                                                founded_names.append(d_)                 
            t_ = tm.time()-start_time                 
            return  founded_names, t_  

    def find_mix_alldb(self,
        x,
        y,
        dbname=os.path.join('.', 'databases', 'excellent-raman-rruf.h5'),
        key_list=None,
        threshold=0,
        normalize_search=False, shift_data = None,
        dblist=None
    ):
        """Находит спектральные компоненты в базах данных, используя метод наименьших квадратов."""
        start_time = tm.time()
        start_time = tm.time()
        # x = np.array(x)
        # y = np.array(y)
        with rm.h5py.File(dbname, 'r') as db:
                return self._process_spectrum_simple(
                    x=np.asarray(x, dtype=float),
                    y=np.nan_to_num(np.asarray(y, dtype=float)),
                    dblist=dblist,
                    key_list = key_list,
                    start_time=start_time,
                    threshold=threshold,
                    normalize_search=normalize_search, shift_data = shift_data,
                    dbname = self.dbname
                    ) 
                
    def _select_basis_vector_simple(self, x, keys = None, dbname = None, dblist = None, shift_data = None, normalize_search =False):
        basis_vectors, db_meta = [], []
        for idx, key in enumerate(keys):
            # Обработка разных баз данных и сдвигов
            current_db, current_key, shift = process_db_metadata(
                dbname, dblist, shift_data, idx, key
            )
            
            # Загрузка данных
            x_db, y_db = load_spectrum(current_db, current_key)
            x_db -= shift
            
            # Интерполяция и нормализация
            interp_y = np.interp(x, x_db, np.nan_to_num(y_db), left=0, right=0)
            if normalize_search:
                interp_y = np.nan_to_num(normalize_min_max(interp_y))
            
            if np.nanmax(interp_y) > 0:
                basis_vectors.append(np.nan_to_num(interp_y / np.nanmax(interp_y)))
                db_meta.append((current_key, current_db, shift))
        return basis_vectors, db_meta  
    
    def _format_results(self,
        db: rm.h5py.File,
        component_keys: List[str],
        coefficients: np.ndarray,
        basis_vectors: List[np.ndarray],
        x: np.ndarray,
        y: np.ndarray,
        dbname: str,
        start_time: float,
        shift = None
    ) -> Tuple[List[Dict[str, Any]], float]:
        """Formats results into output dictionaries"""
        results = []
        #baseline = coefficients[-1]
        
        sum_ = 0
        for vec, coeff in zip(basis_vectors, coefficients):
            if coeff >0:
                sum_ = sum_ + vec * coeff*np.nanmax(vec)
        
        r_2 = abs(rm.ReadWrite5().pairwise_correlation(sum_, y)[0])
        for idx, (key, coeff, shift_) in enumerate(zip(component_keys, coefficients, shift)):
        
            if coeff>0:
                component_data = self.get_info_from_db(
                    db, key=key
                )

                component_data.update({
                    'R-factor': round(coeff, 3),# * basis_vectors[idx], 3),
                    'R-square': round(r_2, 4),
                    'x': x,
                    'y': y,
                    'phase_y': basis_vectors[idx] * coeff,
                    'dbname': dbname,
                    'shift': shift_,
                })

                results.append(component_data)

        return results, tm.time() - start_time
    def find_mix(self,
        x: np.ndarray,
        y: np.ndarray,
        index_file: str,
        nprobe: int = DEFAULT_PROBE,
        ef: int = DEFAULT_EF
    ) -> Tuple[List[Dict[str, Any]], float]:
        """
        Identifies mixture components in spectra using deep learning phase search and least squares fitting.

        Args:
            x (np.ndarray): X-coordinates of the experimental spectrum
            y (np.ndarray): Y-values of the experimental spectrum
            index_file (str): Path to FAISS index file
            dbname (str): Path to HDF5 database file
            number (int): Maximum number of candidate components to consider
            strunz: Filter by Strunz classification
            minlist: Filter by mineral list
            formula: Filter by chemical formula
            chem_elements: Filter by chemical elements present
            nprobe: FAISS search parameter
            ef: FAISS search parameter
            shift: Baseline shift parameter

        Returns:
            Tuple containing:
            - List of component dictionaries with metadata and fitting results
            - Total processing time in seconds

        Raises:
            ValueError: For invalid inputs or no components found
            RuntimeError: For database access or numerical computation issues
        """
        start_time = tm.time()
        with rm.h5py.File(self.dbname, 'r') as db:
                return self._process_spectrum(
                    x=np.asarray(x, dtype=float),
                    y=np.asarray(y, dtype=float),
                    db=db,
                    index_file=index_file,
                    nprobe=nprobe,
                    ef=ef,
                    start_time=start_time)
                
    def _process_spectrum(self,
        x: np.ndarray,
        y: np.ndarray,
        db: rm.h5py.File = None,
        index_file: str = None,
        nprobe: int = DEFAULT_PROBE,
        ef: int = DEFAULT_EF,
        start_time: float = 0,
        debug = False
    ) -> Tuple[List[Dict[str, Any]], float]:
        """Core processing logic for spectral analysis"""
        db_keys = list(db.keys())
        x, y, shift_list = self._init_data(x, y, self.shift)
        basis_vectors = [] 
        component_keys = []
        component_shift = []
        final_keys = []
        final_shift = []
        final_vectors = []
        final_coeffs = []
        y_max = 1
        y_init = y
        x_init = x
                # Create a figure containing a single Axes.

        for i in range(self.deep_num+1): 
            y_max = 1 #np.nanmax(y_init)
            for shift_ in shift_list:
                
                
                # Phase 1: Basis vector selection
                x_, y_, min_x, max_x = data_arange_faiss(x_init + shift_, y_init, db)
                basis_vectors_, component_keys_, component_shift_,_ = self._select_basis_vectors_faiss(x=x_-shift_,
                        y=y_,
                        db=db,
                        db_keys=db_keys,
                        index_file=index_file,
                        nprobe=nprobe,
                        ef=ef, shift = shift_
                    )              
                basis_vectors.extend(basis_vectors_)
                component_keys.extend(component_keys_)
                component_shift.extend(component_shift_)
            x_init, y_init, min_x, max_x = data_arange_faiss(x_init, y_init, db)
            # Phase 2: Least squares fitting

            if basis_vectors:
                coefficients, basis, keys, shifts = self._perform_least_squares(
                    basis_vectors=basis_vectors, basis_keys = component_keys, basis_shift = component_shift,
                    y=y_init
                )
                
                if len (basis):
                    coefficients = np.nan_to_num(coefficients)
                    j=np.argmax(coefficients)
                    final_vectors.append(basis[j])
                    final_keys.append(keys[j])
                    final_shift.append(shifts[j])
                    final_coeffs.append(coefficients[j]*y_max)
                    if i:
                        y_init = y_init - basis[j]*coefficients[j]
                        
                    else:
                        y_init = y_init - basis[j]
                    if debug:
                        np.savetxt(f'{i}. Spectra-faiss_{round(y_max,3)}_{keys[j][:5]}.txt',np.c_[x_init, y_init, basis[j]])     
                    y_init[y_init<0] = 0
                # Plot some data on the Axes.
                #np.savetxt(f'test_{i}-after.txt',  np.c_[x_init,y_init], delimiter='\t') 
                
                basis_vectors = [] 
                component_keys = []
                component_shift = [] 
        x_init, y_init, min_x, max_x = data_arange_faiss(x, y, db)  
        
        if len(basis):     
            final_vectors.extend(basis)
            final_keys.extend(keys)
            final_shift.extend(shifts)
            final_coeffs.extend(coefficients)    
            # Phase 3: Result formatting
        
        return self._format_results(
                db=db,
                component_keys=final_keys,
                coefficients=final_coeffs,
                basis_vectors=final_vectors,
                x=x_init,
                y=y_init,
                dbname=db.filename,
                shift=final_shift,
                start_time=start_time
            )
    def _select_basis_vectors_faiss(self,
        x: np.ndarray,
        y: np.ndarray,
        db: rm.h5py.File = None,
        db_keys: List[str] = None,
        index_file: str = None,
        nprobe: int = DEFAULT_PROBE,
        ef: int = DEFAULT_EF,
        shift = None
    ) -> Tuple[List[np.ndarray], List[str]]:
        """Selects relevant basis vectors through iterative FAISS search"""
        basis_vectors = []
        component_keys = []
        component_shift = []
        seen_components = set()
        filter_ids = []
        iteration_limit = min(MAX_ITERATIONS, self.number_pr)
        distances_ = []
        for _ in range(iteration_limit):
            y_ = np.nan_to_num(y/np.nanmax(y)) if np.nanmax(y) else y*0
            distances, indices = self.faiss_search(
                y_, 
                index_file=index_file,
                filter_out=filter_ids,
                nprobe=nprobe, 
                ef=ef
            )

            if not indices.size:
                break
        

            for g, idx in enumerate(indices[0][:self.number_pr]):
                if idx >= len(db_keys):
                    continue
                
                key = db_keys[idx]
                component_name = key.split('_')[0]
                
                if component_name not in seen_components:
                    if distances[0][g]>0:
                        seen_components.add(component_name)
                        component_keys.append(key)
                        distances_.append(distances[0][g])
                        if shift:
                            spectrum = np.interp(x-shift, x, np.asarray(db[key], dtype=np.float32), left=0, right=0)
                        else:
                            spectrum = np.asarray(db[key])                  
                        basis_vectors.append(np.nan_to_num(spectrum/np.nanmax(spectrum)))
                        component_shift.append(shift)
                        if component_name == component_keys[0].split('_')[0]:
                            filter_ids.append(idx)
        return basis_vectors, component_keys, component_shift, distances_


    def _perform_least_squares(self,
        basis_vectors: List[np.ndarray],
        basis_keys: List[str],
        basis_shift: List[int],
        y: np.ndarray
    ) -> Tuple[np.ndarray, float]:
        """Performs constrained least squares fitting"""
        if not basis_vectors:
            raise ValueError("No basis vectors found for fitting")
        y_normalized = y
        #y_normalized = np.nan_to_num(y / np.nanmax(y)) if np.nanmax(y) else y*0
        # Add baseline term
        basis_matrix = np.column_stack(np.nan_to_num(basis_vectors))
        flag = True
        while flag:
                coeffs, residuals, _, _, = scipy.linalg.lstsq(basis_matrix, y_normalized, overwrite_a=False, overwrite_b=False, cond = self.cond)
                #coeffs, residuals = scipy.optimize.nnls(basis_matrix, y_normalized)
                vect_tmp = []
                key_tmp = []
                shift_tmp = []
                flag = False
                counter_ = 0
                ## # # print(coeffs)
                max_count = len(coeffs)-1
                
                for count, item in enumerate(coeffs):
                        if item > 0:
                            vect_tmp.append(basis_vectors[count])
                            key_tmp.append(basis_keys[count])
                            shift_tmp.append(basis_shift[count])
                            counter_ = counter_ +1
                        else:
                            flag = True
                if flag:
                    basis_keys = key_tmp
                    basis_vectors = vect_tmp
                    basis_shift = shift_tmp
                    if len(basis_vectors):
                        basis_matrix = np.column_stack(basis_vectors)
                    else:
                        coeffs = []
                        basis_keys = []
                        flag = False
        return np.asarray(coeffs), np.asarray(basis_vectors), basis_keys, basis_shift
    def _init_data(self, x: List[float],
                y: List[float], shift: int):
        """
        Init  x and y input arrays and generates list of shifts
        Args:
            x (list): array of x-coordinates
            y (list): array of y-coordinates
            shift (int): value of shift
        Returns:
            x (ndarrays)
            y (ndarrays)
            shift_list: list of shifts from - shift to + shift
        """
        if shift == 0:
            shift_list = [0]
        else:
            shift_list = list(range(-shift, shift + 1, 2))
        x = np.asarray(x)
        y = np.asarray(y)
        return x, y, shift_list    
                
    def find_ml(self,
        x: np.ndarray,
        y: np.ndarray,
        index_file: Optional[str] = None,
        doubles: bool = False,
        nprobe: int = DEFAULT_PROBE,
        ef: int = DEFAULT_EF
    ) -> Tuple[List[Dict[str, Any]], float]:
        """
        Searches a mineral database using FAISS for entries similar to the provided coordinates,
        applying various filters to refine results.

        Args:
            x (np.ndarray): array of x-coordinates
            y (np.ndarray): array of y-coordinates
            index_file (str): Path to the FAISS index file. Required for the search.
            dbname (str): Path to the HDF5 database file. Defaults to './/databases//excellent-raman-rruf.h5'.
            doubles (bool): If True, exclude entries with duplicate names. Defaults to False.
            nprobe (int): FAISS parameter controlling the number of probes during search. Defaults to 128.
            ef (int): FAISS parameter controlling the search depth. Defaults to 64.

        Returns:
            Tuple[List[Dict[str, Any]], float]: A list of dictionaries containing result entries and the elapsed time.

        Raises:
            ValueError: If `index_file` is not provided.
            RuntimeError: If an error occurs during the search process.
        """
        if index_file is None:
            raise ValueError("The 'index_file' parameter must be provided.")

        start_time = tm.time()
        found_results = []
        seen_names = set()
        x, y, shift_list = self._init_data(x, y, self.shift)

        with rm.h5py.File(self.dbname, 'r') as db:
                for shift_ in shift_list:
                    keys = list(db.keys())
                    x_, y_, min_x, max_x = data_arange_faiss(x+shift_ , y, db)
                    basis_vectors_, component_keys_, component_shift_, distances_ = self._select_basis_vectors_faiss(x=x_-shift_,
                            y=y_,
                            db=db,
                            db_keys=keys,
                            index_file=index_file,
                            nprobe=nprobe,
                            ef=ef, shift = shift_
                        )                

                    results_count = min(len(component_keys_), self.number_pr)
                    
                    for i in range(results_count):
                            distance = distances_[i]
                            #print(distance)
                            # Skip if distance is non-positive (if applicable)
                            if distance <= 0:
                                continue



                            entry_key = component_keys_[i]
                            # Retrieve and filter entry information
                            entry_data = self.get_info_from_db(
                                db, key=entry_key
                            )

                            if not entry_data:
                                continue  # Skip if entry doesn't meet filters

                            entry_name = entry_data.get('name')
                            # Handle duplicate exclusion
                            if doubles:
                                if entry_name in seen_names:
                                    continue
                                seen_names.add(entry_name)

                            # Augment entry data with additional information
                            entry_data.update({
                                'R-factor': f"{distance:.2f}",
                                'dbname': self.dbname,
                                'shift': shift_
                            })
                            found_results.append(entry_data)
        elapsed_time = tm.time() - start_time
        return found_results, elapsed_time  



class ChemicalFormatter:
    def __init__(self):
        self.superscript_map = {
            '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
            '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹',
            '+': '⁺'
        }
        
        self.subscript_map = {
            '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄',
            '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉'
        }
        
        self.patterns = {
            'quotes': re.compile(r'[\'"]'),
            # Обновленный паттерн: захватываем число и H2O, игнорируя пробелы между ними
            'h2o': re.compile(r'(\d+\.?\d*)*(H)(2)(O)', re.I),
            'box': re.compile(r'\s*box\s*([\d.]*)', re.I),
            'digits_plus': re.compile(r'(\d+\.?\d*)(\+)'),
            # Обновленный паттерн для исключения чисел перед H₂O
            'plain_digits': re.compile(r'(?<!⋅)(\d+\.?\d*)(?![⋅]*H₂O)')
        }
    def _convert_superscript(self, match):
        # Без изменений
        digits = match.group(1)
        plus = match.group(2)
        converted = [self.superscript_map[c] if c in self.superscript_map else c for c in digits]
        return ''.join(converted) + self.superscript_map[plus]

    def _process_h2o(self, text):
        def replacer(m):
            # Добавляем символ умножения перед числом и преобразуем H2O
            number = m.group(1)
            if number is None:
                number=''
            h = m.group(2)
            two = self.subscript_map['2']
            o = m.group(4)
            return f'⋅{number}{h}{two}{o}'
        
        return self.patterns['h2o'].sub(replacer, text)

    def _process_non_bracketed(self, text):
        # Сначала обрабатываем H₂O
        text = self._process_h2o(text)
        
        # Затем обрабатываем цифры с плюсом
        text = self.patterns['digits_plus'].sub(self._convert_superscript, text)
        
        # Преобразуем оставшиеся цифры в нижний индекс
        text = self.patterns['plain_digits'].sub(
            lambda m: ''.join(self.subscript_map[c] if c.isdigit() else c 
                            for c in m.group(1)),
            text
        )
        
        # Обработка box
        text = self.patterns['box'].sub(
            lambda m: '□' + ''.join(
                self.subscript_map[c] if c.isdigit() else c 
                for c in m.group(1)
            ),
            text
        )
        
        return text

    def _process_bracketed(self, text):
        # Box внутри скобок
        text = self.patterns['box'].sub(
            lambda m: '□' + ''.join(
                self.subscript_map[c] if c.isdigit() else c 
                for c in m.group(1)
            ),
            text
        )
        
        # Цифры внутри скобок
        def replace(m):
            num, plus = m.group(1), m.group(2)
            converter = self.superscript_map if plus else self.subscript_map
            return ''.join(
                converter[c] if c in converter else c 
                for c in num
            ) + (self.superscript_map['+'] if plus else '')
        
        return re.sub(r'([\d.]+)(\+)?', replace, text)

    def format(self, s):
        s = self.patterns['quotes'].sub('', s)
        
        result = []
        current_chunk = []
        in_brackets = False
        
        for char in s:
            if char in '([':
                if current_chunk:
                    part = ''.join(current_chunk)
                    processed = self._process_bracketed(part) if in_brackets else self._process_non_bracketed(part)
                    result.append(processed)
                    current_chunk = []
                result.append(char)
                in_brackets = True
            elif char in ')]':
                if current_chunk:
                    part = ''.join(current_chunk)
                    processed = self._process_bracketed(part)
                    result.append(processed)
                    current_chunk = []
                result.append(char)
                in_brackets = False
            else:
                current_chunk.append(char)
        
        if current_chunk:
            part = ''.join(current_chunk)
            processed = self._process_bracketed(part) if in_brackets else self._process_non_bracketed(part)
            result.append(processed)
        
        return ''.join(result)

def perpendicular_distance(point, start, end):
    """Calculate the perpendicular distance from a point to a line segment."""
    if np.array_equal(start, end):
        return np.linalg.norm(point - start)
    # Vector from start to end
    line_vec = end - start
    # Vector from start to point
    point_vec = point - start
    # Project point_vec onto line_vec to find the closest point on the line
    line_len_squared = np.dot(line_vec, line_vec)
    t = np.dot(point_vec, line_vec) / line_len_squared
    # Clamp t to the range [0, 1]
    t = max(0, min(1, t))
    closest_point = start + t * line_vec
    return np.linalg.norm(point - closest_point)

def rdp(x: np.array, y: np.array, epsilon: float):
    """Apply the Ramer-Douglas-Peucker algorithm to simplify a curve."""
    points = np.vstack((x, y)).T  # Combine x and y into a single array of points
    n = points.shape[0]
    if n < 3:
        return points[:, 0], points[:, 1]  # Not enough points to simplify
    # Initialize the list of indices of the points to keep
    keep = np.zeros(n, dtype=bool)
    keep[0] = True  # Always keep the first point
    keep[-1] = True  # Always keep the last point
    # Recursive function to find points to keep
    def rdp_recursive(start, end):
        max_dist = 0.0
        index = -1
        # Check the distance of each point to the line segment
        for i in range(start + 1, end):
            dist = perpendicular_distance(points[i], points[start], points[end])
            if dist > max_dist:
                max_dist = dist
                index = i
        # If the maximum distance is greater than epsilon, keep the point
        if max_dist > epsilon:
            keep[index] = True
            # Recur on the two halves
            rdp_recursive(start, index)
            rdp_recursive(index, end)
    rdp_recursive(0, n - 1)
    return points[keep].T

def arange_x(x, y, interpolation = False, step = 1):
    indices = sorted(range(len(x)), key=lambda i: x[i])
    # Применяем перестановку к обоим массивам
    x_sorted = np.asarray([x[i] for i in indices], dtype=np.float32)
    y_sorted = np.asarray([y[i] for i in indices], dtype=np.float32)
    if interpolation:
        #np.interp(x-shift, x, np.asarray(db[key], dtype=np.float32), left=0, right=0)
        x_interpolate = np.arange(x_sorted[0],x_sorted[-1], step)       
        y_interpolate = np.interp(x_interpolate, x_sorted, y_sorted, left=0, right=0)
        return x_interpolate, y_interpolate
    return x_sorted, y_sorted

def spike_removal(y, width_threshold, prominence_threshold, moving_average_window=10,
                  width_param_rel=0.01, interp_kind='linear'):
    """
    Detects and replaces spikes in the input spectrum signal with interpolated values.
    
    Based on the publication by N. Coca-Lopez "An intuitive approach for spike removal in Raman spectra 
    based on peaks’ prominence and width" https://doi.org/10.1016/j.aca.2024.342312

    Parameters:
    y (numpy.ndarray): Input signal array.
    width_threshold (float): Threshold for peak width.
    prominence_threshold (float): Threshold for peak prominence.
    moving_average_window (int): Number of points in moving average window.
    width_param_rel (float): Relative height parameter for peak width.
    interp_kind (str): Type of interpolation ('linear', 'quadratic', 'cubic').

    Returns:
    numpy.ndarray: Signal with spikes replaced by interpolated values.
    """
    peaks, _ = find_peaks(y, prominence=prominence_threshold)
    #print(peaks)
    spikes = np.zeros(len(y))
    widths = peak_widths(y, peaks)[0]
    #print(widths)
    widths_left_end, widths_right_end = peak_widths(y, peaks, rel_height=width_param_rel)[2:4]
    for a, width, ext_a, ext_b in zip(range(len(widths)), widths, widths_left_end, widths_right_end):
        if width <= width_threshold:
            spikes[int(ext_a) - 1:int(ext_b) + 2] = 1
    y_out = copy.deepcopy(y)
    for i, spike in enumerate(spikes):
        if spike:
            window = np.arange(max(i - moving_average_window, 0), min(i + moving_average_window+1, len(y)))
            window_exclude_spikes = window[spikes[window] == 0]
            if len(window_exclude_spikes)>1:
                interpolator = interpolate.interp1d(window_exclude_spikes, y[window_exclude_spikes], kind=interp_kind,bounds_error = False, fill_value="extrapolate")
                y_out[i] = interpolator(i)
            else:
                i = i-1
    return y_out
      

   

def data_arange_faiss(x, y, database = None):
    x = np.asarray(x, dtype=np.float32)
    y = np.asarray(y, dtype=np.float32)
    if x.ndim != 1 or y.ndim != 1:
        raise ValueError("Error in arange. x and y must be 1D arrays")
    if len(x) != len(y):
        raise ValueError("Error in arange. x and y must have the same length")
    # Sort input points by x-values
    sort_idx = np.argsort(x)
    x_sorted = x[sort_idx]
    y_sorted = y[sort_idx]

    # Get database parameters
    keys = list(database.keys())
    params = database[keys[0]].attrs
    x_min, x_max, npoints = params['xmin'], params['xmax'], params['npoints']

    # Create interpolation grid
    x_a = np.linspace(x_min, x_max, npoints, dtype=np.float32)
    dY = np.interp(x_a, x_sorted, y_sorted, left=0, right=0)
    min_x, max_x = (x[0], x[-1]) if x[0] < x[-1] else (x[-1], x[0])
    min_idx = find_closest(x, min_x)
    max_idx = find_closest(x, max_x)
    return x_a, dY, min_idx, max_idx    

    
                             
# def faiss_search(x, y, database = None, index_file = None, number = 10, filter_out = [], nprobe = 128, ef = 64 ):
#         """
#         Search using Faiss
#         """
#         if database is None:
#             raise 'No database is selected!'
#         if index_file is None:
#             raise 'No index is selected!'
#         ls = list(database.keys())
#         # x_min = f[ls[0]].attrs['xmin']
#         # x_max = f[ls[0]].attrs['xmax']
#         # npoints = f[ls[0]].attrs['npoints']
#         # step = (x_max - x_min) / (npoints - 1) 
#         x_min = database[ls[0]].attrs['xmin']
#         x_max = database[ls[0]].attrs['xmax']
#         npoints = database[ls[0]].attrs['npoints']
#         x_a = np.linspace(x_min,x_max, npoints)
#         step = round((x_max - x_min) / (npoints - 1), 1)  
#         # # # # print(f'Step: {step} xmin {x_min} xmax{x_max}')               
#         #x_a = np.arange(params['xmin'], params['xmax'], params['step'])
#         #x_a = np.arange(x_min, x_max, step)
#         dY = np.interp(x_a, np.array(x, dtype=float), np.array(y, dtype=float), left = 0, right = 0)
#         # # # # print(f'Step: {step} xmin {x_min} xmax {x_max} length {len(dY)}')    
#         dbY = np.vstack(dY).T
#         faiss.downcast_index(index_file.index).nprobe = nprobe
#         faiss.downcast_index(index_file.index).efSearch	 = ef
#         # index_file.hnsw.efSearch =128
#         #index_file.nprobe = 128
#         #index_file.efSearch = 64
#         if len(filter_out)>0:
#             filter_ids  = [id_ for id_ in range(index_file.ntotal) if id_ not in filter_out]
#             ## # # print(len(filter_ids))
#             id_selector = faiss.IDSelectorArray(filter_ids)
#             D, I = index_file.search(dbY, number,  params=faiss.SearchParametersIVF(sel=id_selector))
#             #D, I = index_file.search(dbY, number,  params=faiss.SearchParametersHNSW(sel=id_selector))
#         else:
#             D, I = index_file.search(dbY, number)
#         return D, I, x_a, dY
#Logarithmic normalization    
def lognorm(y, threshold=None):
                        dbRead = rm.ReadWrite5()
                        if threshold is None:
                            y = dbRead.normalize_min_max(y) 
                        else:
                            y = dbRead.normalize_min_max(y, threshold)
                        del dbRead
                        return y        

def remove_main_peak(x_init, y_init, table_als, res_):
        centers_=res_
        ahead=0.5
        substr_=0.1
        y = np.asarray(y_init, dtype=float)
        y = y_init/np.nanmax(y_init)
        while not centers_['peaks']:
                                         
            if (ahead-substr_)<=substr_: 
                substr_ = substr_*0.1
            ahead=ahead-substr_
            centers_=peakdetect(x_init,y,1,ahead)
        c_={}
        c_=res_
        table_par=[]
        for i in centers_['peaks']:
            
            table_par.append({'p_center': i, 'p_amplitude': 1, 
                        'p_width': 4,'p_method': 'PseudoVoigt', 'l_center_min': 5, 
                        'l_center_max': 5, 'l_amplitude_min': 0, 'l_amplitude_max': 100, 
                        'l_width_min': 0.2, 'l_width_max':5
                        
                        })                   
        tolerance=1e-14
        max_nfev=500   
        data_ = fitcurve(
                            x_init,
                            y,
                            str(centers_['peaks']), 
                            parameters = table_par, 
                            parameter_als = table_als, 
                            tolerance = tolerance,
                            max_nfev=max_nfev, fit_bline = True
                        ) 
        for model_name, model_value in data_['components'].items(): 
            y = y - model_value  
                                 

              
   



def process_db_metadata(main_db, dblist, shift_data, idx, key):
    """Обрабатывает метаданные разных баз данных."""
    if not dblist:
        return main_db, key, shift_data[idx] if shift_data else 0
    
    db_entry = dblist[idx]
    if 'arange' in db_entry:
        parts = key.split('--')
        return os.path.join('.', 'databases', parts[1]), parts[0], shift_data[idx] or 0
    
    return db_entry, key, shift_data[idx] if shift_data else 0

def load_spectrum(db_path, key):
    """Загружает спектр из HDF5 файла."""
    with rm.h5py.File(db_path, 'r') as f:
        dataset = f.get(key)
        if not dataset:
            raise ValueError(f"Спектр {key} не найден в {db_path}")
        return np.asarray(dataset[0], dtype=float), np.nan_to_num(np.asarray(dataset[1], dtype=float))

def normalize_min_max(arr):
    """Нормализация массива к диапазону 0-1."""
    return (arr - np.min(arr)) / (np.max(arr) - np.min(arr) + 1e-8)
     







          
                
# def find_ml(x, y, index_file = None, dbname = './/databases//excellent-raman-rruf.h5', number = 10, strunz = None, minlist = None, formula = None, chem_elements = None, doubles = False, nprobe = 128, ef = 64, shift = 0):
#     if index_file is not None:
#         #index = faiss.read_index(index_file)
       
#         start_time = tm.time()
#         f = rm.h5py.File(dbname, 'r')
#         ls = list(f.keys())
        
#         D, I, _, _ = faiss_search(x, y, database = f, index_file = index_file, number = number, nprobe = nprobe, ef =ef)
#         ## # print(I)
#         founded_names = []  
#         if len(I[0])<number:
#             number = len(I[0])
#         for i_ in range(number):
#             if D[0][i_]>0:
#                 id = I[0][i_]
#                 ## # print(id)
                
#                 key = ls[id]
#                 ## # print('_')
#                 distance = D[0][i_]
#                 data_ = get_info_from_db(f, key = key, strunz = strunz, minlist = minlist, formula = formula, chem_elements = chem_elements)
#                 data_['R-factor'] = format(distance, '.2f')
#                 data_['dbname'] = dbname
#                 data_['shift'] = shift
#                 if doubles:
#                     if any(d['name'] == data_['name'] for d in founded_names):
#                         continue
#                 founded_names.append(data_)           
#             # # # # print(f'{key} at distance {distance}') 
#         t_ = tm.time()-start_time 
#         # # # # print('Elapsed: ', t_)
#         return founded_names, t_ 
#            ## # # print(db_read[key])
          
        
         

def read_spectrum_db(db_, name_):
    dbRead = rm.ReadWrite5()
    a = dbRead.get_spectra_h5(db_, name_)
    del dbRead
    return a

def read_all_from_db(db_):
    dbRead = rm.ReadWrite5()
    a = dbRead.readh5_all_inarray(db_)
    del dbRead
    return a

def t_to_abs(y):
    return -np.log(y)

def smooth_als(y, lam, p):
    fit_ = mm.FittingMap()
    yy = fit_.__baseline_als__(y, lam, p)
    del fit_
    return yy

def smooth_sav_gol(y, box_pts):
    y_smooth = savgol_filter(y, box_pts, 2, mode='nearest')
    return y_smooth

def smooth(y, box_pts):
    box = np.ones(box_pts)/box_pts
    y_smooth = np.convolve(y, box, mode='same')
    return y_smooth

# def readfile(filename, skiprows = 1):
        
#         a = np.loadtxt(filename, skiprows=skiprows)
#         xx = np.array([], dtype=float)
#         yy = np.array([], dtype=float)
#         for item in a:
#                 xx = np.append(xx,np.float64(item[0]))
#                 yy = np.append(yy,np.float64(item[1]))
#         if (xx[0] > xx[-1]):
#                 yy = yy[::-1]
#                 xx = xx[::-1]
#         spectra = {}
#         spectra = peakdetect(xx,yy,1,0.5*np.nanmax(yy))
#         return spectra

# def readfile_jdx(filename, skiprows = 1):
#         ## # print('111')
#         d = jcamp_read(filename)
#         ## # print(d)
#         xx = np.array(d['x'], dtype=float)
#         yy = np.array(d['y'], dtype=float)
#         if (xx[0] > xx[-1]):
#                 yy = yy[::-1]
#                 xx = xx[::-1]
#         spectra = {}
#         spectra = peakdetect(xx,yy,1,0.5*np.nanmax(yy))
#         # # # print(spectra)
#         return spectra
#Extract coordinates from drawfreeform
def extract(closedpath: str, threshold = 10, use_rdp = True):
    # print(closedpath)
    path = re.split('[a-zA-Z]', closedpath)
    letters = re.sub(r'[^a-zA-Z]','', closedpath)
    path = [point for point in path if point]
    x = []
    y = []
    for point in path:
        point_x, point_y = map(float, point.split(','))
        x.append(point_x)
        y.append(point_y)
    #x = np.array(x)
    #y = np.array(y)
    if use_rdp:
        x, y = rdp(x, y, threshold) #fastrdp.rdp(x, y, threshold)
    new_path = ''
    for num, item in enumerate(x):
        new_path = new_path + f'{letters[num]}{item},{y[num]}'
    # print(string_result) 
    return x,y, new_path
#Finde closest value in array
def find_closest(A, target):
    if len(A) == 0:
       raise ValueError(f'No spectrum has been loaded')  
    idx = A.searchsorted(target)

    idx = np.clip(idx, 1, len(A)-1)
    if idx == 0:
        return 0  # Все элементы больше target
    elif idx == len(A):
        return len(A) - 1  # Все элементы меньше target
    left = A[idx-1]
    right = A[idx]
    idx -= target - left < right - target
    return idx
    #return idx - (target - left < right - target)
        
def peakdetect(xx, yy, lookahead = 1, delta = 0.011):
        #filecp = codecs.open(filename, encoding = 'utf8', errors='ignore')
    #Читаем файл с пропуском первых 9 строк, в которых нет спектра
        
    #Ограничиваем область деконволюции 650-1800 см-1
    #filtered = filter(lambda row: 650<row[0]<1800, a)
        
        fit = mm.FittingMap()
        spectra = {}
        yy = np.asarray(yy, dtype=np.float32)
        xx = np.asarray(xx, dtype=np.float32)
        #yy = yy/max(yy)
        #Функция, которая ищет максимум. lookahead - минимальная дистанция между соседними пиками. delta - минимальное значение по y. Функция выдает номера элементов массива yy, в которых она нашла максимумы
        dd = fit.peakdet(yy,lookahead = lookahead, delta = delta)
        del fit
        ampl = []
        x = []
        for each in dd:
                    ampl.append(yy[each])
                    x.append(xx[each])
                    ## # # print(xx[each],'\t',yy[each])                
        spectra['spectrum'] = [xx,yy]
        spectra['peaks'] = x
        spectra['look'] = lookahead
        spectra['delta'] = delta
        spectra['ampl'] = ampl
        spectra['flag_sub'] = False
        
        return spectra
 
def fitcurve(xx,yy,peaks_str,parameters = None, parameter_als=None, tolerance = 1e-15, max_nfev=1000, fit_bline = True):
        # start_time=time.time()
        limits = {}
        ma = {}
        i = 0  
        fname = 'ab' 
        fit = mm.FittingMap()
        params = {}
        limits = {}
        ma = {}
        i = 0  
        x = [int(i) for i in peaks_str.split(',') if i.strip().isdigit()]
        #x = peaks_str
        xx = np.asarray(xx, dtype=np.float32)
        yy = np.asarray(yy, dtype=np.float32)
        max_value = np.nanmax(yy)
        fit.Interval = 0
        if fit_bline:
            if parameter_als is None:
            
                params['baseline_auto'] = [1e7,0.005]
                limits['baseline_auto'] = [[1e5, 5e9], [0.0001, 0.1]]
                fit.Interval = 0
            else:
                ## # # print(parameter_als)
                if 'p_true' in parameter_als[0]:
                    params['p_true'] = [parameter_als[0]["p_true"], parameter_als[1]["p_true"]]
                    
                else:
                    params['p_true'] = [False, False]
                if 'lam_true' in parameter_als[0]:
                    params['lam_true'] = [parameter_als[0]["lam_true"], parameter_als[1]["lam_true"]]
                else:
                    params['lam_true'] = [False, False]
                if 'shift_true' in parameter_als[0]:
                    params['shift_true'] = [parameter_als[0]["shift_true"], False]
                else:
                    params['shift_true'] = [False, False]                    
                ## # # print(params['p_true'] )
                ## # # print(params['lam_true'] )
                ##print(parameter_als)
                params['baseline_auto'] = [float(parameter_als[0]["p_lam"]), float(parameter_als[0]["p_p"]), float(parameter_als[1]["p_lam"]), float(parameter_als[1]["p_p"])]
                if 'shift' in parameter_als[0]:
                    params['baseline_shift'] = [float(parameter_als[0]["shift"])]
                else:
                    params['baseline_shift'] = [0]
                if 'shift_min' in parameter_als[0]:
                    if 'shift_max' in parameter_als[0]:
                        limits['baseline_shift'] = [float(parameter_als[0]["shift_min"]),float(parameter_als[0]["shift_max"])]
                    else:
                        limits['baseline_shift'] = [float(parameter_als[0]["shift_min"]),10]

                else:
                    limits['baseline_shift'] = [0,10]
                    
                    
                limits['baseline_auto'] = [[float(parameter_als[0]["l_lam_min"]),float(parameter_als[0]["l_lam_max"])], [float(parameter_als[0]["l_p_min"]),float(parameter_als[0]["l_p_max"])],
                                        [float(parameter_als[1]["l_lam_min"]),float(parameter_als[1]["l_lam_max"])], [float(parameter_als[1]["l_p_min"]),float(parameter_als[1]["l_p_max"])]]
                if not (parameter_als[1]["Interval"] is None):
                    if parameter_als[1]["Interval"] != '':
                        idx = (np.abs(xx - float(parameter_als[1]["Interval"]))).argmin()
                        # # # # print('position:', idx)
                        # # # # print('length:', len(xx))
                        if idx < len(xx)-2:
                            fit.Interval = idx
        params['kws'] = {'ftol': tolerance, 'xtol': tolerance, 'gtol': tolerance}
        params['max_nfev'] = max_nfev

        if parameters is None:
            params['amplitude'] = np.full(len(x),max_value)
            params['center'] = np.asarray(x, dtype=np.float32)    
            params['width'] = np.full(len(x),4)
            params['method'] = np.full(len(x),'PseudoVoigt')
            limits['amplitude'] = np.full((len(x),2),[0,1000])
            limits['width'] = np.full((len(x),2),[0.2,40])
            limits['center'] = np.full((len(x),2),[5,5])
            
        else:
            p_center = []
            p_amplitude = []
            p_width = []
            p_method = []
            l_center = []
            l_amplitude = []
            l_width = []
            p_add_par = []
            l_add_par = []
            p_vary = []
            for item in parameters:
                if 'p_center' in item:
                    if item['p_center'] != '':
                        p_center.append(item['p_center'])
                    else:
                        p_center.append(0)
                else:
                    p_center.append(0)
                if 'p_amplitude' in item:
                    if item['p_amplitude'] != '':
                        p_amplitude.append(item['p_amplitude'])
                    else:
                        p_amplitude.append(max_value)
                else:
                    p_amplitude.append(max_value)
                if 'p_width' in item:
                    if item['p_width'] != '':    
                        p_width.append(item['p_width'])
                    else:
                        p_width.append(4)
                else:
                    p_width.append(4)
                if 'vary' in item:
                    p_vary.append(item['vary'])
                else:
                    p_vary.append(True)
                if 'p_method' in item:
                    p_method.append(item['p_method'])
                else:
                    p_method.append('PseudoVoigt')
                if 'l_center_min' in item:
                    if item['l_center_min'] != '':
                        l_c_min = item['l_center_min']
                    else:
                        l_c_min = 5
                else:
                    l_c_min = 5
                if 'l_center_max' in item:
                    if item['l_center_max'] != '':
                        l_c_max = item['l_center_max']
                    else:
                        l_c_max = 5
                else:
                    l_c_max = 5
                l_center.append([l_c_min, l_c_max])
                if 'l_amplitude_min' in item:
                    if item['l_amplitude_min'] != '':
                        l_a_min = item['l_amplitude_min']
                    else:
                        l_a_min = 0
                else:
                    l_a_min = 0
                if 'l_amplitude_max' in item:
                    if item['l_amplitude_max']:
                        l_a_max = item['l_amplitude_max']
                    else:
                        l_a_max = 1000
                else:
                    l_a_max = 1000
                l_amplitude.append([l_a_min, l_a_max])
                
                if 'l_width_min' in item:
                    if item['l_width_min'] != '':
                        l_w_min = item['l_width_min']
                    else:
                        l_w_min = 0.2
                else:
                    l_w_min = 0.2
                if 'l_width_max' in item:
                    if item['l_width_max'] != '':
                        
                        l_w_max = item['l_width_max']
                    else:
                        l_w_max = 20  
                else:
                    l_w_max = 20                
                l_width.append([l_w_min, l_w_max])
                if 'p_addit' in item:
                    if item['p_addit'] != '':
                        p_add_par.append(item['p_addit'])
                        if ('l_addit_min' in item) and ('l_addit_max' in item):
                            if item['l_addit_min'] == '':
                                l_amin = 0.1
                            else:
                                l_amin = item['l_addit_min']
                            if item['l_addit_max'] == '':
                                l_amax = 1
                            else:
                                l_amax = item['l_addit_max']
                            l_add_par.append([l_amin, l_amax])
                        else:
                            l_add_par.append([0.1, 1]) 
                    else:
                        p_add_par.append(None)
                        l_add_par.append([None, None])                           
                else:
                    p_add_par.append(None)
                    l_add_par.append([None, None])  
                      
                            
            params['center'] = np.asarray(p_center, dtype=np.float32)
            params['amplitude'] = np.asarray(p_amplitude, dtype=np.float32)
            params['width'] = np.asarray(p_width, dtype=np.float32)
            params['vary'] = np.asarray(p_vary, dtype=bool)
            for num, item in enumerate(p_method):
                if item is None:
                    p_method[num] = 'PseudoVoigt'

            params['method'] = p_method
            limits['amplitude'] = np.asarray(l_amplitude, dtype=np.float32)
            limits['width'] = np.asarray(l_width, dtype=np.float32)
            limits['center'] = np.asarray(l_center, dtype=np.float32)
            params['additional'] = np.asarray(p_add_par, dtype=np.float32)
            limits['additional'] = np.asarray(l_add_par, dtype=np.float32)
        # # # # print(params)
        # # # # print(limits) 
        # # # # print(params)
        start = time.time() 
        result = fit.fit_array(xx,yy,params,limits,fname)
        ## # print('Time: ',  time.time() - start )
        A = result['amplitude']
        FWHM = result['FWHM']
        C = result['center']
        H = result['height']
        Rsq = result['r-square']
        Sig = result['sigma']
        
        C_ = []
        H_ = []
        F_ = []
        A_ = []
        S_ = []
        # # # # print("Peak N\t"+"||\t"+"Amplitude\t"+"||\t"+"Center\t"+"||\t"+"FWHM\t"+"||\t"+"Height\t"+"\n")
        for (idx), value in np.ndenumerate(A):
                C_.append(C[idx[0]])
                H_.append(H[idx[0]])
                F_.append(FWHM[idx[0]])
                A_.append(value)
                S_.append(Sig[idx[0]])
                ## # # print(
                #      str(idx[0]+1)+"\t||\t"+
                #      value.astype('str')+"\t||\t"+
                #      C[idx[0]].astype('str')+"\t||\t"+
                #      FWHM[idx[0]].astype('str')+"\t||\t"+
                #      H[idx[0]].astype('str')
                #      )
        if 'p_1' in result:
            fit_param = {'Center':np.asarray(C_, dtype=float), 'Amplitude': np.asarray(A_, dtype=float),'Sigma': np.asarray(S_, dtype=float), 'FWHM': np.asarray(F_, dtype=float), 'Height': np.asarray(H_, dtype=float),'Method': params['method'], 'R-Square': Rsq, 'p': result['p'], 'lam': result['lam'], 'p_1': result['p_1'], 'lam_1': result['lam_1'], 'shift': result['shift']}
        else:    
            fit_param = {'Center':np.asarray(C_, dtype=float), 'Amplitude': np.asarray(A_, dtype=float),'Sigma': np.asarray(S_, dtype=float), 'FWHM': np.asarray(F_, dtype=float), 'Height': np.asarray(H_, dtype=float),'Method': params['method'], 'R-Square': Rsq, 'p': result['p'], 'lam': result['lam'], 'shift': result['shift']}
        x1 = fit.map_baseline[fname][0]
        y1 = fit.map_baseline[fname][1]
        
        
        #ddd = xx
        length_ = len(xx)
        length_2 = len(x1)
        comp_ = fit.components
        del fit
        # # # # print('Time of fitting: ', time.time()-start_time)
        #Рисуем и сохраняем кривые
        return {'input': [xx,yy], 'output': [x1, y1], 'components': comp_, 'length_in': length_, 'length_out':  length_2, 'params': fit_param, 'time': time.time() - start }


            
def find_phase(xx, yy, dbname = None, print_number = 10, sim = 0.8, wavelength=None, strunz = None, minlist = None, formula = None, chem_elements = None, key_list = None, normalize_search = False, dblist = None):
    if dbname is not None:

            # start_time=time.time()
            dbRead = rm.ReadWrite5()
            ## # # print(yy)
            spectra, time_ = dbRead.find_phase_in(xx, yy, dbname=dbname, r_ref=sim, wavelength=wavelength, key_list=key_list, normalize_search = normalize_search, dblist = dblist)
            #print(time_)
            del dbRead
            founded_names=[]
            # founded_phases=[]
            cnt_=0
            ## # # print(type(spectra))
            # print(spectra)
            if spectra:
                    ## # # print(spectra)
                    d_spectra = sorted(spectra, key=lambda d: d['r'], reverse=True)
            else:
                    return [], time_
            ## # # print(d_spectra)
            for val in d_spectra:
                dbname_ = dbname
                if '--' in val['key']:
                        from_key = val['key'].split('--')
                        #print(from_key)
                        dbname_ = './/databases//'+from_key[1]
                        val['key'] = from_key[0]  
                if cnt_<print_number:
            
                    cnt_ = cnt_+1
                    # str_ = val["name"][2:]
                    str_ = val["name"]
                    b = str_.split('_')
                    # # # # print(b)
                    name_= val["name"]
                    
                    
                    id_=""
                    hyp_=""
                    hyp_min = ''
                    if len(b)>1:
                        if 'rruf' in dbname_:
                            
                            hyp_='[RRUFF]('+'https://rruff.info/'+str(b[1].split('-')[0])+') '
                        if 'rod' in dbname_:
                            
                            hyp_='[ROD](https://solsa.crystallography.net/rod/'+str(b[1].split('.')[0])+'.html) ' 
                        if 'fmm' in dbname_:
                                if 'FMM' in b[1]:
                                            hyp_ = '[FMM](https://fmm.ru/'+str(b[1].replace('-','_'))+') '       
                        str_=b[0]+'_'+b[1]
                        id_ = b[1]
                        name_=b[0]
                    else:
                        
                        str_=val["name"]
                    
                    strunz_item = ''
                    formula_=''
                    chem_el_ = ''
                    status_db = ['Proceed', 'RAW', 'Proceed']
                    comments_ = val['comments']
                    if minlist:
                        try:    
                            minlist = [x.lower() for x in minlist]                  
                            index_ = minlist.index(name_.lower())
                            hyp_min = '[Mindat]('+'http://www.mindat.org/search.php?name='+b[0]+')'
                            strunz_item = strunz[index_]
                            # formatter = ChemicalFormatter()
                    
                            #formula_ = formatter.format(formula[index_])  
                            formula_ =  formula[index_]                            
                            #formula_ = formula[index_]
                            chem_el_ = chem_elements[index_]
                            
                            
                        except ValueError:
                            if 'chemistry' in val:
                                if val['chemistry'] != '':
                                    # formatter = ChemicalFormatter()
                    
                                    # formula_ = formatter.format(val['chemistry'])   
                                    formula_ = val['chemistry']
                            pass 
                    hyp_ = hyp_ + hyp_min
                    
                    founded_names.append({'R-factor': format(val["r"], '.4f'), 'name': name_, 'id': id_, 'hyperlink': hyp_, 'wavelength': val['wavelength'], 'strunz': strunz_item, 'formula': formula_, 'elements': chem_el_, 'dbname': dbname_, 'key': val['key'], 'status': status_db[val['status']], 'comments': comments_})
                    # founded_phases.append({'x': val["x"], 'y': val["y"], 'label': str_})
                else:
                    break
            # # # # print('Time of search: ', time.time()-start_time) 
            return founded_names, time_ #, founded_phases
    else:
            raise ValueError(f'Empty db name')             


def add_to_h5(db_name, data, params=None):
    dbWrite = rm.ReadWrite5()
    dbWrite.addtodb_h5(db_name, spectrum=data, params=params, background=False)
    del dbWrite

def add_to_h5_advanced(table_data, dat_):
    #db_name = './/databases//testing//'+db_name
    # # # print(db_name)
    ## # print(dat_)
    dbWrite = rm.ReadWrite5()
    for pars, item in zip(dat_,table_data):
       # # # print(item)
        x = item['x']
        y = item['y']
        db_name = item['dbname']
        type = 'unknown'
        if 'raman' in db_name:
            type='Raman'
        if 'atr' in db_name:
            type = 'ATR'
        if 'xrd' in db_name:
            type = 'XRD'
        if 'reflection' in db_name:
            type = 'Reflection'
        if 'ftir' in db_name:
            type = 'FTIR'
        if 'luminescence' in db_name:
            type = 'Luminescence'       
        data = [x, y]
        id = item['key']
        params = {'xmin': min(x), 'xmax': max(x), 'npoints': len(x), 'type': type}
        if item['status']=='RAW':
           status = 1
        else:
           status = 0
        params = {'xmin': min(x), 'xmax': max(x), 'npoints': len(x), 'type': type, 'status': status} 
        array_keys = ['x', 'y', 'x_prev', 'y_prev', 'key', 'status']
        for key, p in pars.items():
            
            if key not in array_keys: 
                params[key] = p
        dbWrite.addtodb_h5(db_name, spectrum=data, params=params, background=False)
    del dbWrite

def save_changes_h5(table_data, dat_):
    dbWrite = rm.ReadWrite5()
    for item in dat_:
        key_db = item['key']
        db_name = item['dbname']
        dbWrite.delete_record_h5(db_name, key_db)   
    add_to_h5_advanced(table_data, dat_)
    del dbWrite
    
def get_elements(formula):
    elements = re.findall('[A-Z][a-z]?', formula)
    elements = list(dict.fromkeys(elements))
    return " ".join(elements)

def zernike_radial(n, r):
    """
    Вычисляет радиальный полином Цернике порядка n (четного) для массива r.
    """
    if n % 2 != 0:
        raise ValueError("n должно быть четным")
    result = np.zeros_like(r)
    for k in range(0, n//2 + 1):
        numerator = factorial(n - k)
        denominator = (factorial(k) * factorial(n//2 - k)**2)
        term = (-1)**k * numerator / denominator * r**(n - 2*k)
        result += term
    return result

def zernike_baseline(x, max_order=4):
    """
    Вычисляет базовую линию для спектра x с использованием полиномов Цернике.
    
    Параметры:
    x: одномерный массив, представляющий спектр
    max_order: максимальный порядок полинома (четное число, по умолчанию 4)
    """
    n_points = len(x)
    r = np.linspace(0, 1, n_points)  # Нормализованные радиальные координаты
    
    # Создаем матрицу планирования для полиномов Цернике
    orders = range(0, max_order+1, 2)  # Только четные порядки
    A = np.zeros((n_points, len(orders)))
    
    for i, n in enumerate(orders):
        A[:, i] = zernike_radial(n, r)
    
    # Решаем задачу методом наименьших квадратов
    coefficients, _, _, _ = lstsq(A, x)
    
    # Восстанавливаем базовую линию
    baseline = A @ coefficients
    return baseline

def polynomial_baseline_correction(data, order=5, iterations=10, tolerance=1e-6):
    """
    Performs iterative polynomial baseline correction.

    Args:
        data (np.array): The input data (e.g., spectrum) as a 1D NumPy array.
        order (int): The order of the polynomial to fit.
        iterations (int): Maximum number of iterations for the iterative fitting.
        tolerance (float): Convergence tolerance for the iterative fitting.

    Returns:
        np.array: The estimated baseline.
        np.array: The baseline-corrected data.
    """
    x = np.arange(len(data))
    weights = np.ones_like(data)
    baseline = np.zeros_like(data)

    for i in range(iterations):
        # Fit a polynomial to the data using weighted least squares
        coefficients = np.polyfit(x, data, order, w=weights)
        new_baseline = np.polyval(coefficients, x)

        # Check for convergence
        if np.max(np.abs(new_baseline - baseline)) < tolerance:
            break

        baseline = new_baseline

        # Update weights: downweight points above the current baseline
        # This is a common heuristic for iterative baseline correction
        diff = data - baseline
        weights = np.where(diff < 0, 1, 0.01) # Downweight positive residuals

    corrected_data = data - baseline
    return baseline, corrected_data





