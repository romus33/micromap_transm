# -*- coding: utf-8 -*-

import os

# Ограничение числа потоков внутри BLAS/OpenMP.
# Желательно, чтобы numpy/scipy ещё не были импортированы выше.
for _var in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ.setdefault(_var, "1")

import sys
import copy
import time as tm
import ctypes
from ctypes import *
import multiprocessing as mp

import numpy as np
import lmfit
from lmfit.model import Model

try:
    from tqdm.auto import tqdm
except Exception:
    tqdm = None


# ----------------------------------------------------------------------
# Безопасная замена termcolor.colored
# ----------------------------------------------------------------------

def colored(text, color=None, on_color=None, attrs=None):
    """
    Безопасная замена termcolor.colored.

    Не вызывает внешние shell-команды, поэтому не даёт ошибок вида:
        sh: 1: color: not found
    """
    if not sys.stdout.isatty() and not os.environ.get("FORCE_COLOR"):
        return str(text)

    ANSI_COLORS = {
        "grey": 30,
        "red": 31,
        "green": 32,
        "yellow": 33,
        "blue": 34,
        "magenta": 35,
        "cyan": 36,
        "white": 37,
        "light_grey": 37,
        "dark_grey": 90,
        "light_blue": 94,
    }

    code = ANSI_COLORS.get(color, 0)

    if code == 0:
        return str(text)

    return f"\033[{code}m{text}\033[0m"


# ----------------------------------------------------------------------
# Fallback, если tqdm не установлен
# ----------------------------------------------------------------------

class _FallbackTqdm:
    """
    Очень простой fallback вместо tqdm.

    Используется только если tqdm не установлен.
    """

    def __init__(
        self,
        iterable=None,
        total=None,
        desc=None,
        unit="it",
        smoothing=None,
        mininterval=None,
        **kwargs,
    ):
        self.total = int(total) if total is not None else 0
        self.n = 0
        self.desc = desc if desc is not None else ""

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self.total > 0:
            print()
        return False

    def update(self, n=1):
        self.n += int(n)

        if self.total > 0:
            percent = 100.0 * self.n / self.total
            print(
                f"\r{self.desc}: {self.n}/{self.total} ({percent:.1f}%)",
                end="",
                flush=True,
            )

    def set_description(self, desc="", refresh=True):
        self.desc = desc


# ----------------------------------------------------------------------
# Загрузка нативной библиотеки
# ----------------------------------------------------------------------

from pathlib import Path
import platform

_LIB_DIR = Path(__file__).resolve().parent
_SYSTEM = platform.system()

if _SYSTEM == "Windows":
    _candidates = [_LIB_DIR / "convolution.dll"]
elif _SYSTEM == "Darwin":
    _candidates = [
        _LIB_DIR / "convolution.dylib",
        _LIB_DIR / "convolution.so",
    ]
else:
    _candidates = [_LIB_DIR / "convolution.so"]

_lib_path = next((p for p in _candidates if p.is_file()), None)

if _lib_path is None:
    raise FileNotFoundError(
        "Не найдена нативная библиотека.\n"
        f"Искал в: {_LIB_DIR}\n"
        f"Ожидал один из файлов: {[str(p) for p in _candidates]}"
    )

try:
    myclib = ctypes.CDLL(str(_lib_path))
except OSError as exc:
    raise ImportError(
        f"Не удалось загрузить нативную библиотеку: {_lib_path}\n"
        f"Ошибка: {exc}"
    ) from exc


# ----------------------------------------------------------------------
# Вспомогательные функции
# ----------------------------------------------------------------------

_TSL_METHODS = {"TSL1", "TSL2", "TD1", "TD2"}


def _get_mp_context():
    """
    Возвращает контекст multiprocessing.

    По умолчанию на Linux используется forkserver, так как он безопаснее.

    Если нужен старый fork, задайте:
        export FITTINGMAP_MP_CONTEXT=fork
    """
    name = os.environ.get("FITTINGMAP_MP_CONTEXT", "").strip().lower()

    if name:
        try:
            return mp.get_context(name)
        except ValueError:
            pass

    if os.name == "posix":
        try:
            return mp.get_context("forkserver")
        except ValueError:
            return mp.get_context()

    return mp.get_context()


def _ensure_list(container, key, length, default):
    """
    Гарантирует, что container[key] является списком длины не меньше length.
    """
    if container is None:
        return []

    if length <= 0:
        return container.get(key, [])

    value = container.get(key, None)

    if value is None:
        value = []

    if isinstance(value, (str, bytes)):
        value = [value]
    elif isinstance(value, (list, tuple)):
        value = list(value)
    else:
        try:
            if np.ndim(value) == 0:
                value = [value]
            else:
                value = list(value)
        except Exception:
            value = [value]

    while len(value) < length:
        value.append(copy.deepcopy(default))

    container[key] = value
    return value


def _ensure_baseline_auto(params):
    """
    Приводит params['baseline_auto'] к списку [lam, p].
    """
    try:
        value = params.get("baseline_auto", None)

        if value is None:
            value = [1e7, 0.01]
        else:
            if isinstance(value, (str, bytes)):
                value = [value]
            elif isinstance(value, (list, tuple)):
                value = list(value)
            else:
                try:
                    if np.ndim(value) == 0:
                        value = [value]
                    else:
                        value = list(value)
                except Exception:
                    value = [value]

            while len(value) < 2:
                value.append(0.01)

        params["baseline_auto"] = value
        return value
    except Exception:
        params["baseline_auto"] = [1e7, 0.01]
        return params["baseline_auto"]


def _baseline_auto_limits(limits, default):
    """
    Приводит limits['baseline_auto'] к виду:
        [[lam_min, lam_max], [p_min, p_max]]
    """
    try:
        if not isinstance(limits, dict):
            return copy.deepcopy(default)

        value = limits.get("baseline_auto", None)

        if value is None or len(value) < 2:
            value = copy.deepcopy(default)
        else:
            lam = list(value[0])
            p = list(value[1])

            if len(lam) < 2 or len(p) < 2:
                value = copy.deepcopy(default)
            else:
                value = [lam, p]

        limits["baseline_auto"] = value
        return value
    except Exception:
        limits["baseline_auto"] = copy.deepcopy(default)
        return limits["baseline_auto"]


def _ordered_bounds(low, high, value=0.0):
    """
    Возвращает корректно упорядоченные min/max границы.
    """
    try:
        low = float(low)
    except Exception:
        low = -np.inf

    try:
        high = float(high)
    except Exception:
        high = np.inf

    if not np.isfinite(low):
        low = -np.inf
    if not np.isfinite(high):
        high = np.inf

    if low > high:
        low, high = high, low

    if low == high:
        try:
            delta = max(1e-12, abs(float(value)) * 0.1)
        except Exception:
            delta = 1e-12

        low -= delta
        high += delta

    return low, high


def _param_value(params, key, default=np.nan):
    """
    Безопасно достаёт значение параметра из lmfit.Parameters.
    """
    try:
        if key in params:
            return float(params[key].value)
    except Exception:
        pass

    return default


def _safe_rsq(out, y):
    """
    Безопасный расчёт R-square.
    """
    try:
        y = np.asarray(y, dtype=float)

        if y.size == 0:
            return np.nan

        var = np.var(y, ddof=0)

        if not np.isfinite(var) or var == 0:
            return np.nan

        redchi = getattr(out, "redchi", np.nan)

        if redchi is None or not np.isfinite(redchi):
            return np.nan

        return float(1.0 - redchi / var)
    except Exception:
        return np.nan


def _normalize_output(output, amplitude):
    """
    Нормирует рассчитанную нативной библиотекой кривую и умножает на амплитуду.
    """
    output = np.asarray(output, dtype=float)

    if output.size == 0:
        return output

    try:
        mx = float(np.nanmax(output))
    except Exception:
        mx = 0.0

    if not np.isfinite(mx) or mx == 0.0:
        return np.zeros_like(output, dtype=float)

    return float(amplitude) * output / mx


def _error_result(key, message):
    """
    Стандартный безопасный результат при ошибке.
    """
    return {
        "key": key,
        "amplitude": np.nan,
        "FWHM": np.nan,
        "center": np.nan,
        "height": np.nan,
        "sigma": np.nan,
        "r-square": np.nan,
        "error": str(message),
    }


def _zero_result(key, rsq=np.nan):
    """
    Результат для режима ALS / отсутствия пиков.
    """
    return {
        "key": key,
        "amplitude": 0.0,
        "FWHM": 0.0,
        "center": 0.0,
        "height": 0.0,
        "sigma": 0.0,
        "r-square": rsq,
    }


# ----------------------------------------------------------------------
# Основной класс
# ----------------------------------------------------------------------

class FittingMap(object):
    """
    Класс для обработки гиперспектральных карт:
    подгонка пиков, baseline ALS, TSL/TD кривые.

    Прогресс-бар реализован через tqdm в родительском процессе.
    """

    def __init__(self):
        self.map_baseline = {}
        self.map_bline = {}
        self.components = {}

        self.lam = 1e7
        self.p = 0.01
        self.niter = 10

        self.leng = 0
        self.param = {}
        self.limit = {}
        self.skip_points = None

    # ------------------------------------------------------------------
    # Нативные функции
    # ------------------------------------------------------------------

    @staticmethod
    def __baseline_als__(t: np.ndarray, lam: np.double, p: np.double):
        """
        Baseline ALS через нативную библиотеку.
        """
        t = np.asarray(t, dtype=float)

        if t.size == 0:
            return t.copy()

        t = np.nan_to_num(t, nan=0.0, posinf=0.0, neginf=0.0)

        py_ALS = myclib.ALS
        py_ALS.argtypes = [
            POINTER(c_double),
            POINTER(c_double),
            c_int,
            c_double,
            c_double,
            c_int,
        ]
        py_ALS.restype = None

        inputarray = (c_double * len(t))(*t)
        outputarray = (c_double * len(t))()

        N = c_int(len(t))
        lam_dll = c_double(float(lam))
        p_dll = c_double(float(p))

        py_ALS(inputarray, outputarray, N, lam_dll, p_dll, 10)

        return np.array(outputarray, dtype=float)

    @staticmethod
    def __TSL1__(x: np.ndarray, factor: np.double, energy: np.double, amplitude: np.double):
        """
        TSL первого порядка.
        """
        x = np.asarray(x, dtype=float)
        x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)

        if x.size == 0:
            return np.array([], dtype=float)

        py_TSL = myclib.TSLCalc
        py_TSL.argtypes = [
            c_int,
            c_double,
            c_double,
            POINTER(c_double),
            c_double,
            c_double,
            c_int,
        ]
        py_TSL.restype = None

        Tmin = c_double(float(x.min()))
        Tmax = c_double(float(x.max()))
        Npoints = c_int(len(x))

        outputarray = (c_double * len(x))()

        factor_dll = c_double(float(factor))
        energy_dll = c_double(float(energy))

        py_TSL(
            Npoints,
            Tmin,
            Tmax,
            outputarray,
            factor_dll,
            energy_dll,
            1,
        )

        return _normalize_output(outputarray, amplitude)

    @staticmethod
    def __TSL2__(x: np.ndarray, factor: np.double, energy: np.double, amplitude: np.double):
        """
        TSL второго порядка.
        """
        x = np.asarray(x, dtype=float)
        x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)

        if x.size == 0:
            return np.array([], dtype=float)

        py_TSL = myclib.TSLCalc
        py_TSL.argtypes = [
            c_int,
            c_double,
            c_double,
            POINTER(c_double),
            c_double,
            c_double,
            c_int,
        ]
        py_TSL.restype = None

        Tmin = c_double(float(x.min()))
        Tmax = c_double(float(x.max()))
        Npoints = c_int(len(x))

        outputarray = (c_double * len(x))()

        factor_dll = c_double(float(factor))
        energy_dll = c_double(float(energy))

        py_TSL(
            Npoints,
            Tmin,
            Tmax,
            outputarray,
            factor_dll,
            energy_dll,
            2,
        )

        return _normalize_output(outputarray, amplitude)

    @staticmethod
    def __TD1__(x: np.ndarray, factor: np.double, energy: np.double, amplitude: np.double):
        """
        Temperature decay первого порядка.
        """
        x = np.asarray(x, dtype=float)
        x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)

        if x.size == 0:
            return np.array([], dtype=float)

        py_TD = myclib.TDCalc
        py_TD.argtypes = [
            c_int,
            c_double,
            c_double,
            POINTER(c_double),
            c_double,
            c_double,
            c_int,
        ]
        py_TD.restype = None

        Tmin = c_double(float(x.min()))
        Tmax = c_double(float(x.max()))
        Npoints = c_int(len(x))

        outputarray = (c_double * len(x))()

        factor_dll = c_double(float(factor))
        energy_dll = c_double(float(energy))

        py_TD(
            Npoints,
            Tmin,
            Tmax,
            outputarray,
            factor_dll,
            energy_dll,
            1,
        )

        return _normalize_output(outputarray, amplitude)

    @staticmethod
    def __TD2__(x: np.ndarray, factor: np.double, energy: np.double, amplitude: np.double):
        """
        Temperature decay второго порядка.
        """
        x = np.asarray(x, dtype=float)
        x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)

        if x.size == 0:
            return np.array([], dtype=float)

        py_TD = myclib.TDCalc
        py_TD.argtypes = [
            c_int,
            c_double,
            c_double,
            POINTER(c_double),
            c_double,
            c_double,
            c_int,
        ]
        py_TD.restype = None

        Tmin = c_double(float(x.min()))
        Tmax = c_double(float(x.max()))
        Npoints = c_int(len(x))

        outputarray = (c_double * len(x))()

        factor_dll = c_double(float(factor))
        energy_dll = c_double(float(energy))

        py_TD(
            Npoints,
            Tmin,
            Tmax,
            outputarray,
            factor_dll,
            energy_dll,
            2,
        )

        return _normalize_output(outputarray, amplitude)

    # ------------------------------------------------------------------
    # Вспомогательные методы класса
    # ------------------------------------------------------------------

    @staticmethod
    def __get_numarray(item, wavenumber):
        """
        Возвращает индекс точки спектра по значению абсциссы.
        """
        try:
            start = float(item[5])
            step = float(item[7])

            if step == 0.0 or not np.isfinite(step):
                step = 1.0

            idx = int(round((float(wavenumber) - start) / step))

            try:
                n = int(item[3])
            except Exception:
                n = len(item[0])

            return max(0, min(idx, n))
        except Exception:
            return 0

    def __make_model__(self, num, params, limits):
        """
        Создаёт lmfit-модель для одного пика / одной кривой.
        """
        pref = f"f{num}_"

        _ensure_list(params, "method", num + 1, "Gaussian")

        method = str(params["method"][num])
        method_u = method.upper()

        if method_u in _TSL_METHODS:
            if method_u == "TSL1":
                model = Model(self.__TSL1__, prefix=pref)
            elif method_u == "TSL2":
                model = Model(self.__TSL2__, prefix=pref)
            elif method_u == "TD1":
                model = Model(self.__TD1__, prefix=pref)
            else:
                model = Model(self.__TD2__, prefix=pref)

            _ensure_list(params, "amplitude", num + 1, 1.0)
            _ensure_list(params, "energy", num + 1, 1.0)
            _ensure_list(params, "factor", num + 1, 1e10)

            _ensure_list(limits, "amplitude", num + 1, [0.0, 1000.0])
            _ensure_list(limits, "energy", num + 1, [0.0, 2.0])
            _ensure_list(limits, "factor", num + 1, [1e7, 1e14])

            amp = float(params["amplitude"][num])
            energy = float(params["energy"][num])
            factor = float(params["factor"][num])

            if not np.isfinite(amp):
                amp = 1.0
                params["amplitude"][num] = amp

            if not np.isfinite(energy):
                energy = 1.0
                params["energy"][num] = energy

            if not np.isfinite(factor):
                factor = 1e10
                params["factor"][num] = factor

            amp_limits = limits["amplitude"][num]
            energy_limits = limits["energy"][num]
            factor_limits = limits["factor"][num]

            min_amp, max_amp = _ordered_bounds(
                amp_limits[0] * amp,
                amp_limits[1] * amp,
                amp,
            )

            min_energy, max_energy = _ordered_bounds(
                energy_limits[0],
                energy_limits[1],
                energy,
            )

            min_factor, max_factor = _ordered_bounds(
                factor_limits[0],
                factor_limits[1],
                factor,
            )

            model.set_param_hint(
                pref + "amplitude",
                value=amp,
                min=min_amp,
                max=max_amp,
            )

            model.set_param_hint(
                pref + "energy",
                value=energy,
                min=min_energy,
                max=max_energy,
            )

            model.set_param_hint(
                pref + "factor",
                value=factor,
                min=min_factor,
                max=max_factor,
            )

            return model

        model_class_name = method + "Model"

        if not hasattr(lmfit.models, model_class_name):
            raise ValueError(f"Unknown fitting method: {method}")

        bar = getattr(lmfit.models, model_class_name)
        model = bar(prefix=pref)

        _ensure_list(params, "amplitude", num + 1, 1.0)
        _ensure_list(params, "center", num + 1, 0.0)
        _ensure_list(params, "width", num + 1, 4.0)

        _ensure_list(limits, "amplitude", num + 1, [0.0, 1000.0])
        _ensure_list(limits, "center", num + 1, [5.0, 5.0])
        _ensure_list(limits, "width", num + 1, [0.2, 10.0])

        amp = float(params["amplitude"][num])
        cen = float(params["center"][num])
        wid = float(params["width"][num])

        if not np.isfinite(amp):
            amp = 1.0
            params["amplitude"][num] = amp

        if not np.isfinite(cen):
            cen = 0.0
            params["center"][num] = cen

        if not np.isfinite(wid) or wid == 0.0:
            wid = 4.0
            params["width"][num] = wid

        amp_limits = limits["amplitude"][num]
        center_limits = limits["center"][num]
        width_limits = limits["width"][num]

        min_amp, max_amp = _ordered_bounds(
            amp_limits[0] * amp,
            amp_limits[1] * amp,
            amp,
        )

        min_center, max_center = _ordered_bounds(
            cen - center_limits[0],
            cen + center_limits[1],
            cen,
        )

        min_sigma, max_sigma = _ordered_bounds(
            wid * width_limits[0],
            wid * width_limits[1],
            wid,
        )

        model.set_param_hint(
            pref + "amplitude",
            value=amp,
            min=min_amp,
            max=max_amp,
        )

        model.set_param_hint(
            pref + "center",
            value=cen,
            min=min_center,
            max=max_center,
        )

        model.set_param_hint(
            pref + "sigma",
            value=wid,
            min=min_sigma,
            max=max_sigma,
        )

        return model

    # ------------------------------------------------------------------
    # Обработка одной точки карты
    # ------------------------------------------------------------------

    def map_intensity(self, item):
        """
        Подгонка одной точки гиперспектральной карты.

        Возвращает словарь с результатами.
        """
        name = str(item[1]) + "_" + str(item[2])

        try:
            params = copy.deepcopy(self.param or {})
            limits = copy.deepcopy(self.limit or {})
        except Exception:
            params = dict(self.param or {})
            limits = dict(self.limit or {})

        if "method" not in params or params["method"] is None:
            return _error_result(name, "params['method'] is required")

        _ensure_list(params, "method", 1, "Gaussian")

        if len(params["method"]) == 0:
            return _error_result(name, "params['method'] is empty")

        method0 = str(params["method"][0])
        method0_u = method0.upper()

        is_als = method0_u == "ALS"
        is_tsl = method0_u in _TSL_METHODS

        if "range" not in params or len(params["range"]) < 2:
            params["range"] = [item[5], item[6]]

        try:
            xmin = float(params["range"][0])
            xmax = float(params["range"][1])

            if xmin > xmax:
                xmin, xmax = xmax, xmin
        except Exception as exc:
            return _error_result(name, f"Invalid range: {exc}")

        try:
            y_full = np.asarray(item[0], dtype=float)

            i0 = self.__get_numarray(item, xmin)
            i1 = self.__get_numarray(item, xmax)

            if i1 < i0:
                i0, i1 = i1, i0

            i0 = max(0, min(i0, y_full.size))
            i1 = max(i0, min(i1, y_full.size))

            y = y_full[i0:i1]

            if y.size == 0:
                return _error_result(name, "Empty fitting range")

            x = np.linspace(xmin, xmax, y.size)
        except Exception as exc:
            return _error_result(name, f"Cannot extract spectrum range: {exc}")

        baseline_flag = ("baseline" in params) and (params["baseline"] is not None)
        b_line = None

        if baseline_flag:
            try:
                self.lam = float(params["baseline"][0])
                self.p = float(params["baseline"][1])

                if len(params["baseline"]) > 2:
                    self.niter = int(params["baseline"][2])
            except Exception:
                baseline_flag = False

        number_of_peaks = 0

        if not is_als:
            if is_tsl:
                _ensure_list(params, "method", 1, method0)
                number_of_peaks = len(params["method"])

                _ensure_list(params, "amplitude", number_of_peaks, 1.0)
                _ensure_list(params, "energy", number_of_peaks, 1.0)
                _ensure_list(params, "factor", number_of_peaks, 1e10)

                _ensure_list(limits, "amplitude", number_of_peaks, [0.0, 1000.0])
                _ensure_list(limits, "energy", number_of_peaks, [0.0, 2.0])
                _ensure_list(limits, "factor", number_of_peaks, [1e7, 1e14])
            else:
                if "center" not in params:
                    return _error_result(name, "No centers")

                _ensure_list(params, "center", 1, 0.0)
                number_of_peaks = len(params["center"])

                _ensure_list(params, "amplitude", number_of_peaks, 1.0)
                _ensure_list(params, "width", number_of_peaks, 4.0)
                _ensure_list(params, "method", number_of_peaks, "Gaussian")

                _ensure_list(limits, "amplitude", number_of_peaks, [0.0, 1000.0])
                _ensure_list(limits, "width", number_of_peaks, [0.2, 10.0])
                _ensure_list(limits, "center", number_of_peaks, [5.0, 5.0])

        if "baseline_auto" not in params:
            if baseline_flag:
                try:
                    b_line = self.__baseline_als__(y, self.lam, self.p)
                    y_fit = np.subtract(y, b_line)
                except Exception as exc:
                    return _error_result(name, f"Baseline ALS error: {exc}")
            else:
                b_line = np.zeros_like(y, dtype=float)
                y_fit = y.copy()
        else:
            y_fit = y.copy()

        if "kws" not in params:
            params["kws"] = {"ftol": 1e-8, "xtol": 1e-8, "gtol": 1e-8}

        fit_kws = params["kws"]

        mod = None

        if not is_als:
            for i in range(number_of_peaks):
                try:
                    this_mod = self.__make_model__(i, params, limits)
                except Exception as exc:
                    return _error_result(name, f"Model creation error: {exc}")

                if mod is None:
                    mod = this_mod
                else:
                    mod = mod + this_mod

        if "baseline_auto" in params:
            baseline_auto_params = _ensure_baseline_auto(params)
            baseline_auto_limits = _baseline_auto_limits(
                limits,
                [[1e4, 1e12], [0.0001, 0.1]],
            )

            bl = Model(self.__baseline_als__, prefix="bg_")

            try:
                bl.set_param_hint(
                    "lam",
                    value=float(baseline_auto_params[0]),
                    min=float(baseline_auto_limits[0][0]),
                    max=float(baseline_auto_limits[0][1]),
                )

                bl.set_param_hint(
                    "p",
                    value=float(baseline_auto_params[1]),
                    min=float(baseline_auto_limits[1][0]),
                    max=float(baseline_auto_limits[1][1]),
                )
            except Exception as exc:
                return _error_result(name, f"Baseline auto hints error: {exc}")

            if mod is None:
                mod = bl
            else:
                mod = mod + bl

        if mod is None:
            if is_als:
                if baseline_flag and b_line is not None:
                    self.map_baseline[name] = [
                        b_line,
                        item[1],
                        item[2],
                        len(y),
                        len(y),
                        xmin,
                        xmax,
                        item[7],
                        None,
                    ]

                    self.map_bline[name] = [
                        x,
                        b_line,
                        self.lam,
                        self.p,
                    ]
                else:
                    zero = np.zeros_like(y, dtype=float)

                    self.map_baseline[name] = [
                        zero,
                        item[1],
                        item[2],
                        len(y),
                        len(y),
                        xmin,
                        xmax,
                        item[7],
                        None,
                    ]

                    self.map_bline[name] = [
                        x,
                        np.zeros_like(x, dtype=float),
                        0,
                        0,
                    ]

                return _zero_result(name, np.nan)

            return _error_result(name, "No model")

        try:
            if "baseline_auto" in params:
                out = mod.fit(
                    y_fit,
                    x=x,
                    t=y_fit,
                    method="least_squares",
                    fit_kws=fit_kws,
                    nan_policy="omit",
                )
            else:
                out = mod.fit(
                    y_fit,
                    x=x,
                    method="least_squares",
                    fit_kws=fit_kws,
                    nan_policy="omit",
                )
        except Exception as exc:
            self.map_baseline[name] = [
                None,
                item[1],
                item[2],
                len(y),
                len(y),
                xmin,
                xmax,
                item[7],
                None,
            ]

            if baseline_flag and b_line is not None:
                self.map_bline[name] = [
                    x,
                    b_line,
                    self.lam,
                    self.p,
                ]
            else:
                self.map_bline[name] = [
                    x,
                    np.zeros_like(x, dtype=float),
                    0,
                    0,
                ]

            return _error_result(name, f"Fit failed: {exc}")

        try:
            comps = out.eval_components(x=x)
        except Exception:
            comps = None

        self.components = comps

        best_fit = getattr(out, "best_fit", None)

        if best_fit is None:
            best_fit = np.full_like(y_fit, np.nan, dtype=float)

        self.map_baseline[name] = [
            best_fit,
            item[1],
            item[2],
            len(y),
            len(y),
            xmin,
            xmax,
            item[7],
            comps,
        ]

        if (
            "baseline_auto" in params
            and isinstance(comps, dict)
            and "bg_" in comps
        ):
            self.map_bline[name] = [
                x,
                comps["bg_"],
                _param_value(out.params, "bg_lam", np.nan),
                _param_value(out.params, "bg_p", np.nan),
            ]
        elif baseline_flag and b_line is not None:
            self.map_bline[name] = [
                x,
                b_line,
                self.lam,
                self.p,
            ]
        else:
            self.map_bline[name] = [
                x,
                np.zeros_like(x, dtype=float),
                0,
                0,
            ]

        Rsq = _safe_rsq(out, y_fit)

        if is_als:
            result = _zero_result(name, Rsq)

            if "baseline_auto" in params:
                result["lam"] = _param_value(out.params, "bg_lam", np.nan)
                result["p"] = _param_value(out.params, "bg_p", np.nan)

            return result

        if is_tsl:
            A = np.array(
                [
                    _param_value(out.params, f"f{i}_amplitude", np.nan)
                    for i in range(number_of_peaks)
                ],
                dtype=float,
            )

            F = np.array(
                [
                    _param_value(out.params, f"f{i}_factor", np.nan)
                    for i in range(number_of_peaks)
                ],
                dtype=float,
            )

            E = np.array(
                [
                    _param_value(out.params, f"f{i}_energy", np.nan)
                    for i in range(number_of_peaks)
                ],
                dtype=float,
            )

            return {
                "key": name,
                "amplitude": A,
                "factor": F,
                "energy": E,
                "r-square": Rsq,
            }

        A = np.array(
            [
                _param_value(out.params, f"f{i}_amplitude", np.nan)
                for i in range(number_of_peaks)
            ],
            dtype=float,
        )

        FWHM = np.array(
            [
                _param_value(out.params, f"f{i}_fwhm", np.nan)
                for i in range(number_of_peaks)
            ],
            dtype=float,
        )

        C = np.array(
            [
                _param_value(out.params, f"f{i}_center", np.nan)
                for i in range(number_of_peaks)
            ],
            dtype=float,
        )

        H = np.array(
            [
                _param_value(out.params, f"f{i}_height", np.nan)
                for i in range(number_of_peaks)
            ],
            dtype=float,
        )

        S = np.array(
            [
                _param_value(out.params, f"f{i}_sigma", np.nan)
                for i in range(number_of_peaks)
            ],
            dtype=float,
        )

        return {
            "key": name,
            "amplitude": A,
            "FWHM": FWHM,
            "center": C,
            "height": H,
            "sigma": S,
            "r-square": Rsq,
        }

    # ------------------------------------------------------------------
    # Подгонка одного спектра
    # ------------------------------------------------------------------

    def fit_array(self, x, y, params=None, limits=None, name=""):
        """
        Подгонка одного спектра/кривой.
        """
        x = np.asarray(x, dtype=float)
        y = np.asarray(y, dtype=float)

        if x.size != y.size:
            return {
                "error": "x and y must have the same length",
                "r-square": np.nan,
            }

        if params is None:
            params = {}
        else:
            try:
                params = copy.deepcopy(params)
            except Exception:
                params = dict(params)

        if limits is None:
            limits = {}
        else:
            try:
                limits = copy.deepcopy(limits)
            except Exception:
                limits = dict(limits)

        if "method" not in params or params["method"] is None:
            return {
                "error": "params['method'] is required",
                "r-square": np.nan,
            }

        _ensure_list(params, "method", 1, "Gaussian")

        if len(params["method"]) == 0:
            return {
                "error": "params['method'] is empty",
                "r-square": np.nan,
            }

        method0 = str(params["method"][0])
        method0_u = method0.upper()

        is_als = method0_u == "ALS"
        is_tsl = method0_u in _TSL_METHODS

        baseline_flag = ("baseline" in params) and (params["baseline"] is not None)
        b_line = None

        if baseline_flag:
            try:
                self.lam = float(params["baseline"][0])
                self.p = float(params["baseline"][1])

                if len(params["baseline"]) > 2:
                    self.niter = int(params["baseline"][2])
            except Exception:
                baseline_flag = False

        number_of_peaks = 0

        if not is_als:
            if is_tsl:
                number_of_peaks = len(params["method"])

                _ensure_list(params, "amplitude", number_of_peaks, 1.0)
                _ensure_list(params, "energy", number_of_peaks, 1.0)
                _ensure_list(params, "factor", number_of_peaks, 1e10)

                _ensure_list(limits, "amplitude", number_of_peaks, [0.0, 1000.0])
                _ensure_list(limits, "energy", number_of_peaks, [0.0, 2.0])
                _ensure_list(limits, "factor", number_of_peaks, [1e7, 1e14])
            else:
                if "center" not in params:
                    return {
                        "error": "No centers",
                        "r-square": np.nan,
                    }

                _ensure_list(params, "center", 1, 0.0)
                number_of_peaks = len(params["center"])

                _ensure_list(params, "amplitude", number_of_peaks, 1000.0)
                _ensure_list(params, "width", number_of_peaks, 2.0)
                _ensure_list(params, "method", number_of_peaks, "Gaussian")

                _ensure_list(limits, "amplitude", number_of_peaks, [0.0, 1000.0])
                _ensure_list(limits, "width", number_of_peaks, [0.2, 10.0])
                _ensure_list(limits, "center", number_of_peaks, [5.0, 5.0])

                if "baseline_auto" not in params and baseline_flag:
                    b_line = self.__baseline_als__(y, self.lam, self.p)
                    y = np.subtract(y, b_line)
        else:
            if "baseline_auto" not in params:
                print(
                    "No start fitting parameters. "
                    "Default parameters are used (lam=1e7, p=0.01)"
                )
                params["baseline_auto"] = [1e7, 0.01]

        if "kws" not in params:
            params["kws"] = {"ftol": 1e-8, "xtol": 1e-8, "gtol": 1e-8}

        if "max_nfev" not in params:
            params["max_nfev"] = 100000

        fit_kws = params["kws"]

        mod = None

        if is_als:
            baseline_auto_params = _ensure_baseline_auto(params)
            baseline_auto_limits = _baseline_auto_limits(
                limits,
                [[2.0, 1e2], [0.1, 1.0]],
            )

            mod = Model(self.__baseline_als__, prefix="bg_")

            mod.set_param_hint(
                "lam",
                value=float(baseline_auto_params[0]),
                min=float(baseline_auto_limits[0][0]),
                max=float(baseline_auto_limits[0][1]),
            )

            mod.set_param_hint(
                "p",
                value=float(baseline_auto_params[1]),
                min=float(baseline_auto_limits[1][0]),
                max=float(baseline_auto_limits[1][1]),
            )

            try:
                out = mod.fit(
                    y,
                    x=x,
                    t=y,
                    method="least_squares",
                    fit_kws=fit_kws,
                    max_nfev=params["max_nfev"],
                    nan_policy="omit",
                )
            except Exception as exc:
                return {
                    "error": str(exc),
                    "r-square": np.nan,
                }

            try:
                comps = out.eval_components(x=x)
            except Exception:
                comps = None

            self.map_baseline[name] = [x, getattr(out, "best_fit", None)]

            self.map_bline[name] = [
                x,
                comps.get("bg_") if isinstance(comps, dict) else None,
                _param_value(out.params, "bg_lam", np.nan),
                _param_value(out.params, "bg_p", np.nan),
            ]

            self.components = comps

            return {
                "lam": _param_value(out.params, "bg_lam", np.nan),
                "p": _param_value(out.params, "bg_p", np.nan),
                "r-square": _safe_rsq(out, y),
            }

        for i in range(number_of_peaks):
            this_mod = self.__make_model__(i, params, limits)

            if mod is None:
                mod = this_mod
            else:
                mod = mod + this_mod

        if "baseline_auto" in params:
            baseline_auto_params = _ensure_baseline_auto(params)
            baseline_auto_limits = _baseline_auto_limits(
                limits,
                [[1e4, 1e12], [0.0001, 0.1]],
            )

            bl = Model(self.__baseline_als__, prefix="bg_")

            bl.set_param_hint(
                "lam",
                value=float(baseline_auto_params[0]),
                min=float(baseline_auto_limits[0][0]),
                max=float(baseline_auto_limits[0][1]),
            )

            bl.set_param_hint(
                "p",
                value=float(baseline_auto_params[1]),
                min=float(baseline_auto_limits[1][0]),
                max=float(baseline_auto_limits[1][1]),
            )

            if mod is None:
                mod = bl
            else:
                mod = mod + bl

        if mod is None:
            return {
                "error": "No model",
                "r-square": np.nan,
            }

        try:
            if "baseline_auto" in params:
                out = mod.fit(
                    y,
                    x=x,
                    t=y,
                    method="least_squares",
                    fit_kws=fit_kws,
                    max_nfev=params["max_nfev"],
                    nan_policy="omit",
                )
            else:
                out = mod.fit(
                    y,
                    x=x,
                    method="least_squares",
                    fit_kws=fit_kws,
                    max_nfev=params["max_nfev"],
                    nan_policy="omit",
                )
        except Exception as exc:
            return {
                "error": str(exc),
                "r-square": np.nan,
            }

        try:
            comps = out.eval_components(x=x)
        except Exception:
            comps = None

        self.components = comps
        self.map_baseline[name] = [x, getattr(out, "best_fit", None)]

        if (
            "baseline_auto" in params
            and isinstance(comps, dict)
            and "bg_" in comps
        ):
            self.map_bline[name] = [
                x,
                comps["bg_"],
                _param_value(out.params, "bg_lam", np.nan),
                _param_value(out.params, "bg_p", np.nan),
            ]
        elif baseline_flag and b_line is not None:
            self.map_bline[name] = [
                x,
                b_line,
                self.lam,
                self.p,
            ]
        else:
            self.map_bline[name] = [
                x,
                np.zeros_like(x, dtype=float),
                0,
                0,
            ]

        Rsq = _safe_rsq(out, y)

        if is_tsl:
            A = np.array(
                [
                    _param_value(out.params, f"f{i}_amplitude", np.nan)
                    for i in range(number_of_peaks)
                ],
                dtype=float,
            )

            F = np.array(
                [
                    _param_value(out.params, f"f{i}_factor", np.nan)
                    for i in range(number_of_peaks)
                ],
                dtype=float,
            )

            E = np.array(
                [
                    _param_value(out.params, f"f{i}_energy", np.nan)
                    for i in range(number_of_peaks)
                ],
                dtype=float,
            )

            return {
                "amplitude": A,
                "factor": F,
                "energy": E,
                "r-square": Rsq,
            }

        A = np.array(
            [
                _param_value(out.params, f"f{i}_amplitude", np.nan)
                for i in range(number_of_peaks)
            ],
            dtype=float,
        )

        FWHM = np.array(
            [
                _param_value(out.params, f"f{i}_fwhm", np.nan)
                for i in range(number_of_peaks)
            ],
            dtype=float,
        )

        C = np.array(
            [
                _param_value(out.params, f"f{i}_center", np.nan)
                for i in range(number_of_peaks)
            ],
            dtype=float,
        )

        H = np.array(
            [
                _param_value(out.params, f"f{i}_height", np.nan)
                for i in range(number_of_peaks)
            ],
            dtype=float,
        )

        S = np.array(
            [
                _param_value(out.params, f"f{i}_sigma", np.nan)
                for i in range(number_of_peaks)
            ],
            dtype=float,
        )

        result = {
            "amplitude": A,
            "FWHM": FWHM,
            "center": C,
            "height": H,
            "r-square": Rsq,
            "sigma": S,
        }

        if "baseline_auto" in params:
            result["p"] = _param_value(out.params, "bg_p", np.nan)
            result["lam"] = _param_value(out.params, "bg_lam", np.nan)

        return result

    # ------------------------------------------------------------------
    # Обработка карты с tqdm
    # ------------------------------------------------------------------

    def find_intensity(
        self,
        map_spectra,
        params,
        limits,
        skip_points=None,
        skip_number=None,
        num_proc=1,
    ):
        """
        Строит карту параметров подгонки по гиперспектральной карте.

        Прогресс-бар отображается через tqdm.
        """
        self.param = params
        self.limit = limits
        self.skip_points = skip_points

        work_map = dict(map_spectra or {})

        if skip_number is not None and isinstance(skip_number, list):
            work_map = {
                key: value
                for i, (key, value) in enumerate(work_map.items())
                if i not in skip_number
            }

        if skip_points is not None and isinstance(skip_points, list):
            for sx, sy in skip_points:
                key_to_delete = str(sx) + "_" + str(sy)
                work_map.pop(key_to_delete, None)

        items = list(work_map.values())
        total = len(items)

        x = np.array([item[1] for item in items])
        y = np.array([item[2] for item in items])

        self.leng = total
        self.map_baseline = {}
        self.map_bline = {}
        self.components = {}

        print(colored("Peak fitting:", "cyan"))

        if total == 0:
            return x, y, []

        try:
            if num_proc is None:
                num_proc = os.cpu_count() or 1
            num_proc = max(1, int(num_proc))
        except Exception:
            num_proc = 1

        results = [None] * total

        def _process_payload(payload):
            if not isinstance(payload, dict):
                return

            idx = payload.get("idx", None)
            result = payload.get("result", None)

            if idx is not None and 0 <= idx < total:
                results[idx] = result

            key = payload.get("key", None)

            if key:
                baseline_entry = payload.get("baseline_entry", None)
                bline_entry = payload.get("bline_entry", None)
                components_entry = payload.get("components", None)

                if baseline_entry is not None:
                    self.map_baseline[key] = baseline_entry

                if bline_entry is not None:
                    self.map_bline[key] = bline_entry

                if components_entry is not None and components_entry != {}:
                    self.components[key] = components_entry

        tasks = list(enumerate(items))

        ProgressClass = tqdm if tqdm is not None else _FallbackTqdm

        if num_proc <= 1 or total <= 1:
            _worker_init(params, limits)

            with ProgressClass(
                total=total,
                desc="Peak fitting",
                smoothing=0.1,
                mininterval=0.1,
            ) as pbar:
                for task in tasks:
                    payload = _worker_fit(task)
                    _process_payload(payload)
                    pbar.update(1)

            z1 = [
                r if r is not None else _error_result("unknown", "missing result")
                for r in results
            ]

            return x, y, z1

        ctx = _get_mp_context()

        try:
            with ctx.Pool(
                processes=num_proc,
                initializer=_worker_init,
                initargs=(params, limits),
            ) as pool:
                with ProgressClass(
                    total=total,
                    desc="Peak fitting",
                    smoothing=0.1,
                    mininterval=0.1,
                ) as pbar:
                    for payload in pool.imap_unordered(
                        _worker_fit,
                        tasks,
                        chunksize=1,
                    ):
                        _process_payload(payload)
                        pbar.update(1)

        except Exception as exc:
            print(
                colored(
                    f"Multiprocessing failed: {exc}\n"
                    "Falling back to sequential mode.",
                    "yellow",
                )
            )

            results = [None] * total
            self.map_baseline.clear()
            self.map_bline.clear()
            self.components.clear()

            _worker_init(params, limits)

            with ProgressClass(
                total=total,
                desc="Peak fitting",
                smoothing=0.1,
                mininterval=0.1,
            ) as pbar:
                for task in tasks:
                    payload = _worker_fit(task)
                    _process_payload(payload)
                    pbar.update(1)

        z1 = [
            r if r is not None else _error_result("unknown", "missing result")
            for r in results
        ]

        return x, y, z1

    # ------------------------------------------------------------------
    # Поиск пиков
    # ------------------------------------------------------------------

    @staticmethod
    def __find_nearest_(self, array, value):
        array = np.asarray(array)
        idx = (np.abs(array - value)).argmin()
        return idx

    @staticmethod
    def peakdet(y_axis, lookahead=3, delta=0.02):
        """
        Возвращает позиции пиков на спектре.
        """
        max_peaks = []
        dump = []

        length = len(y_axis)
        x_axis = range(length)

        if lookahead < 1:
            raise ValueError("Lookahead must be '1' or above in value")

        if not (np.isscalar(delta) and delta >= 0):
            raise ValueError("delta must be a positive number")

        mn, mx = np.inf, -np.inf
        mxpos = 0

        for index, (x, y) in enumerate(zip(x_axis[:-lookahead], y_axis[:-lookahead])):
            if y > mx:
                mx = y
                mxpos = x

            if y < mn:
                mn = y

            if y < mx - delta and mx != np.inf:
                if y_axis[index:index + lookahead].max() < mx:
                    if len(y_axis[index - lookahead:index + lookahead]) > 0:
                        max_peaks.append(mxpos)
                        dump.append(True)

                        mx = np.inf
                        mn = np.inf

                        if index + lookahead >= length:
                            break

                        continue

            if y > mn + delta and mn != -np.inf:
                if y_axis[index:index + lookahead].min() > mn:
                    dump.append(False)

                    mn = -np.inf
                    mx = -np.inf

                    if index + lookahead >= length:
                        break

        try:
            if dump[0]:
                max_peaks.pop(0)

            del dump
        except IndexError:
            print("No peaks found")

        return max_peaks

    @staticmethod
    def __ampd__(sigInput):
        """
        AMPD algorithm.
        """
        sigTime = np.arange(0, len(sigInput))
        fitPoly = np.polyfit(sigTime, sigInput, 1)
        sigFit = np.polyval(fitPoly, sigTime)

        dtrSignal = sigInput - sigFit
        N = len(dtrSignal)
        L = int(N / 2.0) - 1

        LSM = np.random.uniform(1.0, 2.0, size=(L, N))

        for k in np.arange(1, L):
            locMax = np.zeros(N, dtype=bool)

            mask = np.array(
                (dtrSignal[k:N - k - 1] > dtrSignal[0:N - 2 * k - 1])
                & (dtrSignal[k:N - k - 1] > dtrSignal[2 * k:N - 1])
            )

            mask = mask.flatten()
            locMax[k:N - k - 1] = mask
            LSM[k - 1, locMax] = 0

        G = np.sum(LSM, 1)
        l_ = np.where(G == G.min())[0][0]
        LSM = LSM[0:l_, :]

        S = np.std(LSM, 0)
        pks = np.flatnonzero(S == 0)

        return pks

    def ampd_fast(self, sigInput, order):
        """
        Faster AMPD.
        """
        if len(sigInput) % order != 0:
            print("AMPD: Invalid order, decreasing order")

            while len(sigInput) % order != 0:
                order -= 1

            print("AMPD: Using order " + str(order))

        N = int((len(sigInput) / order / 2.0)) + 1

        pks = None

        for i in range(0, len(sigInput) - N, N):
            pksTemp = self.__ampd__(sigInput[i:(i + 2 * N - 1)])

            if pks is None:
                pks = pksTemp
            else:
                pks = np.concatenate((pks, pksTemp + i))

        index = 1
        out = []

        while index < len(pks):
            if (pks[index] - pks[index - 1]) * 100.0 / pks[index] > 5:
                out.append(pks[index - 1])
                out.append(pks[index])

            index += 1

        pks = np.unique(out)

        return pks


# ----------------------------------------------------------------------
# Multiprocessing workers
#
# ВАЖНО: эти функции должны быть на уровне модуля, чтобы их можно было
# передавать между процессами через pickle.
# ----------------------------------------------------------------------

_WORKER_FITTER = None


def _worker_init(params, limits):
    """
    Инициализация лёгкого экземпляра FittingMap внутри рабочего процесса.
    """
    global _WORKER_FITTER

    fitter = FittingMap.__new__(FittingMap)

    fitter.map_baseline = {}
    fitter.map_bline = {}
    fitter.components = {}

    baseline = None

    if isinstance(params, dict):
        baseline = params.get("baseline", None)

    try:
        if baseline is not None and len(baseline) > 0:
            fitter.lam = float(baseline[0])
        else:
            fitter.lam = 1e7
    except Exception:
        fitter.lam = 1e7

    try:
        if baseline is not None and len(baseline) > 1:
            fitter.p = float(baseline[1])
        else:
            fitter.p = 0.01
    except Exception:
        fitter.p = 0.01

    try:
        if baseline is not None and len(baseline) > 2:
            fitter.niter = int(baseline[2])
        else:
            fitter.niter = 10
    except Exception:
        fitter.niter = 10

    fitter.leng = 0
    fitter.param = params
    fitter.limit = limits
    fitter.skip_points = None

    _WORKER_FITTER = fitter


def _worker_fit(args):
    """
    Обработка одной точки карты в рабочем процессе.

    args = (idx, item)
    """
    global _WORKER_FITTER

    try:
        idx, item = args
    except Exception:
        idx = None
        item = None

    if item is None:
        key = "unknown"
    else:
        key = str(item[1]) + "_" + str(item[2])

    if _WORKER_FITTER is None:
        return {
            "idx": idx,
            "key": key,
            "result": _error_result(key, "worker is not initialized"),
            "baseline_entry": None,
            "bline_entry": None,
            "components": None,
        }

    try:
        _WORKER_FITTER.map_baseline.clear()
        _WORKER_FITTER.map_bline.clear()
        _WORKER_FITTER.components = {}

        result = _WORKER_FITTER.map_intensity(item)

        if not isinstance(result, dict):
            result = _error_result(key, "invalid result")

        result.setdefault("key", key)

        return {
            "idx": idx,
            "key": key,
            "result": result,
            "baseline_entry": _WORKER_FITTER.map_baseline.get(key, None),
            "bline_entry": _WORKER_FITTER.map_bline.get(key, None),
            "components": _WORKER_FITTER.components,
        }

    except Exception as exc:
        return {
            "idx": idx,
            "key": key,
            "result": _error_result(key, exc),
            "baseline_entry": None,
            "bline_entry": None,
            "components": None,
        }
