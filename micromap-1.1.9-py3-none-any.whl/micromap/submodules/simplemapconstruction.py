import math
import numpy as np

#num_proc = 4
_round_to = lambda num, digits: 0 if num == 0 else round(num, max(int(
    -math.floor(math.log10(abs(num - int(num))))) + digits - 1, digits))


class SimpleMapConstruction(object):
    """Class for maps construction"""

    def __init__(self, map_spectr, skip_number = None, skip_points=None):  # , point1=-1, threshold=0,point_threshold=-1,point2=-1, interval1=0, interval2=0):
        """Constructor"""
        if skip_number is not None:
            if isinstance(skip_number, list):
                filtered_dict = {
                                key: value 
                                for i, (key, value) in enumerate(map_spectr.items()) 
                                if i not in skip_number
                                }
                map_spectr = filtered_dict
        if skip_points is not None:
            if isinstance(skip_points, list):
                for x, y in skip_points:
                    key_to_delete = str(x) + '_' + str(y)
                    try:
                        map_spectr.pop(key_to_delete)
                    except KeyError:
                        pass            
        self.__map_spectra__ = map_spectr
        # self.threshold=threshold
        # #Means the lowest intensity of positive signal. This needs when relationships between two points were used to avoid map corruption in points with lower intensity
        # self.point_threshold=point_threshold #Point (in cm-1) where threshold was measured
        # self.point1=point1                   #Point1 (in cm-1) where intensity was measured
        # self.point2=point2                   #Second point where intensity was measured
        # self.interval1=interval1             #Interval1 of integration in cm-1
        # self.interval2=interval2             ##Interval2 of integration in cm-1
        # if (self.point1==-1): print("Points were not initialized")

    @staticmethod
    def __get_numarray(item, wavenumber):
        """
           Private method to get corresponding array element number of wavenumber
        """
        return int((wavenumber - item[5]) / item[7])

    def __mpPointRelation__(self, item, param):
        """
            Method to map relation of intensitites between two points
        """
        if np.isnan(self.__check_thresh__(item, param)):
            return np.NaN
        
        sp = item[0]
        n1 = sp[self.__get_numarray(item, param['points'][0])]
        n2 = sp[self.__get_numarray(item, param['points'][1])]

        if (not n1) and (not n2):
            #return 0
            return np.nan
        #print('222222')
        return np.float64(n1 / n2)

    def __mpPointIntensity__(self, item, param):
        """
            Method to map intensity in point1
        """
        return item[0][self.__get_numarray(item, param['points'][0])]

    def __mpSquare__(self, item, param):
        """
            Method to map integral intensity in point1+/-interval1
        """

        return np.trapz(item[0][
                        self.__get_numarray(item, param['points'][0] - param['intervals'][0]):self.__get_numarray(item,
                                                                                                                  param[
                                                                                                                      'points'][
                                                                                                                      0] +
                                                                                                                  param[
                                                                                                                      'intervals'][
                                                                                                                      0])])

    def __check_thresh__(self, item, param):
        sss = 0
        ij = 0
        for val in param['thresholds']:
            
            if item[0][self.__get_numarray(item, val[0])] < val[1]:
                sss = sss + 1
            ij = ij + 1
        if sss == ij:
            #print(item[1], item[2])
            # return 0
            return np.NaN
        #print('ok')    
        return 1

    def __mpSquareRelation__(self, item, param):
        """
            Method to map integral relations in point1+/-interval1 and point2+/-interval2
        """
        if np.isnan(self.__check_thresh__(item, param)):

            return np.NaN
        a_= item[0][
                      self.__get_numarray(item, param['points'][0] - param['intervals'][0]):self.__get_numarray(item,
                                                                                                                param[
                                                                                                                    'points'][
                                                                                                                    0] +
                                                                                                                param[
                                                                                                                    'intervals'][
                                                                                                                    0])]
        if len(a_)==1: 
            n1 = a_[0]
        else:      
            n1 = np.trapz(a_)
        a_= item[0][
                      self.__get_numarray(item, param['points'][1] - param['intervals'][1]):self.__get_numarray(item,
                                                                                                                param[
                                                                                                                    'points'][
                                                                                                                    1] +
                                                                                                                param[
                                                                                                                    'intervals'][
                                                                                                                    1])] 
        if len(a_)==1:
            n2 = a_[0]
        else:      
            n2 = np.trapz(a_)       

        if (not n1) and (not n2):
            # return 0
            print('fff')
            return np.NaN
        r_ = n1 / n2
        return r_
        
    def __mpSubstractSquares__(self, item, param):
        """
            Method to map integral substrations between point1+/-interval1 and point2+/-interval2
        """
        if np.isnan(self.__check_thresh__(item, param)):
            return np.nan
        n1 = np.trapz(item[0][
                      self.__get_numarray(item, param['points'][0] - param['intervals'][0]):self.__get_numarray(item,
                                                                                                                param[
                                                                                                                    'points'][
                                                                                                                    0] +
                                                                                                                param[
                                                                                                                    'intervals'][
                                                                                                                    0])])
        n2 = np.trapz(item[0][
                      self.__get_numarray(item, param['points'][1] - param['intervals'][1]):self.__get_numarray(item,
                                                                                                                param[
                                                                                                                    'points'][
                                                                                                                    1] +
                                                                                                                param[
                                                                                                                    'intervals'][
                                                                                                                    1])])
        if not n1 and not n2:
            #return 0
            return np.nan

        if n1 > n2:
            return (n1 - n2) / n1
        else:
            return (n1 - n2) / n2

    def generate(self, method, param=None):
        """
            Map generator method
            param is a dictionary
            param={'points_m':[],'intervals':[],'thresholds':[[point,value]],'intervals':[]}
        """
        if param is None:
            param = {'points': [], 'intervals': [], 'thresholds': [[]]}
        x = np.array([it[1] for it in self.__map_spectra__.values()])
        y = np.array([it[2] for it in self.__map_spectra__.values()])
        z = np.ones(len(y))
        if method == 'PointRelation':
            z = np.array([self.__mpPointRelation__(item, param) for item in self.__map_spectra__.values()])
        if method == 'PointIntensity':
            z = np.array([self.__mpPointIntensity__(item, param) for item in self.__map_spectra__.values()])
        if method == 'Square':
            z = np.array([self.__mpSquare__(item, param) for item in self.__map_spectra__.values()])
        if method == 'SquareRelation':
            z = np.array([self.__mpSquareRelation__(item, param) for item in self.__map_spectra__.values()])
        if method == 'SubstractSquares':
            z = np.array([self.__mpSubstractSquares__(item, param) for item in self.__map_spectra__.values()])
        return x, y, z
