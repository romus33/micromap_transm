import os
import re
import struct
import time as tm
from photonicdata_files_wip.wip_loader import WIPFile
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw
import numpy as np
import progressbar as pb
import pickle
from pathlib import Path
from typing import Any, Dict, Union, List

'''
Ignore the warnings when filters are applied
'''
np.seterr(divide='ignore', invalid='ignore')

# _round_to = lambda num, digits: 0 if num == 0 else round(num, max(int(-math.floor(math.log10(abs(num - int(num))))) + digits - 1, digits))
import sys

def colored(text, color=None, on_color=None, attrs=None):
    """
    Безопасная замена termcolor.colored.
    Использует только ANSI escape-коды и не вызывает shell-команды (sh, tput, color),
    что критично для работы multiprocessing.
    """
    # Если вывод перенаправлен не в терминал, просто возвращаем текст
    if not sys.stdout.isatty() and not os.environ.get("FORCE_COLOR"):
        return str(text)

    ANSI_COLORS = {
        'grey': 30, 'red': 31, 'green': 32, 'yellow': 33,
        'blue': 34, 'magenta': 35, 'cyan': 36, 'white': 37,
        'light_grey': 37, 'dark_grey': 90, 'light_blue': 94,
    }
    
    code = ANSI_COLORS.get(color, 0)
    
    if code == 0:
        return str(text)
        
    return f"\033[{code}m{text}\033[0m"

class Wip_map():
    def __init__(self, filename):
        self.wip = WIPFile(filename)
    
    def read_data_single_map(self, num=0, info = False):
        a = self.read_data(info = info)
        return a[num] 
       
    def read_data(self, info = False):
        tdgraphs = self.wip.data_td(keep=["TDGraph"])
        bitmap = self.wip.data_td(keep = ["TDBitmap"])
        #self.wip.export(zip=True)
        matrix_dict_list = []
        for tdg in tdgraphs:
            x = np.float32(tdg.raman_shift)
            wl_array = np.array(tdg.wl, dtype = 'float64')
            shift_array = np.float64((10**7)/tdg.excitation_wl) -(10**7)/wl_array
            
            x = shift_array
            x_min = np.min(x)
            x_max = np.max(x)
            x_length = len(x)
            x_step = (x_max-x_min)/(x_length-1)
            for btmp in bitmap:
                coords_all = btmp.project_to_model(tdg, round=False)
                coords = [tuple(l[:2]) for l in coords_all]
            tdg.export()
            if tdg.is_exportable and tdg.is_valid_spectra:
                # Fine datanumber of the related TDText object with metadata
                # In case of duplicated captions sort_order="auto" may be required (see docs)
                
                tdtext_datanumber = self.wip.find_related(tdg.datanumber, by="caption",
                                                    keep="TDText", sort_order="auto",
                                                    soft_matches=True)           
                if len(tdtext_datanumber) > 0:
                    # load metadata if a related TDText is found
                    metadata = self.wip.data_td(tdtext_datanumber[0]).content()
                    if info == True:
                        print(metadata)
                    points_per_line = int(metadata['Points per Line'])
                    num_lines = int(metadata['Lines per Image'])               
                    coords_rect = [tuple(l[:2]) for l in coords]
                   
                    matrix_dict = self.create_matrix_dict(tdg.spectra_matrix, coords_rect, x_min, x_max, x_length, x_step, points_per_line, num_lines, x)
                    matrix_dict_list.append(matrix_dict)
        return matrix_dict_list
                
                         
    def plot_wip_image(self):
        tdgraphs = self.wip.data_td(keep=["TDGraph"])
        bitmap = self.wip.data_td(keep = ["TDBitmap"])
        self.wip.export(zip=True)
        for tdg in tdgraphs:
            for btmp in bitmap:
                coords = btmp.project_to_model(tdg, round=False)
                img = Image.fromarray(btmp.image_matrix)
                draw = ImageDraw.Draw(img)
                draw.polygon([tuple(l[:2]) for l in coords], outline="red", width=2)
                plt.imshow(img)        
                plt.show()    

    def create_matrix_dict(self, spectral_matrix, coords_rect, x_min, x_max, x_length, x_step, points_per_line, num_lines, x_arr):
        """
        Создает массив словарей с координатами и спектрами для каждой точки измерения.
        
        Parameters:
        spectral_matrix : numpy.ndarray
            3D массив спектров размером (num_lines, points_per_line, spectral_length)
        coords_rect : list of tuples
            Список координат углов в порядке: верхний-левый, верхний-правый, нижний-правый, нижний-левый
        
        Returns:
        list of dict
            Список словарей с ключами 'x', 'y', 'spectrum'
        """
        # Получаем размеры матрицы измерений
        corners = np.array(coords_rect)
        
        # Вычисляем вектора для интерполяции
        top_edge = corners[1] - corners[0]    # Верхняя грань
        bottom_edge = corners[2] - corners[3] # Нижняя грань
        
        # Создаем сетку индексов для интерполяции
        x_idx = np.linspace(0, 1, points_per_line)
        y_idx = np.linspace(0, 1, num_lines)
        
        matrix_dict = {}
        
        for i in range(num_lines):
            for j in range(points_per_line):
                # Вычисляем индекс в плоском списке
                idx = i * points_per_line + j
                
                # Интерполяция по горизонтали (вдоль строки)
                top_point = corners[0] + top_edge * x_idx[j]
                bottom_point = corners[3] + bottom_edge * x_idx[j]
                
                # Интерполяция по вертикали (между верхней и нижней точкой)
                point = top_point + (bottom_point - top_point) * y_idx[i]
                
                # Добавляем запись в результирующий массив
                name = str(int(point[0])) + '_' + str(int(point[1]))
                #x_eval = np.arange(x_min,x_max,x_step)
                #print(len(x_eval), len(x_arr))
                y_ = np.interp(np.linspace(x_min,x_max,x_length), x_arr, np.array(spectral_matrix[idx].tolist() if hasattr(spectral_matrix[idx], 'tolist') else spectral_matrix[idx]))
                matrix_dict[name] = [y_, int(point[0]), int(point[1]), x_length, x_length,x_min, x_max,x_step]
                
        
        return matrix_dict

class MapEdit(object):
    """
    This class contains methods that can open, edit and save copy of .floats, Witec and Horiba hyperspectral map files
    Arguments:
        __map_spectra__: Each element having name [str(mx) + '_' + str(my)] of the dictionary contains the spectrum measured at point x, y of the hyperspectral map with the following structure:
               [np.array(spectrum), mx, my, nv, nr, x1, x2, step]
                    np.array(spectrum): ordinate values of spectrum in the hyperspectral map in the point with mx, my coordinate
                    mx: x-coordinate of the point in the hyperspectral map
                    my: y-coordinate of the point in the hyperspectral map
                    nv: number of points in the spectrum np.array(spectrum)
                    nr: number of points in the reduced spectrum np.array(spectrum). The value is equal to nv in the most cases
                    x1: minimal wavenumber in the spectrum
                    x2: maximum wavenumber in the spectrum
                    step: distance between adjacent x values (step of wavenumber measurement)
        in_filename: input filename
        minx: minimum wavenumber of spectrum in all elements of hyperspectral map.
                default value: -1 means that initial minimum value is used
        maxx: maximum wavenumber of spectrum in all elements of hyperspectral map.
                default value: -1 means that initial maximum value is used.
        __pBar__: progress bar initialization

    """

    def __init__(self, in_filename, minx=-1, maxx=-1):
        """
        Constructor of MapEdit class

        Args:
            in_filename: input filename
            minx: minimum wavenumber of spectrum in all elements of hyperspectral map.
                default value: -1 means that initial minimum value is used
            maxx: maximum wavenumber of spectrum in all elements of hyperspectral map.
                default value: -1 means that initial maximum value is used.
        """
        self.in_filename = in_filename
        self.__map_spectra__ = {}
        """if you want to cut spectra in hyperspectral map you should set minx and maxx values and the spectra is adjusted in the [minx, maxx] range"""
        self.minx = minx
        self.maxx = maxx
        # Init progress bar element
        self.__pBar__ = pb.ProgressBar(tm.time())
    def read_wip(self, number = 0, info = False):
        wip_matrix = Wip_map(self.in_filename)
        
        self.__map_spectra__ = wip_matrix.read_data_single_map(number, info = info)
        if not((self.minx == -1) and (self.maxx == -1)):
                for key, item in self.__map_spectra__.items():
                    self.__map_spectra__[key] = self.__reduce_spectrum__(item)         
        return self.__map_spectra__ 
    
    
    def read(self):
        """
          Open and read file .floats from Simex Fourer spectrometer equipped Micran-3 infrared microscope. The hyperspectral map is reading to self.__map_spectra__ dictionary.

          Returns:
             self.__map_spectra__: Each element of the dictionary contains the spectrum measured at point x, y of the hyperspectral map with the following structure:
               [np.array(spectrum), mx, my, nv, nr, x1, x2, step]
                    np.array(spectrum): ordinate values of spectrum in the hyperspectral map in the point with mx, my coordinate
                    mx: x-coordinate of the point in the hyperspectral map
                    my: y-coordinate of the point in the hyperspectral map
                    nv: number of points in the spectrum np.array(spectrum)
                    nr: number of points in the reduced spectrum np.array(spectrum). The value is equal to nv in the most cases
                    x1: minimal wavenumber in the spectrum
                    x2: maximum wavenumber in the spectrum
                    step: distance between adjacent x values (step of wavenumber measurement)
        """

        with open(self.in_filename, 'rb') as f:
            length = os.stat(self.in_filename).st_size
            # print(l)
            print('Reading ' + colored(self.in_filename, 'blue') + ' file:')
            self.__pBar__.printProgressBar(0, length, prefix='Progress:', suffix='', length=50)
            count_i = 0

            while True:
                h = f.read(20)
                if not h:
                    break
                mx, my, nv, nr, x1, x2 = struct.unpack('<iihhff', h)

                if nv <= 0:
                    break
                spectrum = struct.unpack('<' + nv * 'f', f.read(nv * 4))
                step = (x2 - x1) / (nr - 1)
                if (self.minx == -1) and (self.maxx == -1):
                    self.__map_spectra__[str(mx) + '_' + str(my)] = [np.array(spectrum), mx, my, nv, nr, x1, x2, step]
                else:
                    # if minx and maxx have been setuped the all spectra in hyperspectral map are transformed
                    self.__map_spectra__[str(mx) + '_' + str(my)] = self.__reduce_spectrum__(
                        [np.array(spectrum), mx, my, nv, nr, x1, x2, step])  # reduce_spectrum
                count_i = count_i + 20 + nv * 4

                self.__pBar__.printProgressBar(count_i, length, prefix='Progress:', suffix='', length=50)
        f.close()
        return self.__map_spectra__

    def read_raman_map(self):
        """
        Read hyperspectral Raman map measured with Witec Raman microscope. The hyperspectral map is reading to self.__map_spectra__ dictionary.

        Returns:
            self.__map_spectra__: Each element of the dictionary contains the spectrum measured at point x, y of the hyperspectral map with the following structure:
               [spectrum, mx, my, nv, nr, x1, x2, step]
                    spectrum: ordinate values of spectrum in the hyperspectral map in the point with mx, my coordinate
                    mx: x-coordinate of the point in the hyperspectral map
                    my: y-coordinate of the point in the hyperspectral map
                    nr: number of points in the spectrum
                    nr: number of points in the spectrum (for compatibility with self.read() method Returns
                    x1: minimal wavenumber in the spectrum
                    x2: maximum wavenumber in the spectrum

        """

        print('Reading Raman map file: ' + colored(self.in_filename, "blue"))
        map_spectra = open(self.in_filename, encoding="cp1251").readlines()
        xpoints = int(map_spectra[6].split()[-1])
        inds = (i.replace("/", "_") for i in re.findall("(\\d+/\\d+)", map_spectra[17]))
        map_spectra = [map_spectra[i].split() for i in range(19, xpoints + 19)]
        xvalues = np.array([np.float(row[0]) for row in map_spectra])
        x1, x2, step = xvalues[0], xvalues[-1], 1
        xarr = np.arange(x1, x2 + step, step)
        nr = len(xarr)
        self.__map_spectra__ = {ind: [np.interp(xarr, xvalues, np.array([np.float(row[i]) for row in map_spectra])),
                                      *(int(j) for j in ind.split('_')), nr, nr, x1, x2, step] for i, ind in
                                enumerate(inds, 1)}
        return self.__map_spectra__

    def read_raman_horiba(self):
        """
        Read hyperspectral Raman map measured with Horiba Raman microscope. The hyperspectral map is reading to self.__map_spectra__ dictionary.

        Returns:
            self.__map_spectra__: Each element of the dictionary contains the spectrum measured at point x, y of the hyperspectral map with the following structure:
               [spectrum, mx, my, nv, nr, x1, x2, step]
                    spectrum: ordinate values of spectrum in the hyperspectral map in the point with mx, my coordinate
                    mx: x-coordinate of the point in the hyperspectral map
                    my: y-coordinate of the point in the hyperspectral map
                    nr: number of points in the spectrum
                    nr: number of points in the spectrum (for compatibility with self.read() method Returns
                    x1: minimal wavenumber in the spectrum
                    x2: maximum wavenumber in the spectrum

        """
        map_spectra = open(self.in_filename, encoding="cp1251").readlines()
        wn = np.array(map_spectra[0].split(), dtype=float)
        x1 = wn.min()
        x2 = wn.max()
        nr = len(wn)
        step= (x2-x1)/(nr-1)
        for row in map_spectra[1:]:
            data = np.array(row.split(), dtype=float)
            mx = float(data[0])*100
            my = float(data[1])*100
            ind=str(mx)+'_'+str(my)
            spectrum=data[2:]
            # print(ind)
            # print(spectrum)
            self.__map_spectra__[ind] = [np.array(spectrum), int(mx), int(my), nr, nr, x1, x2, step]

        return self.__map_spectra__
    
    def reduce_map(self, rect=None):
        """
        Reduce hyperspectral map.

        Args:
            rect: {'xmin': 0, 'xmax': 0, 'ymin': 0, 'ymax': 0}
            A dictionary that contains the coordinates of the rectangle to which the map will be scaled.

        Note: The map should be read using read(), read_raman_map() or read_raman_horiba() methods.

        Returns:
            The reduced inside rectangular coordinates map in dictionary format.
                self.__map_spectra__: Each element of the dictionary contains the spectrum measured at point x, y of the hyperspectral map with the following structure:
               [spectrum, mx, my, nv, nr, x1, x2, step]
                    spectrum: ordinate values of spectrum in the hyperspectral map in the point with mx, my coordinate
                    mx: x-coordinate of the point in the hyperspectral map
                    my: y-coordinate of the point in the hyperspectral map
                    nr: number of points in the spectrum
                    nr: number of points in the spectrum (for compatibility with self.read() method Returns
                    x1: minimal wavenumber in the spectrum
                    x2: maximum wavenumber in the spectrum

        """
        if rect is None:
            rect = {'xmin': 0, 'xmax': 0, 'ymin': 0, 'ymax': 0}
        return {k: v for k, v in self.__map_spectra__.items() if
                rect['xmin'] <= v[1] <= rect['xmax'] and rect['ymin'] <= v[2] <= rect['ymax']}

    def delete_points(self, points=None):
        """
        Delete points using their coordinates from hyperspectral map self.__maps_spectra__

        Args:
            points[(x,y)]: points is an array consists of pairs of (x,y) values that should be deleted
        """
        if points is None:
            points = []
        for x, y in points:
            key_to_delete = str(x) + '_' + str(y)
            try:
                self.__map_spectra__.pop(key_to_delete)
            except KeyError:
                pass

    
    def delete_points_str(self, str_=None):
        """
        Delete points using name of points in the dictionary map self.__maps_spectra__

        Args:
            str_=['x_y']: array of strings with names in self.__maps_spectra__
        """
        if str_ is None:
            str_ = []
        for item in str_:
            try:
                self.__map_spectra__.pop(item)
            except KeyError:
                pass

    @staticmethod
    def __get_numarray(item, wavenumber):
        """
        Private method to get corresponding array element number of wavenumber

            Args:
                item: dictionary in format of self.__maps_spectra__
                wavenumber: float values of finding wavenumber

            Returns:
                number of element in array item[0] the elements with wavenumber
        """
        return int((wavenumber - item[5]) / item[7])

    def __reduce_spectrum__(self, item):
        """
        Private method to reduce wavenumber in spectrum in the range [self.minx, self.maxx]

            Args:
                item: dictionary in format of self.__maps_spectra__
            Returns:
                item: dictionary with reduced wavenumbers  [self.minx, self.maxx]
        """
        if self.minx > self.maxx:
            self.minx, self.maxx = self.maxx, self.minx
        if self.minx < item[5]:
            n1 = 0
            # print('Low bound is out of range and set 0')
        else:
            n1 = self.__get_numarray(item, self.minx)
        if self.maxx > item[6]:
            n2 = item[3] - 1
            # print('High bound is out of range')
        else:
            n2 = self.__get_numarray(item, self.maxx)

        item[0] = item[0][n1:n2]
        item[5] = self.minx
        item[6] = self.maxx
        item[3] = len(item[0])
        item[4] = len(item[0])
        return item

    def writefloats(self, fname, floats_data=None):
        """
        Method to write new .floats file

        Args:
            fname: filename of write .floats file (string)
            floats_data: dictionary in format self.__maps_spectra__
        """
        if floats_data is None:
            floats_data = {}
        data = floats_data
        if not data:
            data = self.__map_spectra__
        length = len(data)
        print('Writing ' + fname + ' file:')
        self.__pBar__.printProgressBar(0, length, prefix='Progress:', suffix='', length=50)
        i = 0

        with open(fname, 'wb') as v:
            for item in data.values():
                v.write(struct.pack('<iihhff', *item[1:-1]))
                v.write(struct.pack('<' + item[3] * 'f', *item[0]))
                i = i + 1
                # time_elapsed=' '+str(int(tm.time()-time0))+' sec'
                self.__pBar__.printProgressBar(i, length, prefix='Progress:', suffix='', length=50)
                # return 0
    def save_fit_results(
        self,
        filename: Union[str, Path],
        x: List[Any],
        y: List[Any],
        z_dict: Dict[str, Any],
        array_dict: Dict[str, Any],
        params: Dict[str, Any],
    ) -> None:
        """
        Сохраняет результаты фитинга в pickle-файл.

        Параметры:
            filename (str | Path):
                Путь к файлу, в который нужно сохранить данные.
                Например: "results/fit_results.pkl".

            x:
                Массив или список координат x.
                Обычно это 1D-массив: [x1, x2, x3, ...].

            y:
                Массив или список координат y.
                Обычно это 1D-массив: [y1, y2, y3, ...].

            z_dict (dict):
                Словарь с z-данными.
                Например:
                    {
                        "z_fit": z_fit_array,
                        "z_residual": z_residual_array
                    }

            array_dict (dict):
                Словарь с результами подгонки (спектрами)
                    {
                        "raw": raw_array,
                        "mask": mask_array
                    }

            params (dict):
                Словарь с параметрами фитинга:
                    {
                        "method": "Gaussian",
                        "amplitude": 1.23,
                        "sigma": 0.45
                    }

        Возвращает:
            None

        Пример использования:
            self.save_fit_results(
                filename="fit_results.pkl",
                x=x_data,
                y=y_data,
                z_dict={
                    "z_fit": z_fit,
                    "z_residual": z_residual
                },
                array_dict={
                    "raw": raw_array,
                    "mask": mask_array
                },
                params={
                    "model": "gauss",
                    "popt": popt,
                    "pcov": pcov
                }
            )
        """

        data = {
                "x": x,
                "y": y,
                "z_dict": z_dict,
                "array": array_dict,
                "params": params
            }

        filename = Path(filename)

        with open(filename, "wb") as f:
                pickle.dump(data, f, protocol=pickle.HIGHEST_PROTOCOL)

        print(f"Данные сохранены в файл: {filename}")


    def load_fit_results(self, filename: Union[str, Path]):
        """
        Параметры:
        filename (str | Path):
            Путь к файлу, в который нужно сохранить данные.
            Например: "results/fit_results.pkl".        
        Возвращает
        x:
            Массив или список координат x.
            Обычно это 1D-массив: [x1, x2, x3, ...].

        y:
            Массив или список координат y.
            Обычно это 1D-массив: [y1, y2, y3, ...].

        z_dict (dict):
            Словарь с z-данными.
            Например:
                {
                    "z_fit": z_fit_array,
                    "z_residual": z_residual_array
                }

        array_dict (dict):
            Словарь с результами подгонки (спектрами)
                {
                    "raw": raw_array,
                    "mask": mask_array
                }

        params (dict):
            Словарь с параметрами фитинга:
                {
                    "method": "Gaussian",
                    "amplitude": 1.23,
                    "sigma": 0.45
                }
        """
        filename = Path(filename)

        with open(filename, "rb") as f:
            data = pickle.load(f)
        if "x" in data:
            x = data["x"]
        else:
            x = None
        if "y" in data:
            y = data["y"]
        else:
            y = None
        if "z_dict" in data:
            z_dict = data["z_dict"]
        else:
            z_dict = None
        if "array" in data:
            array_ = data['array']
        else:
            array_ = None
        if "params" in data:
            params = data["params"]
        else:
            params = None
        return x, y, z_dict, array_, params
