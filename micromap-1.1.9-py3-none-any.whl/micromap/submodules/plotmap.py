from collections import OrderedDict
import matplotlib.cm as cm
import matplotlib as mpl
import matplotlib.colors as colors
import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import griddata
from scipy.spatial import cKDTree as KDTree
from scipy.interpolate import RegularGridInterpolator
# num_proc = 4
# _round_to = lambda num, digits: 0 if num == 0 else round(num, max(int(-math.floor(math.log10(abs(num - int(num))))) + digits - 1, digits))
import sys
import os

def colored(text, color=None, on_color=None, attrs=None):
    """
    Безопасная замена termcolor.colored.
    Использует только ANSI escape-коды и не вызывает shell-команды (sh, tput, color),
    что критично для работы multiprocessing.
    """
    # Если вывод перенаправлен не в терминал, просто возвращаем текст
    if not sys.stdout.isatty() and not os.environ.get("FORCE_COLOR"):
        return str(text)

    ANSI_COLORS = {
        'grey': 30, 'red': 31, 'green': 32, 'yellow': 33,
        'blue': 34, 'magenta': 35, 'cyan': 36, 'white': 37,
        'light_grey': 37, 'dark_grey': 90, 'light_blue': 94,
    }
    
    code = ANSI_COLORS.get(color, 0)
    
    if code == 0:
        return str(text)
        
    return f"\033[{code}m{text}\033[0m"

class PlotMap(object):
    """
    The class for drawing of maps using matplotlib
    """

    def __init__(self, map_spectr, x, y, z):
        self.x = x
        self.y = y
        self.z = z
        self.line_white = OrderedDict()
        self.map_spectra = map_spectr

    @staticmethod
    def plot_contour(x, y, z, resolution=256, contour_method='linear'):
        """"
         Construct optimal contour with correct boundaries
        """
        # z=np.array(z,dtype=float)
        X, Y = np.meshgrid(np.linspace(x.min(), x.max(), resolution), np.linspace(y.min(), y.max(), resolution))
        Z = griddata([[a, b] for a, b in zip(x, y)], z, (X, Y), method=contour_method, rescale=True)
        tree = KDTree(np.c_[x, y])
        dist, _ = tree.query(np.c_[X.ravel(), Y.ravel()], k=1)
        dist = dist.reshape(X.shape)
        Z[dist > (1.8 * np.ma.median(dist))] = np.nan
        return X, Y, Z

    def generate_contour(self, resolution, method):
        """
        Generate contoutor
        """
        print(colored('x,y,z contour has been generated', 'cyan'))
        X, Y, Z = self.plot_contour(self.x, self.y, self.z, resolution, method)
        return X, Y, Z

    def plot_color_map_with_spectra(self, array_dict=None, pallette=cm.get_cmap('jet'), resolution=256,
                                    contour_method='linear', vmin=None, vmax=None, nchunk=2000):
        # Plot color contour with clickable spectra, if you need draw baseline or other data you can give there in the dict array_dict. array_dict[0] is x-axis, array_dic[1] is y. Key is coordinates of points
        if vmin is None:
            vmin = np.nanmin(self.z)
        if vmax is None:
            vmax = np.nanmax(self.z)
        fig, ax = plt.subplots()
        #cmap = plt.get_cmap('BrBG')
        #cmap.set_bad('white')
        # print(colored('Plotting color map in ' + pallette + ' pallette', 'cyan'))
        X, Y, Z = self.plot_contour(self.x, self.y, self.z, 256, contour_method)
        # res=np.linspace(int(self.z.min()),int(self.z.max()),resolution)
        # norm =colors.BoundaryNorm(res,len(res))
        #dr=np.linspace(self.z.min(),self.z.max(), 6)
        
        contourf_ = ax.contourf(X, Y, Z,  resolution, vmin=vmin, vmax=vmax, cmap=pallette, antialiased='True',nchunk=nchunk)#, levels=dr)
        #ax.contour(X,Y,Z,colors=['red','blue'])
        #ax.clabel(contourf_, fmt='%2.2f', colors='w', fontsize=14)
        ax.set_aspect('equal')
        ax.plot(self.x, self.y, 'ko', linewidth=1.5, alpha=0.3)
        fig.colorbar(contourf_, ax=ax)
        xy_points = [(item[1], item[2]) for item in self.map_spectra.values()]
        ax.plot([self.x.min(), self.x.min() + (self.x.max() - self.x.min()) / 4],
                [self.y.min() - self.y.min() * 0.003, self.y.min() - self.y.min() * 0.003], '-k', linewidth=5)
        length_mkm = (self.x.max() - self.x.min()) * 3.175 / 4
        lbl_txt = f"{length_mkm:.0f}" + ' mkm'
        print(lbl_txt)
        ax.text(self.x.min() + (self.x.max() - self.x.min()) / 8, self.y.min() - self.y.min() * 0.002, lbl_txt,
                ha='center', va='center')

        fig1, ax1 = plt.subplots()
        # if not array_dict:
        fig.canvas.mpl_connect('button_press_event',
                               lambda event: self.__onclick__(event, xy_points, fig1, ax1, fig, ax, array_dict))
        #polygons_coords = contourf_.allsegs
        # paths = contourf_.collections[0].get_paths()
        #help(paths[0])
        #polygon_kinds = contourf_.allkinds
        """
        level_old=None
        diff_=0
        for level, collection in zip(contourf_.levels[1:], contourf_.collections):
            print(collection)
            print(f"%% Level {level} %%")
            if level_old is None:
                level_old=level
            else:
                diff_=level-level_old

            if diff_<10:
                color='grey'
            if (diff_>=10) and (diff_<25):
                color='black'
            if (diff_>=25) and (diff_<35):
                color='yellow'
            if (diff_>=35) and (diff_<55):
                color='goldenrod'
            if (diff_>=55) and (diff_<65):
                color='red'   
            #print(collection.get_paths()[0].to_polygons()[:0])
            for g_ in  collection.get_paths()[0].to_polygons()[0]: 
                print(g_)     
                #ax.plot(g_[0], g_[1], "--", color=color, linewidth=3.0)
        
        
        color_=mpl.cm.get_cmap('Set1')
        for num_, i_ in enumerate(polygons_coords):
            #print(i_)
            # print(polygon_kinds[num_])
            for numj_, j_ in enumerate(i_):
                print(polygon_kinds[num_][numj_])
                ax.plot(j_[:, 0], j_[:, 1], "--", color=color_(1), linewidth=1.0) 

                polygons_coords = contourf_.allsegs #[0][0]
        
        polygons_values = contourf_.levels
        print(polygons_values)
        color=['grey', 'black','yellow','goldenrod','red','blue', 'pink', 'orange','brown','magenta']
        print(polygons_coords)
        for i_ in range(len(polygons_values)-1):
            
            diff_=(polygons_values[i_+1]-polygons_values[i_])*203.3
            if diff_<10:
                color='grey'
            if (diff_>=10) and (diff_<25):
                color='black'
            if (diff_>=25) and (diff_<35):
                color='yellow'
            if (diff_>=35) and (diff_<55):
                color='goldenrod'
            if (diff_>=55) and (diff_<65):
                color='red'
            #print(polygons_coords[i_] )
            print(i_)
            try:
                int_one=polygons_coords[i_][0]
                                           
                ax.plot(int_one[:, 0], int_one[:, 1], "--", color=color[i_], linewidth=3.0)
            except:
               print('eee')   """   
        #ax.plot(the_interesting_one[:, 0], the_interesting_one[:, 1], "r--", color='red')
        #return contourf_

    def plot_bounded(self, bounds, array_dict=None, pallette='Greys', resolution=256, contour_method='linear'):
        # Plot bounded contour with clickable spectra. bounds is array with boundaries between colors. If you need draw baseline or other data you can give there in the dict array_dict. array_dict[0] is x-axis, array_dic[1] is y. Key is coordinates of points
        print(colored('Plotting bound map in ' + pallette + ' pallette', 'cyan'))
        fig, ax = plt.subplots()
        X, Y, Z = self.plot_contour(self.x, self.y, self.z, resolution, contour_method)
        norm = colors.BoundaryNorm(boundaries=bounds, ncolors=resolution)
        contourf_ = ax.pcolormesh(X, Y, Z, cmap=pallette, norm=norm)
        
        ################################################################################
        ax.plot(self.x, self.y, 'ko', alpha=0.3)
        ax.set_aspect('equal')
        fig.colorbar(contourf_, ax=ax)
        xy_points = [(item[1], item[2]) for item in self.map_spectra.values()]
        ax.plot([self.x.min(), self.x.min() + (self.x.max() - self.x.min()) / 4],
                [self.y.min() - self.y.min() * 0.004, self.y.min() - self.y.min() * 0.004], '-k', linewidth=5)
        length_mkm = (self.x.max() - self.x.min()) * 3.175 / 4
        lbl_txt = f"{length_mkm:.0f}" + ' mkm'
        print(lbl_txt)
        ax.text(self.x.min() + (self.x.max() - self.x.min()) / 8, self.y.min() - self.y.min() * 0.0035, lbl_txt,
                ha='center', va='center')
        fig1, ax1 = plt.subplots()
        # if not array_dict:
        fig.canvas.mpl_connect('button_press_event', lambda event: self.__onclick__(event, xy_points, fig1, ax1, fig, ax, array_dict))

    @staticmethod
    def __dist2__(x, y, a, b):
        t1 = a - x
        t2 = b - y
        return t1 * t1 + t2 * t2

    @staticmethod
    def show():
        plt.rcParams['savefig.dpi'] = 600
        plt.show()

    def __onclick__(self, event, xy_points, fig1, ax1, fig, ax, array_map):
        # Draw spectra and additional dta when click
        cmap = cm.get_cmap('tab20')
        x, y = event.xdata, event.ydata
        a, b = min([(self.__dist2__(x, y, a, b), (a, b)) for a, b in xy_points])[1]
        str_coord = str(a) + '_' + str(b)
        for key, value in self.line_white.items():
            if key == str_coord:
                tmp_v = value[0]
                tmp_p = value[1]
                tmp_c= value[4]
                ll = tmp_v.pop(0)
                k = tmp_p.pop(0)
                for l1 in tmp_c:
                    l1.set_linestyle('None')
                    l1.remove()
                del tmp_c
                ll.remove()
                k.remove()                
                self.line_white.pop(key, value)
                fig.canvas.draw()
                fig1.canvas.draw()
                fig1.canvas.flush_events()
                return

        plot_tmp = ax.plot(a, b, 'wo')
        fig.canvas.draw()
        item = self.map_spectra[str(a) + '_' + str(b)]
        x = np.linspace(item[5], item[6], item[3])
        y = item[0]
        line = ax1.plot(x, y, color=cmap(len(self.line_white)), label=str_coord)
        if array_map:
            name_=str(item[1]) + '_' + str(item[2])
            xz1 = np.linspace(array_map[name_][5],
                              array_map[name_][6],
                              array_map[name_][4])
            zz1 = array_map[name_][0]

            line_b = ax1.plot(xz1, zz1, '--', color=cmap(len(self.line_white)))
            ad=[]
            if len(array_map[name_])>8:
                ad=xz1
                ad=np.vstack([ad, zz1])
                for model_name, model_value in array_map[name_][8].items():
                    if model_name == 'bg_':
                        line_b = line_b+ax1.plot(xz1, model_value, '--', color=cmap(len(self.line_white)))
                        ad = np.vstack([ad, model_value])
                    else:
                        line_b = line_b+ax1.plot(xz1, model_value + array_map[name_][8]['bg_'], '--', color=cmap(len(self.line_white)))
                        ad = np.vstack([ad, model_value + array_map[name_][8]['bg_']])
            self.line_white[str_coord] = [line, plot_tmp, x, y, line_b, ad]
        else:
            self.line_white[str_coord] = [line, plot_tmp, x, y, None]
        ax1.set(xlabel='Wavenumber [cm$^{-1}$]', ylabel='Intensity [arb. units.]', title="data at {} {}".format(a, b))
        print('(' + str(item[1]) + ':' + str(item[2]) + ')')
        ax1.legend()
        fig1.canvas.draw()
        fig1.canvas.flush_events()

    def save_selected(self, fname):
        # Save clicked spectra to fname ascii file
        print('Saving selected spectra to ' + colored(fname, 'blue'))
        result_arr = []
        comp_arr = {}
        key_arr = []
        stringg = ''
        # print(self.line_white)
        for key, value in self.line_white.items():
            stringg = stringg + "\t" + key + "\t"
            result_arr.append(value[2])
            result_arr.append(value[3])
            if len(value)>5:
                comp_arr[key]=value[5]
                tmp_ = np.array(value[5])
                tmp_ = tmp_.T
                np.savetxt(key + '.txt', tmp_, delimiter="\t")
            key_arr.append(key)
        result_arr = np.array(result_arr)
        result_arrT = result_arr.T
        np.savetxt(fname, result_arrT, delimiter="\t", header=stringg)
        return {'curve': result_arr, 'key': key_arr, 'components': comp_arr}

    @staticmethod
    def writemap(fname, x, y, z):
        # Write map (matrix) to the ascii file fname.map
        print('Writing map to ' + colored(str(fname), 'blue'))
        _x = sorted(list(set(x)))
        _y = sorted(list(set(y)))
        len_x = len_y = 6
        with open(fname, 'w') as v:
            print('0\t'.rjust(len_y) + '\t'.join(str(a).rjust(len_x) for a in _x), file=v)
            for j in _y:
                row = {a: "%.3f" % c for a, b, c in zip(x, y, z) if j == b}
                row = [row[a] if a in row.keys() else '' for a in _x]
                print(str(j) + '\t'.rjust(len_y) + '\t'.join(str(c).rjust(len_x) for c in row), file=v)
