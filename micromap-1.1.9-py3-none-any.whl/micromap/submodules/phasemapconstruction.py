import os
import numpy as np
from scipy.stats.stats import pearsonr
from sklearn.manifold import TSNE
from readwriteir5 import ReadWrite5
from r_pca import R_pca
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.decomposition import KernelPCA
# import sklearn.cluster as cluster

import sys
import os

def colored(text, color=None, on_color=None, attrs=None):
    """
    Безопасная замена termcolor.colored.
    Использует только ANSI escape-коды и не вызывает shell-команды (sh, tput, color),
    что критично для работы multiprocessing.
    """
    # Если вывод перенаправлен не в терминал, просто возвращаем текст
    if not sys.stdout.isatty() and not os.environ.get("FORCE_COLOR"):
        return str(text)

    ANSI_COLORS = {
        'grey': 30, 'red': 31, 'green': 32, 'yellow': 33,
        'blue': 34, 'magenta': 35, 'cyan': 36, 'white': 37,
        'light_grey': 37, 'dark_grey': 90, 'light_blue': 94,
    }
    
    code = ANSI_COLORS.get(color, 0)
    
    if code == 0:
        return str(text)
        
    return f"\033[{code}m{text}\033[0m"

class PhaseMapConstruction(object):
    """Class for phase maps construction. In this class different algorithms different point search on hyperspectral map is given
    Attributes:
        __map_spectra__(dict): The dictionary contains hyperspectral map. Each element having name [str(mx) + '_' + str(my)] of the dictionary contains the spectrum measured at point x, y of the hyperspectral map with the following structure:
               [np.array(spectrum), mx, my, nv, nr, x1, x2, step]
                    np.array(spectrum): ordinate values of spectrum in the hyperspectral map in the point with mx, my coordinate
                    mx: x-coordinate of the point in the hyperspectral map
                    my: y-coordinate of the point in the hyperspectral map
                    nv: number of points in the spectrum np.array(spectrum)
                    nr: number of points in the reduced spectrum np.array(spectrum). The value is equal to nv in the most cases
                    x1: minimal wavenumber in the spectrum
                    x2: maximum wavenumber in the spectrum
                    step: distance between adjacent x values (step of wavenumber measurement)
        xminn(float): set minimal value of abscissa axis in the spectra of hyperspectral map
        xmaxx(float): set maximal value of abscissa axis in the spectra of hyperspectral map
        i_tmp_map(int): the number of founded phases
        dict_phase(dict): The dictionary contains founded phases. The name of each dictionary element is 'phase' + str(number_of_phase) The structure is:
            ['phase' + str(num)] = [item_tmp, num, step_spectra, xmin, xmax, npoints]
            item_tmp(floats): array-like ordinate axis of a spectrum
            num(int): number of phase. The same to num in dictionary element name
            step_spectra(float): distance between adjacent x values (step of wavenumber measurement)
            xmin(float): minimal wavenumber in the spectrum
            xmax(float): maximum wavenumber in the spectrum
            npoints(int): length of item_tmp array
        foundedphases(dict): dictionary that contains founded in database phases. The name of each element is ['str(mx)_str(my)'].
            The structure of dictionary is
                {'num': ind, 'r': arr}
                'num': arrays of number of database record with suitable similarity
                'r': similarity value between spectra from database and hyperspectral map
        num_print(int): how many print records from foundedphases{}
        pca(dict): Dictionary contains pca coordinates when pca analysis is used.
            {'coordinates': reduced_data, 'variance': pca_.explained_variance_ratio_}
            'pca_coordinates': array of pca_coordinates measured for each point of hyperspectral map
            'variance': variance ratio of PCA for the point
        max_val(dict): Dictionary contains the spectrum of each phases with maximal intensity
            self.max_val['phase' + str(nnn + 1)] = [item_tmp, nnn]
            item_tmp(floats): y_array of spectrum
            nnn: number of phase
    """

    def __init__(self, map_spectr):
        """
        Initialization of class
        Args:
            map_spectr(dict): The dictionary contains hyperspectral map. Each element having name [str(mx) + '_' + str(my)] of the dictionary contains the spectrum measured at point x, y of the hyperspectral map with the following structure:
               [np.array(spectrum), mx, my, nv, nr, x1, x2, step]
                    np.array(spectrum): ordinate values of spectrum in the hyperspectral map in the point with mx, my coordinate
                    mx: x-coordinate of the point in the hyperspectral map
                    my: y-coordinate of the point in the hyperspectral map
                    nv: number of points in the spectrum np.array(spectrum)
                    nr: number of points in the reduced spectrum np.array(spectrum). The value is equal to nv in the most cases
                    x1: minimal wavenumber in the spectrum
                    x2: maximum wavenumber in the spectrum
                    step: distance between adjacent x values (step of wavenumber measurement)

        """
        self.__map_spectra__ = map_spectr
        self.xminn = 0
        self.xmaxx = 0
        self.i_tmp_map = 0
        self.dict_phase = {}
        self.foundedphases = {}
        self.num_print = 5
        self.pca={}
        self.max_val={}

    @staticmethod
    def find_nearest(array, value):
        """
        The method to find nearest value in array
        Args:
            array(floats): array where the value finding
            value(float): the finding value
        Returns:
            index of array with nearest value (int)
        """
        array = np.asarray(array)
        idx = (np.abs(array - value)).argmin()
        return idx
    @staticmethod
    def __get_numarray(item, wavenumber):
        """
            Private method to get corresponding array element number of wavenumber
        """
        return int((wavenumber - item[5]) / item[7])

    def __similarity__(self, item, param):
        """
           Find similarity between spectra using cosine, pearson or sorenson metrics
           Args:
               item(dict): element of maps_spectra dict, contains information about spectra in selected point
               [np.array(spectrum), mx, my, nv, nr, x1, x2, step]
                    np.array(spectrum): ordinate values of spectrum in the hyperspectral map in the point with mx, my coordinate
                    mx: x-coordinate of the point in the hyperspectral map
                    my: y-coordinate of the point in the hyperspectral map
                    nv: number of points in the spectrum np.array(spectrum)
                    nr: number of points in the reduced spectrum np.array(spectrum). The value is equal to nv in the most cases
                    x1: minimal wavenumber in the spectrum
                    x2: maximum wavenumber in the spectrum
                    step: distance between adjacent x values (step of wavenumber measurement)
                param(dict): The dictionary with parameters of similarity finding
                    'factor': each element contains pair of values.
                        The param['factor'][0] is the limit r-factor in similarity findings between hyperspectral members of map to construct phase map in dict_phases{}
                        The param['factor'][1] is the limit r-factor in similarity findings between dict_phase{} element and spectra in database
                        When similarity search occurs the two spectra is compaired and r-factor is calculated. If the calculated r-factor is lower than given in param['factor'] there is new phase.
                    'method'(str): similarity method. It could be cosine similarity, pearson similarity or sorenson similarity
                    'range': each element contains pair of values that determine range of x-values where spectra is compaired.
                        param['range'][0] - xmin
                        param['range'][1] - xmax
                        Default: all range is used
                    'thresholds': the array of paired elements. Each pair is [wavenumber, value_lim], when y-coordinate in x-coordinate=wavenumber in the spectrum is higher than value_lim the similarity procedure is calculated, else the point is skipped and classified to zero phase.
                        if thresholds contains several pairs of values the similarity calculation will be carried out if the y-coordinate at least at one point of wavenumber is greater than the corresponding value_lim.
                        It is simple selection method to delete the point having lower intensity of epoxy  region in the hyperspectral map.
                    'dbname'(str): the name of database where founded different phases will be identified. If dbname is not in the dictionary param the search in database is not performed.
        """
        item_tmp = np.nan_to_num(item[0])
        step_spectra = item[7]
        factor = param['factor'][0]
        method = param['method']
        if 'range' not in param:
            param['range'] = [item[5], item[6]]

        self.xminn = xmin = param['range'][0]
        if xmin < item[5]:
            xmin = item[5]

        self.xmaxx = xmax = param['range'][1]
        if xmax > item[6]:
            xmax = item[6]
        if 'thresholds' not in param:
            param['thresholds'] = [[xmin, 0]]
        sss = 0
        ij = 0

        for val in param['thresholds']:
            ij = ij + 1
            if item_tmp[self.__get_numarray(item, val[0])] < val[1]:
                sss = sss + 1
        if sss == ij:
            return 0.0

        item_tmp = item_tmp[self.__get_numarray(item, xmin):self.__get_numarray(item, xmax)]
        r = 0.1
        if self.i_tmp_map == 0:
            self.i_tmp_map = 1
            print(self.i_tmp_map, end='_')
            self.dict_phase['phase' + str(1)] = [item_tmp, self.i_tmp_map, step_spectra, xmin, xmax, len(item_tmp)]
            self.max_val['phase' + str(1)] = [item_tmp, 1]
            return self.i_tmp_map

        tmp_arr = []
        # print(factor)
        for key, value in self.dict_phase.items():
            # print(method)
            if method == 'cosine':
                # print(method)
                r = np.dot(item_tmp, value[0]) / (np.linalg.norm(item_tmp) * np.linalg.norm(value[0]))
            if method == 'pearson':
                r = pearsonr(item_tmp, value[0])[0]
            if method == 'sorenson':
                r = 1.0 - 2.0 * np.logical_and(item_tmp, value[0]).sum() / (value[0].sum() + item_tmp.sum())
            tmp_arr.append(r)
        tmp_arr = np.array(tmp_arr)
        nnn = np.argmax(tmp_arr)
        rrr = np.amax(tmp_arr)
        if rrr >= factor:
            if max(self.dict_phase['phase' + str(nnn + 1)][0]) < max(item_tmp):
                    self.max_val['phase' + str(nnn + 1)] = [item_tmp, nnn+1]
            else:
                self.max_val['phase' + str(nnn + 1)] = [self.dict_phase['phase' + str(nnn + 1)][0], nnn+1]
            return self.dict_phase['phase' + str(nnn + 1)][1] + rrr
        self.i_tmp_map = self.i_tmp_map + 1
        print(self.i_tmp_map, end='_')
        self.dict_phase['phase' + str(self.i_tmp_map)] = [item_tmp, self.i_tmp_map, step_spectra, xmin, xmax,
                                                          len(item_tmp)]

        z_val = self.i_tmp_map
        return z_val

    def generate(self, params=None):
        """
            Public method to generate map of phases using similarity between spectra.
            Args:
                params(dict): The dictionary with parameters of similarity finding
                    'factor': each element contains pair of values.
                        The param['factor'][0] is the limit r-factor in similarity findings between hyperspectral members of map to construct phase map in dict_phases{}
                        The param['factor'][1] is the limit r-factor in similarity findings between dict_phase{} element and spectra in database
                        When similarity search occurs the two spectra is compaired and r-factor is calculated. If the calculated r-factor is lower than given in param['factor'] there is new phase.
                    'method'(str): similarity method. It could be cosine similarity, pearson similarity or sorenson similarity
                    'range': each element contains pair of values that determine range of x-values where spectra is compaired.
                        param['range'][0] - xmin
                        param['range'][1] - xmax
                        Default: all range is used
                    'thresholds': the array of paired elements. Each pair is [wavenumber, value_lim], when y-coordinate in x-coordinate=wavenumber in the spectrum is higher than value_lim the similarity procedure is calculated, else the point is skipped and classified to zero phase.
                        if thresholds contains several pairs of values the similarity calculation will be carried out if the y-coordinate at least at one point of wavenumber is greater than the corresponding value_lim.
                        It is simple selection method to delete the point having lower intensity of epoxy  region in the hyperspectral map.
                    'dbname'(str): the name of database where founded different phases will be identified. If dbname is not in the dictionary params the search in database is not performed.
            Returns:
                x, y, z: coordinates of phase map. x, y - coordinates x, y  in hyperspectral map. z - number of found phase
        """
        if params is None:
            params = {}
        self.i_tmp_map = 0
        self.dict_phase={}
        self.max_val={}
        x = np.array([item[1] for item in self.__map_spectra__.values()])
        y = np.array([item[2] for item in self.__map_spectra__.values()])
        printphase = False
        if 'method' not in params:
            params['method'] = 'cosine'
        if 'factor' not in params:
            params['factor'] = [0.95, 0.95]
        print('')
        print(colored('Phase map construction using ' + params['method'] + ' similarity', 'cyan'))

        if 'dbname' in params:
            printphase = True

        z = np.array([self.__similarity__(item, params) for item in self.__map_spectra__.values()])
        for item in self.max_val.values():
            self.dict_phase['phase' + str(item[1])][0]=item[0]
        if printphase:
            print('.')
            print('---------------------')
            dbname = params['dbname']
            self.findphase(dbname, self.dict_phase, params)
        print('')
        return x, y, z

    def findphase(self, dbname, phases, params):
        """
            Method for find phase from database using cosine similarity with adjustment database record length and spectrum length.
            Args:

                dbname(str): name of database
                phases(dict): dictionary of found phases. The name of each dictionary elements is 'phase' + num) (i.e. phase1)
                    The structure of the dictionary is [item_tmp, num, step_spectra, xmin, xmax, len(item_tmp)]
                    item_tmp(floats): array-like ordinate values of spectrum of selected phase
                    num(int): number of phase. The same in the name of the dictionary element.
                    step_spectra(float): distance between neighbouring elements on x-axis in the item_tmp spectrum
                    xmin(float): min value on x-axis in the item_tmp spectrum
                    xmax(float): max value on x-axis in the item_tmp spectrum
                    step_spectra, xmin, xmax and lemgth of item_tmp are used to reconstruct x-axis (abscissa axis) of the item_tmp spectra.
        """
        fn = os.path.splitext(dbname)
        dbRead = ReadWrite5()

        if fn[1] == '.ir5':
            db = dbRead.readir5(fname=dbname)
            print(colored(str(db["nrecords"]), 'red') + ' records is reading from ' + colored(dbname, 'blue'))
            spectra = dbRead.getspectra_all_ir5(db)
        # if fn[1] == '.h5':
        #     db = dbRead.readh5(fname=dbname)
        #     spectra = dbRead.readh5_all(db)
            
        #     print(colored(str(len(spectra)), 'red') + ' records is reading from ' + colored(dbname, 'blue'))

        for keyP, valueP in phases.items():
            phX = np.linspace(valueP[3], valueP[4], valueP[5])
            fnd = {}
            if fn[1] == '.ir5':
                fnd = dbRead.findphase_ir5(phX, valueP[0], db, params['factor'][1])

                print(keyP, ":")
                if len(fnd["num"]) > self.num_print:
                    max_num = self.num_print
                else:
                    max_num = len(fnd["num"])
                for val in range(max_num):
                    print(format(fnd["r"][val], '.4f'), "|\t", spectra[str(fnd["num"][val])][2])
                self.foundedphases[keyP] = fnd                
            if fn[1] == '.h5':
                
                fnd = dbRead.find_phase_in(phX, valueP[0], dbname, params['factor'][1])
                spectra_ = sorted(fnd, key=lambda d: d['r'], reverse=True)
                print(keyP, ":")
                for val in spectra_:
                    print(val['name'], ':\t', val['r'])
                self.foundedphases[keyP] = fnd


            print(".............................")

    def generate_pca(self, params=None):
        """
        The method generate map of phases given from dimension reduction using PCA method.
        Args:
            params(dict): The dictionary contains PCA parameters:
                    'factor': r-factor for similarity comparison of PCA vectors. When similarity search occurs the two spectra is compaired and r-factor is calculated. If the calculated r-factor is lower than given in param['factor'] there is new phase.
                    'method'(str): similarity method. It could be cosine similarity, pearson similarity or sorenson similarity
                    'range': each element contains pair of values that determine range of x-values where spectra is compaired.
                        param['range'][0] - xmin
                        param['range'][1] - xmax
                        Default: all range is used
                     'components'(int): number of components in PCA. default: 2
                     'robust'(bool): enable r-PCA analysis.
        Returns:
            x, y, z: map of phases. x,y spatial coordinats, z - number of phase.

        """
        x = np.array([item[1] for item in self.__map_spectra__.values()])
        y = np.array([item[2] for item in self.__map_spectra__.values()])
        if 'method' not in params:
            params['method'] = 'cosine'
        if 'factor' not in params:
            params['factor'] = 0.95
        if 'components' not in params:
                params['components'] = 2
        comp_= params['components']
        abs_array = []
        self.xminn = xmin = params['range'][0]
        self.xmaxx = xmax = params['range'][1]

        for item in self.__map_spectra__.values():
            if xmax>item[6]:
                xmax=item[6]
            if xmin<item[5]:
                xmin=item[5]
            abs_array.append(item[0][self.__get_numarray(item, xmin):self.__get_numarray(item, xmax)])
        abs_array = np.array(abs_array)
        if 'robust' in params:
            L, S = R_pca(abs_array).fit(max_iter=500, iter_print=50)
            abs_array = np.array(L)

        print(colored('Calculate PCA coordinates', 'cyan'))
        if 'kernelPCA' in params:
            pca_= KernelPCA(kernel='linear', fit_inverse_transform=True, gamma=10)
        else:
            pca_ = PCA(n_components=comp_, svd_solver='auto')
        reduced_data=pca_.fit_transform(abs_array)
        self.pca = {'coordinates': reduced_data, 'variance': pca_.explained_variance_ratio_}
        self.i_tmp_map = 0
        self.dict_phase={}
        self.max_val={}
        printphase = True

        print(colored('Phase map construstion using ' + params['method'] + ' similarity in PCA coordinates', 'cyan'))
        z = np.array([self.__similarity__pca__(item, params=params) for item in np.array(reduced_data).real])     
        return x, y, z

    def generate_t_sne(self, params=None):
        """
        The method generate map of phases given from dimension reduction using t-SNE method.
        Args:
            params(dict): The dictionary contains PCA parameters:
                    'factor': r-factor for similarity comparison of PCA vectors. When similarity search occurs the two spectra is compaired and r-factor is calculated. If the calculated r-factor is lower than given in param['factor'] there is new phase.
                    'method'(str): similarity method. It could be cosine similarity, pearson similarity or sorenson similarity
                    'range': each element contains pair of values that determine range of x-values where spectra is compaired.
                        param['range'][0] - xmin
                        param['range'][1] - xmax
                        Default: all range is used
                     'components'(int): number of components in PCA. default: 2
                     'perplexity'(float): perplexity value. Default: 3

        Returns:
            x, y, z: map of phases. x,y spatial coordinates
                z is phases number

        """
        x = np.array([item[1] for item in self.__map_spectra__.values()])
        y = np.array([item[2] for item in self.__map_spectra__.values()])
        if 'method' not in params:
            params['method'] = 'cosine'
        if 'factor' not in params:
            params['factor'] = 0.95
        if 'components' not in params:
            params['components']= 2
        if 'perplexity' not in params:
            params['perplexity']= 50
        n_components = params['components']
        perplexity = params['perplexity']
        abs_array = []
        self.xminn = xmin = params['range'][0]
        self.xmaxx = xmax = params['range'][1]

        for item in self.__map_spectra__.values():
            if xmax>item[6]:
                xmax=item[6]
            if xmin<item[5]:
                xmin=item[5]
            abs_array.append(item[0][self.__get_numarray(item, xmin):self.__get_numarray(item, xmax)])
        abs_array = np.array(abs_array)
        print(colored('Calculate t-SNE coordinates', 'cyan'))
        tsne_perplexity = TSNE(n_jobs = 4, n_components=n_components, perplexity=perplexity, learning_rate=100, n_iter=5000, init="random", random_state=0)
        reduced_data = tsne_perplexity.fit_transform(abs_array)

        self.pca = {'coordinates': reduced_data}
        self.i_tmp_map = 0
        self.dict_phase={}
        self.max_val={}
        printphase = False
        print('')
        print(colored('Phase map construstion using ' + params['method'] + ' similarity in t-SNE coordinates', 'cyan'))
        z = np.array([self.__similarity__pca__(item, params=params) for item in np.array(reduced_data).real])
        return x, y, z

    def __similarity__pca__(self, item, params):
        """
           Find similarity between spectra using cosine, pearson or sorenson metrics between PCA of t-SNE reduced dimension vectors.
           Args:
               item(dict): element of maps_spectra dict, contains information about spectra in selected point
               [np.array(spectrum), mx, my, nv, nr, x1, x2, step]
                    np.array(spectrum): ordinate values of spectrum in the hyperspectral map in the point with mx, my coordinate
                    mx: x-coordinate of the point in the hyperspectral map
                    my: y-coordinate of the point in the hyperspectral map
                    nv: number of points in the spectrum np.array(spectrum)
                    nr: number of points in the reduced spectrum np.array(spectrum). The value is equal to nv in the most cases
                    x1: minimal wavenumber in the spectrum
                    x2: maximum wavenumber in the spectrum
                    step: distance between adjacent x values (step of wavenumber measurement)
                param(dict): The dictionary with parameters of similarity finding
                    'factor': each element contains pair of values.
                        The param['factor'][0] is the limit r-factor in similarity findings between hyperspectral members of map to construct phase map in dict_phases{}
                        The param['factor'][1] is the limit r-factor in similarity findings between dict_phase{} element and spectra in database
                        When similarity search occurs the two spectra is compaired and r-factor is calculated. If the calculated r-factor is lower than given in param['factor'] there is new phase.
                    'method'(str): similarity method. It could be cosine similarity, pearson similarity or sorenson similarity
                    'range': each element contains pair of values that determine range of x-values where spectra is compaired.
                        param['range'][0] - xmin
                        param['range'][1] - xmax
                        Default: all range is used
            Returns:
                phase number.
        """
        item_tmp = np.nan_to_num(item)
        factor=params['factor'][0]
        method=params['method']
        r = 0.1
        if self.i_tmp_map == 0:
            self.i_tmp_map = 1
            print(self.i_tmp_map, end='_')
            self.dict_phase['phase' + str(1)] = [item_tmp, self.i_tmp_map, 0, 0, 0, len(item_tmp)]
            return self.i_tmp_map

        tmp_arr = []
        # print(factor)
        for key, value in self.dict_phase.items():
            # print(method)
            if method == 'cosine':
                # print(method)
                r = np.dot(item_tmp, value[0]) / (np.linalg.norm(item_tmp) * np.linalg.norm(value[0]))
            if method == 'pearson':
                r = pearsonr(item_tmp, value[0])[0]
            if method == 'sorenson':
                r = 1.0 - 2.0 * np.logical_and(item_tmp, value[0]).sum() / (value[0].sum() + item_tmp.sum())
            tmp_arr.append(r)
        tmp_arr = np.array(tmp_arr)
        nnn = np.argmax(tmp_arr)
        rrr = np.amax(tmp_arr)
        # print(rrr)
        if rrr >= factor:
                if (max(item_tmp) > max(self.dict_phase['phase' + str(nnn + 1)][0])):
                    self.max_val['phase' + str(nnn + 1)] = [item_tmp, nnn + 1]
                else:
                    self.max_val['phase' + str(nnn + 1)] = [self.dict_phase['phase' + str(nnn + 1)][0], nnn + 1]
                return self.dict_phase['phase' + str(nnn + 1)][1] + rrr
        self.i_tmp_map = self.i_tmp_map + 1
        print(self.i_tmp_map, end='_')
        self.dict_phase['phase' + str(self.i_tmp_map)] = [item_tmp, self.i_tmp_map, 0, 0, 0,
                                                          len(item_tmp)]

        z_val = self.i_tmp_map
        return z_val

    def generate_lda(self, y_arr=None, params=None):
        """
        The method generate map of phases given from dimension reduction using t-SNE method.
        Args:
            params(dict): The dictionary contains PCA parameters:
                    'factor': r-factor for similarity comparison of PCA vectors. When similarity search occurs the two spectra is compaired and r-factor is calculated. If the calculated r-factor is lower than given in param['factor'] there is new phase.
                    'method'(str): similarity method. It could be cosine similarity, pearson similarity or sorenson similarity
                    'range': each element contains pair of values that determine range of x-values where spectra is compaired.
                        param['range'][0] - xmin
                        param['range'][1] - xmax
                        Default: all range is used
                     'components'(int): number of components in PCA. default: 2
                     'perplexity'(float): perplexity value. Default: 3

        Returns:
            x, y, z: map of phases. x,y spatial coordinates
                z is phases number

        """
        x = np.array([item[1] for item in self.__map_spectra__.values()])
        y = np.array([item[2] for item in self.__map_spectra__.values()])
        if 'method' not in params:
            params['method'] = 'cosine'
        if 'factor' not in params:
            params['factor'] = 0.95
        if 'components' not in params:
            params['components']= 2
        # print(params)
        n_components = params['components']
        abs_array = []
        self.xminn = xmin = params['range'][0]
        self.xmaxx = xmax = params['range'][1]

        for item in self.__map_spectra__.values():
            if xmax>item[6]:
                xmax=item[6]
            if xmin<item[5]:
                xmin=item[5]
            abs_array.append(item[0][self.__get_numarray(item, xmin):self.__get_numarray(item, xmax)])
        abs_array = np.array(abs_array)
        print(colored('Calculate LDA coordinates', 'cyan'))
        lda= LinearDiscriminantAnalysis(n_components=n_components)
        reduced_data = lda.fit_transform(abs_array, np.array(y_arr).astype('int'))

        self.pca = {'coordinates': reduced_data}
        self.i_tmp_map = 0
        self.dict_phase={}
        self.max_val={}
        printphase = False
        print('')
        print(colored('Phase map construstion using ' + params['method'] + ' similarity in LDA coordinates', 'cyan'))
        z = np.array([self.__similarity__pca__(item, params=params) for item in np.array(reduced_data).real])
        return x, y, z

