import time as tm
import os
import numpy as np

counter = None
import sys


def colored(text, color=None, on_color=None, attrs=None):
    """
    Безопасная замена termcolor.colored.
    Использует только ANSI escape-коды и не вызывает shell-команды (sh, tput, color),
    что критично для работы multiprocessing.
    """
    # Если вывод перенаправлен не в терминал, просто возвращаем текст
    if not sys.stdout.isatty() and not os.environ.get("FORCE_COLOR"):
        return str(text)

    ANSI_COLORS = {
        'grey': 30, 'red': 31, 'green': 32, 'yellow': 33,
        'blue': 34, 'magenta': 35, 'cyan': 36, 'white': 37,
        'light_grey': 37, 'dark_grey': 90, 'light_blue': 94,
    }
    
    code = ANSI_COLORS.get(color, 0)
    
    if code == 0:
        return str(text)
        
    return f"\033[{code}m{text}\033[0m"

class ProgressBar(object):
    def __init__(self, time0):
        self.__time0__ = time0

    def printProgressBar(self, iteration, total, prefix='', suffix='', decimals=1, length=100, fill='█', printEnd="\r"):
        """
    Call in a loop to create terminal progress bar
    @params:
        iteration   - Required  : current iteration (Int)
        total       - Required  : total iterations (Int)
        prefix      - Optional  : prefix string (Str)
        suffix      - Optional  : suffix string (Str)
        decimals    - Optional  : positive number of decimals in percent complete (Int)
        length      - Optional  : character length of bar (Int)
        fill        - Optional  : bar fill character (Str)
        printEnd    - Optional  : end character (e.g. "\r", "\r\n") (Str)
        """

        percent = colored(("{0:." + str(decimals) + "f}").format(100 * (iteration / np.float64(total))), 'red')
        filledLength = int(length * iteration // total)
        percent_sign = colored('%', 'red')
        bar = fill * filledLength + '-' * (length - filledLength)
        time_elapsed = ' ' + str(int(tm.time() - self.__time0__)) + ' sec'
        print(f'\r{prefix} |{bar}| {percent}{percent_sign}{time_elapsed} {suffix}', end=printEnd)
        # Print New Line on Complete
        if iteration == total:
            print()
