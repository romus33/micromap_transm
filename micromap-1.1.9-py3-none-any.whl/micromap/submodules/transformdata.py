import kramers as kk
import math
from scipy.signal import wiener
import scipy.sparse as sparse
from scipy.sparse.linalg import spsolve
import numpy as np
import ctypes
from ctypes import *
from multiprocessing import Pool, Value
import copy
import time as tm
import progressbar as pb
import os
import platform
import finder as fnd
from functools import partial
from pathlib import Path

_LIB_DIR = Path(__file__).resolve().parent
_SYSTEM = platform.system()

if _SYSTEM == "Windows":
    _candidates = [_LIB_DIR / "convolution.dll"]
elif _SYSTEM == "Darwin":
    _candidates = [
        _LIB_DIR / "convolution.dylib",
        _LIB_DIR / "convolution.so",
    ]
else:
    _candidates = [_LIB_DIR / "convolution.so"]

_lib_path = next((p for p in _candidates if p.is_file()), None)

if _lib_path is None:
    raise FileNotFoundError(
        "Не найдена нативная библиотека.\n"
        f"Искал в: {_LIB_DIR}\n"
        f"Ожидал один из файлов: {[str(p) for p in _candidates]}"
    )

try:
    myclib = ctypes.CDLL(str(_lib_path))
except OSError as exc:
    raise ImportError(
        f"Не удалось загрузить нативную библиотеку: {_lib_path}\n"
        f"Ошибка: {exc}"
    ) from exc
#myclib = cdll.LoadLibrary(name_dll)


_round_to = lambda num, digits: 0 if num == 0 else round(num, max(int(
    -math.floor(math.log10(abs(num - int(num))))) + digits - 1, digits))

import sys

def colored(text, color=None, on_color=None, attrs=None):
    """
    Безопасная замена termcolor.colored.
    Использует только ANSI escape-коды и не вызывает shell-команды (sh, tput, color),
    что критично для работы multiprocessing.
    """
    # Если вывод перенаправлен не в терминал, просто возвращаем текст
    if not sys.stdout.isatty() and not os.environ.get("FORCE_COLOR"):
        return str(text)

    ANSI_COLORS = {
        'grey': 30, 'red': 31, 'green': 32, 'yellow': 33,
        'blue': 34, 'magenta': 35, 'cyan': 36, 'white': 37,
        'light_grey': 37, 'dark_grey': 90, 'light_blue': 94,
    }
    
    code = ANSI_COLORS.get(color, 0)
    
    if code == 0:
        return str(text)
        
    return f"\033[{code}m{text}\033[0m"
class TransformData(object):
    """Baseline and smoothing, transmittance to absorbance, reflectivity to KK class"""

    def __init__(self):
        """Constructor"""

        # manager= Manager()
        # self.map_baselines=manager.dict()
        self.map_baselines = {}
        self.lam_als = 1e8
        self.p_als = 0.01
        self.leng = 0
        self.__pBar__ = pb.ProgressBar(tm.time())

        # self.ii=0
        # self.myclib = cdll.LoadLibrary("convolution")

    @staticmethod
    def __init_C__(args):
        global counter
        counter = args

    def baseline_als_dll(self, y):
        """Baseline reconstruct using ALS algorithm using external dll library convolution.dll
            https://zanran_storage.s3.amazonaws.com/www.science.uva.nl/ContentPages/443199618.pdf
            Asymmetric Least Squares Smoothing
            niter - Maximum number of iterations
            lam - 2nd derivative constraint
            p - Weighting of positive residuals
        
        """
        y_arr = y[0]
        lam = self.lam_als
        p = self.p_als
        niter = 10
        py_ALS = myclib.ALS
        py_ALS.argtypes = [POINTER(c_double), POINTER(c_double), c_int, c_double, c_double, c_int]
        py_ALS.restype = None
        inputarray = (c_double * len(y_arr))(*y_arr)
        outputarray = (c_double * len(y_arr))()
        N = c_int(len(y_arr))
        lam_dll = c_double(lam)
        p_dll = c_double(p)
        py_ALS(inputarray, outputarray, N, lam_dll, p_dll, niter)
        name = str(y[1]) + '_' + str(y[2])

        with counter.get_lock():
            counter.value += 1
            self.__pBar__.printProgressBar(counter.value, self.leng, prefix='Progress:', suffix='', length=50)

        return name, np.array(outputarray)
    def despike(self, y):
        a = 8
        b = 0.1
        y_ = fnd.spike_removal(y[0],a,b)
        y_ = fnd.spike_removal(y_,a,b)
        name = str(y[1]) + '_' + str(y[2])

        with counter.get_lock():
            counter.value += 1
            self.__pBar__.printProgressBar(counter.value, self.leng, prefix='Progress:', suffix='', length=50)        
        return name, np.array(y_)  
    
    def spike_removal(self, mapS, a = 8, b = 0.1, width_param_rel=0.0001, moving_average_window=20, num_proc = 4):
        
        # length = len(mapS)
        # print(colored('Cosmic rays removal:', 'cyan'))
        # self.__pBar__.printProgressBar(0, length, prefix='Progress:', suffix='', length=50)
        # i = 0
        # for key, value in mapS.items():
        #     mapS[key][0] = fnd.spike_removal(mapS[key][0],a,b, width_param_rel=width_param_rel, moving_average_window=moving_average_window)
        #     i = i + 1
        #     self.__pBar__.printProgressBar(i, length, prefix='Progress:', suffix='', length=50)        
        self.leng = len(mapS)
        a_ = copy.deepcopy(mapS)
        print(colored('Cosmic rays removal:', 'cyan'))
        self.__pBar__.printProgressBar(0, self.leng, prefix='Progress:', suffix='', length=50)        
        cs = int(len(mapS) / num_proc)
        global counter
        counter = Value('i', 0)
        pool = Pool(processes=num_proc, initializer=self.__init_C__, initargs=(counter,))
        z = pool.map_async(self.despike, mapS.values(), chunksize=cs)
        z.wait()
        d = z.get()
        for val in d:
            a_[str(val[0])][0] = val[1]   
        mapS = a_
        pool.close()


 
    def clean_co2_point(self,y, extrapolate=False ):
        x_ = [2317.8293,2325.5813,2333.3333,2341.0852,2348.8372,2356.589,2364.341,2372.093,2379.845,2387.597,2395.3489,2403.1008,2410.8528,2418.6047,2426.3567,2434.1086]
        a = [0.00732,0.02332,0.03898,0.07168,0.06526,0.03338,-0.04316,-0.01473,0.00917,0.02057,0.02666,0.01957,0.01376,0.01359,0.00407,-0.00358]
        b = [0.00961,0.00938,0.00218,-0.00553,-0.01647,-0.04019,-0.07915,-0.0482,-0.01935,0.0033,0.01916,0.01695,0.01113,0.00913,0.00752,0.0022]
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        c_ = y[0]
        x_min = y[5]
        x_max = y[6]
        x_length = y[3]
        x_arr = np.asarray(x_, dtype=float)
        a_arr = np.asarray(a, dtype=float)
        b_arr = np.asarray(b, dtype=float)
        c_arr = np.asarray(c_, dtype=float)
        name = str(y[1]) + '_' + str(y[2])
        if x_arr.size != a_arr.size or x_arr.size != b_arr.size:
            raise ValueError(
                "Массивы x_, a и b должны содержать одинаковое количество элементов."
            )

        x_length = int(x_length)

        if c_arr.size != x_length:
            raise ValueError(
                "Количество элементов массива c_ должно быть равно x_length."
            )

        if x_length < 2:
            raise ValueError("x_length должно быть не меньше 2.")

        x_flat = x_arr.ravel()
        a_flat = a_arr.ravel()
        b_flat = b_arr.ravel()
        c_flat = c_arr.ravel()

        # Исходная ось X для c_
        x_c = np.linspace(float(x_min), float(x_max), x_length)

        # --------------------------------------------------------------------
        # 1. Интерполируем c_ на ось x_, чтобы выполнить подгонку
        # --------------------------------------------------------------------
        c_on_x =  np.interp(x_flat, x_c, c_flat, left=0, right=0)
        mask = (
            np.isfinite(x_flat)
            & np.isfinite(a_flat)
            & np.isfinite(b_flat)
            & np.isfinite(c_on_x)
        )

        n_valid = int(np.count_nonzero(mask))

        if n_valid < 3:
            raise ValueError(
                "Недостаточно корректных точек для оценки трёх коэффициентов "
                "c1, c2, c3."
            )

        X = np.column_stack(
            (
                a_flat[mask],
                b_flat[mask],
                np.ones(n_valid),
            )
        )

        y = c_on_x[mask]

        coeffs, _, rank, _ = np.linalg.lstsq(X, y, rcond=-1)

        c1, c2, c3 = coeffs

        # --------------------------------------------------------------------
        # 2. Подогнанный спектр на оси x_
        # --------------------------------------------------------------------
        fitted_on_x = c1 * a_flat + c2 * b_flat #+ c3
        r_squared = np.corrcoef(y, fitted_on_x+c3)[0, 1] ** 2
        if r_squared>0.7:
            # --------------------------------------------------------------------
            # 3. Интерполируем подогнанный спектр на исходную ось c_
            # --------------------------------------------------------------------
            fitted_on_c = np.interp(x_c, x_flat, fitted_on_x, left=0, right=0).ravel()

            # --------------------------------------------------------------------
            # 4. Вычитаем из исходного c_
            # --------------------------------------------------------------------
            residual = (c_flat - fitted_on_c).reshape(c_arr.shape)
            with counter.get_lock():
                counter.value += 1
                self.__pBar__.printProgressBar(counter.value, self.leng, prefix='Progress:', suffix='', length=50)    
            return name, np.array(residual)
        else:
            with counter.get_lock():
                counter.value += 1
                self.__pBar__.printProgressBar(counter.value, self.leng, prefix='Progress:', suffix='', length=50)    
            return name, np.array(c_)            

    def clean_co2(self, mapS, num_proc = 4):
        """
          Method to substract CO2 from all spectra in hyperspectral map
          
        """
        self.leng = len(mapS)
        print(colored('CO2 substraction:', 'cyan'))
        self.__pBar__.printProgressBar(0, self.leng, prefix='Progress:', suffix='', length=50)
        cs = int(len(mapS) / num_proc)
        global counter
        counter = Value('i', 0)
        pool = Pool(processes=num_proc, initializer=self.__init_C__, initargs=(counter,))
        z = pool.map_async(self.clean_co2_point, mapS.values(), chunksize=cs)
        z.wait()
        d = z.get()
        # print(f)
        for val in d:
            mapS[str(val[0])][0] = val[1]
        pool.close()
   
              
        
        
    def substract_baseline_map(self, mapS, lam, p, baseline_dict=None, num_proc = 4):
        """
          Method to substract baseline from all spectra in hyperspectral map
          
        """
        if baseline_dict is None:
            baseline_dict={}
        self.leng = len(mapS)
        print(colored('Baseline substraction using Assymetric Least Smoothing (ALS):', 'cyan'))
        self.__pBar__.printProgressBar(0, self.leng, prefix='Progress:', suffix='', length=50)
        self.lam_als = lam
        self.p_als = p
        self.map_baselines = baseline_dict if baseline_dict else copy.deepcopy(mapS)
        if baseline_dict:
            for key, value in mapS.items():
                mapS[key][0] = mapS[key][0] - self.map_baselines[key][0]
            return
        cs = int(len(mapS) / num_proc)
        global counter
        counter = Value('i', 0)
        pool = Pool(processes=num_proc, initializer=self.__init_C__, initargs=(counter,))
        z = pool.map_async(self.baseline_als_dll, mapS.values(), chunksize=cs)
        z.wait()
        d = z.get()
        # print(f)
        for val in d:
            mapS[str(val[0])][0] -= val[1]
            self.map_baselines[str(val[0])][0] = val[1]
        pool.close()
        
    def Shift_x_map(self, mapS, shift = 1):
        print(colored('Shift X:', 'cyan'))
        length = len(mapS)
        self.__pBar__.printProgressBar(0, length, prefix='Progress:', suffix='', length=50)
        i = 0
        for key, value in mapS.items():
            #[np.array(spectrum), mx, my, nv, nr, x1, x2, step]
            mapS[key][5] =  mapS[key][5] - shift
            mapS[key][6] =  mapS[key][6] - shift
            i = i + 1
            # time_elapsed=' '+str(int(tm.time()-time0))+' sec'
            self.__pBar__.printProgressBar(i, length, prefix='Progress:', suffix='', length=50)              
                   
    def WienerFilter_map(self, mapS, mysize=3, noise=3):
        """
          Method to smooth all spectra in hyperspectral map using Wiener map
        """
        length = len(mapS)
        print(colored('Wiener filteration:', 'cyan'))
        self.__pBar__.printProgressBar(0, length, prefix='Progress:', suffix='', length=50)
        i = 0
        # time0=tm.time()
        for key, value in mapS.items():
            mapS[key][0] = self.WienerFilter(mapS[key][0], mysize, noise)
            i = i + 1
            # time_elapsed=' '+str(int(tm.time()-time0))+' sec'
            self.__pBar__.printProgressBar(i, length, prefix='Progress:', suffix='', length=50)
            # return mapS

    def AbsorbanceConvert_map(self, mapS):
        """
          Method to convert transmittance to absorbance for all points in hyperspectral map
        """
        length = len(mapS)
        print(colored('Transmittance to absorbance convertation:', 'cyan'))
        self.__pBar__.printProgressBar(0, length, prefix='Progress:', suffix='', length=50)
        i = 0
        for key, value in mapS.items():
            mapS[key][0] = self.dat_to_absorbance(mapS[key][0])
            i = i + 1
            self.__pBar__.printProgressBar(i, length, prefix='Progress:', suffix='', length=50)

    def KramersConvert_map(self, mapS, ER=1.31, RefI=1.62):
        """
          Method to convert reflectivity to absorbance using Kramers Kronig equation
          ER - Effective reflection numbers
          RefI- refractive index at infinity
        """
        length = len(mapS)
        print(colored('Kramers-Kronig transformation', 'cyan'))
        self.__pBar__.printProgressBar(0, length, prefix='Progress:', suffix='', length=50)
        i = 0
        for key, value in mapS.items():
            x = np.linspace(value[5], value[6], value[4])
            y = abs(value[0] / 100.0)
            n_Z = np.ones(len(x)) * 1
            mapS[key][0] = kk.op_constants(x, n_Z, x, y, ER, RefI)[:, 0]
            i = i + 1
            self.__pBar__.printProgressBar(i, length, prefix='Progress:', suffix='', length=50)

    @staticmethod
    def baseline_als(y_arr: np.ndarray, lam: np.double, p: np.double, niter=10):
        """Baseline reconstruct using ALS algorithm using scipy libraries
            https://zanran_storage.s3.amazonaws.com/www.science.uva.nl/ContentPages/443199618.pdf
            Asymmetric Least Squares Smoothing
            niter - Maximum number of iterations
            lam - 2nd derivative constraint
            p - Weighting of positive residuals
        
        """
        L = np.uint(y_arr.size)
        D = sparse.diags([1, -2, 1], [0, -1, -2], shape=(L, L - 2))
        D = lam * D.dot(D.transpose())
        w = np.ones(L)
        W = sparse.spdiags(w, 0, L, L)
        for i in range(niter):
            W.setdiag(w)
            Z = W + D
            z = spsolve(Z, w * y_arr)
            w = p * (y_arr > z) + (1 - p) * (y_arr < z)
        return z

    @staticmethod
    def WienerFilter(y_arr, mysize=3, noise=3):
        """
        Smoothing using Wiener filter
        """

        wi = wiener(y_arr, mysize, noise)
        return wi

    @staticmethod
    def dat_to_absorbance(item):
        """
              Transmittance to absorbance
        """
        item[item <= 0] = 0.1
        absorb = -np.log10(item / 100)

        return absorb
